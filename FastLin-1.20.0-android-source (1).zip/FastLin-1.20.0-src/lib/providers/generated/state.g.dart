// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../state.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(configState)
final configStateProvider = ConfigStateProvider._();

final class ConfigStateProvider
    extends $FunctionalProvider<Config, Config, Config>
    with $Provider<Config> {
  ConfigStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'configStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$configStateHash();

  @$internal
  @override
  $ProviderElement<Config> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  Config create(Ref ref) {
    return configState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(Config value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<Config>(value),
    );
  }
}

String _$configStateHash() => r'51588e13e097449bf0b71481e42ce5f0aaf286b9';

@ProviderFor(currentGroupsState)
final currentGroupsStateProvider = CurrentGroupsStateProvider._();

final class CurrentGroupsStateProvider
    extends $FunctionalProvider<GroupsState, GroupsState, GroupsState>
    with $Provider<GroupsState> {
  CurrentGroupsStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'currentGroupsStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$currentGroupsStateHash();

  @$internal
  @override
  $ProviderElement<GroupsState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  GroupsState create(Ref ref) {
    return currentGroupsState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(GroupsState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<GroupsState>(value),
    );
  }
}

String _$currentGroupsStateHash() =>
    r'f97e7d4a45fdbc18c23d2837224369193c6ad2e3';

@ProviderFor(navigationItemsState)
final navigationItemsStateProvider = NavigationItemsStateProvider._();

final class NavigationItemsStateProvider
    extends
        $FunctionalProvider<
          NavigationItemsState,
          NavigationItemsState,
          NavigationItemsState
        >
    with $Provider<NavigationItemsState> {
  NavigationItemsStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'navigationItemsStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$navigationItemsStateHash();

  @$internal
  @override
  $ProviderElement<NavigationItemsState> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  NavigationItemsState create(Ref ref) {
    return navigationItemsState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(NavigationItemsState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<NavigationItemsState>(value),
    );
  }
}

String _$navigationItemsStateHash() =>
    r'8cccbc549ad3fa17ee7a3f3db0d72fbaf8cc439b';

@ProviderFor(currentNavigationItemsState)
final currentNavigationItemsStateProvider =
    CurrentNavigationItemsStateProvider._();

final class CurrentNavigationItemsStateProvider
    extends
        $FunctionalProvider<
          NavigationItemsState,
          NavigationItemsState,
          NavigationItemsState
        >
    with $Provider<NavigationItemsState> {
  CurrentNavigationItemsStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'currentNavigationItemsStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$currentNavigationItemsStateHash();

  @$internal
  @override
  $ProviderElement<NavigationItemsState> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  NavigationItemsState create(Ref ref) {
    return currentNavigationItemsState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(NavigationItemsState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<NavigationItemsState>(value),
    );
  }
}

String _$currentNavigationItemsStateHash() =>
    r'159f22cdd09a4393e53d08d5ea1542df64710fd7';

@ProviderFor(coreState)
final coreStateProvider = CoreStateProvider._();

final class CoreStateProvider
    extends $FunctionalProvider<CoreState, CoreState, CoreState>
    with $Provider<CoreState> {
  CoreStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'coreStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$coreStateHash();

  @$internal
  @override
  $ProviderElement<CoreState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  CoreState create(Ref ref) {
    return coreState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(CoreState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<CoreState>(value),
    );
  }
}

String _$coreStateHash() => r'97dec0fcbbc5308c5821deb2d04a3d668615b8bb';

@ProviderFor(updateParams)
final updateParamsProvider = UpdateParamsProvider._();

final class UpdateParamsProvider
    extends $FunctionalProvider<UpdateParams, UpdateParams, UpdateParams>
    with $Provider<UpdateParams> {
  UpdateParamsProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'updateParamsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$updateParamsHash();

  @$internal
  @override
  $ProviderElement<UpdateParams> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  UpdateParams create(Ref ref) {
    return updateParams(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(UpdateParams value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<UpdateParams>(value),
    );
  }
}

String _$updateParamsHash() => r'd7c86cdf9a5f98d0ea7f6621f88a91ad57f8cdb8';

@ProviderFor(proxyState)
final proxyStateProvider = ProxyStateProvider._();

final class ProxyStateProvider
    extends $FunctionalProvider<ProxyState, ProxyState, ProxyState>
    with $Provider<ProxyState> {
  ProxyStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'proxyStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$proxyStateHash();

  @$internal
  @override
  $ProviderElement<ProxyState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  ProxyState create(Ref ref) {
    return proxyState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ProxyState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ProxyState>(value),
    );
  }
}

String _$proxyStateHash() => r'b1ac8276521b9948d4374ed0ef06a1dac498cfed';

@ProviderFor(WakelockState)
final wakelockStateProvider = WakelockStateProvider._();

final class WakelockStateProvider
    extends $NotifierProvider<WakelockState, bool> {
  WakelockStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'wakelockStateProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$wakelockStateHash();

  @$internal
  @override
  WakelockState create() => WakelockState();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(bool value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<bool>(value),
    );
  }
}

String _$wakelockStateHash() => r'127a960dca14e72c79d5db693145c3d2bf756374';

abstract class _$WakelockState extends $Notifier<bool> {
  bool build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<bool, bool>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<bool, bool>,
              bool,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

@ProviderFor(IsRestartingCore)
final isRestartingCoreProvider = IsRestartingCoreProvider._();

final class IsRestartingCoreProvider
    extends $NotifierProvider<IsRestartingCore, bool> {
  IsRestartingCoreProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'isRestartingCoreProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$isRestartingCoreHash();

  @$internal
  @override
  IsRestartingCore create() => IsRestartingCore();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(bool value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<bool>(value),
    );
  }
}

String _$isRestartingCoreHash() => r'6aa6e78ee75218cf96605ffcce6591763a319991';

abstract class _$IsRestartingCore extends $Notifier<bool> {
  bool build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<bool, bool>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<bool, bool>,
              bool,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

@ProviderFor(trayState)
final trayStateProvider = TrayStateProvider._();

final class TrayStateProvider
    extends $FunctionalProvider<TrayState, TrayState, TrayState>
    with $Provider<TrayState> {
  TrayStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'trayStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$trayStateHash();

  @$internal
  @override
  $ProviderElement<TrayState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  TrayState create(Ref ref) {
    return trayState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(TrayState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<TrayState>(value),
    );
  }
}

String _$trayStateHash() => r'0a29fc928f71098761ddac2121022c39749aa864';

@ProviderFor(vpnState)
final vpnStateProvider = VpnStateProvider._();

final class VpnStateProvider
    extends $FunctionalProvider<VpnState, VpnState, VpnState>
    with $Provider<VpnState> {
  VpnStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'vpnStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$vpnStateHash();

  @$internal
  @override
  $ProviderElement<VpnState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  VpnState create(Ref ref) {
    return vpnState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(VpnState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<VpnState>(value),
    );
  }
}

String _$vpnStateHash() => r'128ddad03ce045ad1f8204e47aec3cb6cfa29f6e';

@ProviderFor(navigationState)
final navigationStateProvider = NavigationStateProvider._();

final class NavigationStateProvider
    extends
        $FunctionalProvider<NavigationState, NavigationState, NavigationState>
    with $Provider<NavigationState> {
  NavigationStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'navigationStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$navigationStateHash();

  @$internal
  @override
  $ProviderElement<NavigationState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  NavigationState create(Ref ref) {
    return navigationState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(NavigationState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<NavigationState>(value),
    );
  }
}

String _$navigationStateHash() => r'72b2bd0c18fce0342a37b21529019c241534b616';

@ProviderFor(dashboardState)
final dashboardStateProvider = DashboardStateProvider._();

final class DashboardStateProvider
    extends $FunctionalProvider<DashboardState, DashboardState, DashboardState>
    with $Provider<DashboardState> {
  DashboardStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'dashboardStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$dashboardStateHash();

  @$internal
  @override
  $ProviderElement<DashboardState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  DashboardState create(Ref ref) {
    return dashboardState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(DashboardState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<DashboardState>(value),
    );
  }
}

String _$dashboardStateHash() => r'83778c83f07a7a1b8ea85417f712f45a4a897cba';

@ProviderFor(proxiesActionsState)
final proxiesActionsStateProvider = ProxiesActionsStateProvider._();

final class ProxiesActionsStateProvider
    extends
        $FunctionalProvider<
          ProxiesActionsState,
          ProxiesActionsState,
          ProxiesActionsState
        >
    with $Provider<ProxiesActionsState> {
  ProxiesActionsStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'proxiesActionsStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$proxiesActionsStateHash();

  @$internal
  @override
  $ProviderElement<ProxiesActionsState> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ProxiesActionsState create(Ref ref) {
    return proxiesActionsState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ProxiesActionsState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ProxiesActionsState>(value),
    );
  }
}

String _$proxiesActionsStateHash() =>
    r'84f8a94706233ff5d4b8a456291a4e66c1381c62';

@ProviderFor(startButtonSelectorState)
final startButtonSelectorStateProvider = StartButtonSelectorStateProvider._();

final class StartButtonSelectorStateProvider
    extends
        $FunctionalProvider<
          StartButtonSelectorState,
          StartButtonSelectorState,
          StartButtonSelectorState
        >
    with $Provider<StartButtonSelectorState> {
  StartButtonSelectorStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'startButtonSelectorStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$startButtonSelectorStateHash();

  @$internal
  @override
  $ProviderElement<StartButtonSelectorState> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  StartButtonSelectorState create(Ref ref) {
    return startButtonSelectorState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(StartButtonSelectorState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<StartButtonSelectorState>(value),
    );
  }
}

String _$startButtonSelectorStateHash() =>
    r'537aff93c98b0a689cf8cabd080c610c9c58e611';

@ProviderFor(profilesSelectorState)
final profilesSelectorStateProvider = ProfilesSelectorStateProvider._();

final class ProfilesSelectorStateProvider
    extends
        $FunctionalProvider<
          ProfilesSelectorState,
          ProfilesSelectorState,
          ProfilesSelectorState
        >
    with $Provider<ProfilesSelectorState> {
  ProfilesSelectorStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'profilesSelectorStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$profilesSelectorStateHash();

  @$internal
  @override
  $ProviderElement<ProfilesSelectorState> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ProfilesSelectorState create(Ref ref) {
    return profilesSelectorState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ProfilesSelectorState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ProfilesSelectorState>(value),
    );
  }
}

String _$profilesSelectorStateHash() =>
    r'aac2deee6e747eceaf62cb5f279ec99ce9227a5a';

@ProviderFor(visibleGroupsState)
final visibleGroupsStateProvider = VisibleGroupsStateProvider._();

final class VisibleGroupsStateProvider
    extends $FunctionalProvider<GroupsState, GroupsState, GroupsState>
    with $Provider<GroupsState> {
  VisibleGroupsStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'visibleGroupsStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$visibleGroupsStateHash();

  @$internal
  @override
  $ProviderElement<GroupsState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  GroupsState create(Ref ref) {
    return visibleGroupsState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(GroupsState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<GroupsState>(value),
    );
  }
}

String _$visibleGroupsStateHash() =>
    r'1425229f50a0628cdf37ed89813b8cf96e2f5f5d';

@ProviderFor(filterGroupsState)
final filterGroupsStateProvider = FilterGroupsStateFamily._();

final class FilterGroupsStateProvider
    extends $FunctionalProvider<GroupsState, GroupsState, GroupsState>
    with $Provider<GroupsState> {
  FilterGroupsStateProvider._({
    required FilterGroupsStateFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'filterGroupsStateProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$filterGroupsStateHash();

  @override
  String toString() {
    return r'filterGroupsStateProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $ProviderElement<GroupsState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  GroupsState create(Ref ref) {
    final argument = this.argument as String;
    return filterGroupsState(ref, argument);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(GroupsState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<GroupsState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is FilterGroupsStateProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$filterGroupsStateHash() => r'8afbff336cb27dcf968f4d20e7feff569e3a3f24';

final class FilterGroupsStateFamily extends $Family
    with $FunctionalFamilyOverride<GroupsState, String> {
  FilterGroupsStateFamily._()
    : super(
        retry: null,
        name: r'filterGroupsStateProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  FilterGroupsStateProvider call(String query) =>
      FilterGroupsStateProvider._(argument: query, from: this);

  @override
  String toString() => r'filterGroupsStateProvider';
}

@ProviderFor(delaySortSnapshot)
final delaySortSnapshotProvider = DelaySortSnapshotProvider._();

final class DelaySortSnapshotProvider
    extends $FunctionalProvider<DelayMap, DelayMap, DelayMap>
    with $Provider<DelayMap> {
  DelaySortSnapshotProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'delaySortSnapshotProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$delaySortSnapshotHash();

  @$internal
  @override
  $ProviderElement<DelayMap> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  DelayMap create(Ref ref) {
    return delaySortSnapshot(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(DelayMap value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<DelayMap>(value),
    );
  }
}

String _$delaySortSnapshotHash() => r'09437a82b63fe35d4d9e47a03d401d0c65c385fb';

@ProviderFor(SortedGroupProxies)
final sortedGroupProxiesProvider = SortedGroupProxiesFamily._();

final class SortedGroupProxiesProvider
    extends $NotifierProvider<SortedGroupProxies, List<Proxy>?> {
  SortedGroupProxiesProvider._({
    required SortedGroupProxiesFamily super.from,
    required (String, String) super.argument,
  }) : super(
         retry: null,
         name: r'sortedGroupProxiesProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$sortedGroupProxiesHash();

  @override
  String toString() {
    return r'sortedGroupProxiesProvider'
        ''
        '$argument';
  }

  @$internal
  @override
  SortedGroupProxies create() => SortedGroupProxies();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(List<Proxy>? value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<List<Proxy>?>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is SortedGroupProxiesProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$sortedGroupProxiesHash() =>
    r'5e631c8fd12ed454c3b1430d50aa3a706600845a';

final class SortedGroupProxiesFamily extends $Family
    with
        $ClassFamilyOverride<
          SortedGroupProxies,
          List<Proxy>?,
          List<Proxy>?,
          List<Proxy>?,
          (String, String)
        > {
  SortedGroupProxiesFamily._()
    : super(
        retry: null,
        name: r'sortedGroupProxiesProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  SortedGroupProxiesProvider call(String query, String groupName) =>
      SortedGroupProxiesProvider._(argument: (query, groupName), from: this);

  @override
  String toString() => r'sortedGroupProxiesProvider';
}

abstract class _$SortedGroupProxies extends $Notifier<List<Proxy>?> {
  late final _$args = ref.$arg as (String, String);
  String get query => _$args.$1;
  String get groupName => _$args.$2;

  List<Proxy>? build(String query, String groupName);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<List<Proxy>?, List<Proxy>?>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<List<Proxy>?, List<Proxy>?>,
              List<Proxy>?,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args.$1, _$args.$2));
  }
}

@ProviderFor(sortedGroupsState)
final sortedGroupsStateProvider = SortedGroupsStateFamily._();

final class SortedGroupsStateProvider
    extends $FunctionalProvider<GroupsState, GroupsState, GroupsState>
    with $Provider<GroupsState> {
  SortedGroupsStateProvider._({
    required SortedGroupsStateFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'sortedGroupsStateProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$sortedGroupsStateHash();

  @override
  String toString() {
    return r'sortedGroupsStateProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $ProviderElement<GroupsState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  GroupsState create(Ref ref) {
    final argument = this.argument as String;
    return sortedGroupsState(ref, argument);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(GroupsState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<GroupsState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is SortedGroupsStateProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$sortedGroupsStateHash() => r'6f5bd90c6d11ff2d647b70127a76b7e6d5303d1e';

final class SortedGroupsStateFamily extends $Family
    with $FunctionalFamilyOverride<GroupsState, String> {
  SortedGroupsStateFamily._()
    : super(
        retry: null,
        name: r'sortedGroupsStateProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  SortedGroupsStateProvider call(String query) =>
      SortedGroupsStateProvider._(argument: query, from: this);

  @override
  String toString() => r'sortedGroupsStateProvider';
}

@ProviderFor(proxiesListState)
final proxiesListStateProvider = ProxiesListStateProvider._();

final class ProxiesListStateProvider
    extends
        $FunctionalProvider<
          ProxiesListState,
          ProxiesListState,
          ProxiesListState
        >
    with $Provider<ProxiesListState> {
  ProxiesListStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'proxiesListStateProvider',
        isAutoDispose: true,
        dependencies: <ProviderOrFamily>[queryProvider],
        $allTransitiveDependencies: <ProviderOrFamily>[
          ProxiesListStateProvider.$allTransitiveDependencies0,
        ],
      );

  static final $allTransitiveDependencies0 = queryProvider;

  @override
  String debugGetCreateSourceHash() => _$proxiesListStateHash();

  @$internal
  @override
  $ProviderElement<ProxiesListState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  ProxiesListState create(Ref ref) {
    return proxiesListState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ProxiesListState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ProxiesListState>(value),
    );
  }
}

String _$proxiesListStateHash() => r'8246b3165aa0f3a7cd199d42b9c1c1bb54330e1a';

@ProviderFor(proxiesTabState)
final proxiesTabStateProvider = ProxiesTabStateProvider._();

final class ProxiesTabStateProvider
    extends
        $FunctionalProvider<ProxiesTabState, ProxiesTabState, ProxiesTabState>
    with $Provider<ProxiesTabState> {
  ProxiesTabStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'proxiesTabStateProvider',
        isAutoDispose: true,
        dependencies: <ProviderOrFamily>[queryProvider],
        $allTransitiveDependencies: <ProviderOrFamily>[
          ProxiesTabStateProvider.$allTransitiveDependencies0,
        ],
      );

  static final $allTransitiveDependencies0 = queryProvider;

  @override
  String debugGetCreateSourceHash() => _$proxiesTabStateHash();

  @$internal
  @override
  $ProviderElement<ProxiesTabState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  ProxiesTabState create(Ref ref) {
    return proxiesTabState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ProxiesTabState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ProxiesTabState>(value),
    );
  }
}

String _$proxiesTabStateHash() => r'c30411b187481ab00ed9c565d4fa1c2e25fbc1b9';

@ProviderFor(proxiesTabControllerState)
final proxiesTabControllerStateProvider = ProxiesTabControllerStateProvider._();

final class ProxiesTabControllerStateProvider
    extends
        $FunctionalProvider<
          ({List<String> a, String? b}),
          ({List<String> a, String? b}),
          ({List<String> a, String? b})
        >
    with $Provider<({List<String> a, String? b})> {
  ProxiesTabControllerStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'proxiesTabControllerStateProvider',
        isAutoDispose: true,
        dependencies: <ProviderOrFamily>[proxiesTabStateProvider],
        $allTransitiveDependencies: <ProviderOrFamily>[
          ProxiesTabControllerStateProvider.$allTransitiveDependencies0,
          ProxiesTabControllerStateProvider.$allTransitiveDependencies1,
        ],
      );

  static final $allTransitiveDependencies0 = proxiesTabStateProvider;
  static final $allTransitiveDependencies1 =
      ProxiesTabStateProvider.$allTransitiveDependencies0;

  @override
  String debugGetCreateSourceHash() => _$proxiesTabControllerStateHash();

  @$internal
  @override
  $ProviderElement<({List<String> a, String? b})> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ({List<String> a, String? b}) create(Ref ref) {
    return proxiesTabControllerState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(({List<String> a, String? b}) value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<({List<String> a, String? b})>(
        value,
      ),
    );
  }
}

String _$proxiesTabControllerStateHash() =>
    r'b80e11e9e3cc78793963d6dd40e6ab32994f007a';

@ProviderFor(proxyGroupSelectorState)
final proxyGroupSelectorStateProvider = ProxyGroupSelectorStateFamily._();

final class ProxyGroupSelectorStateProvider
    extends
        $FunctionalProvider<
          ProxyGroupSelectorState,
          ProxyGroupSelectorState,
          ProxyGroupSelectorState
        >
    with $Provider<ProxyGroupSelectorState> {
  ProxyGroupSelectorStateProvider._({
    required ProxyGroupSelectorStateFamily super.from,
    required (String, String) super.argument,
  }) : super(
         retry: null,
         name: r'proxyGroupSelectorStateProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$proxyGroupSelectorStateHash();

  @override
  String toString() {
    return r'proxyGroupSelectorStateProvider'
        ''
        '$argument';
  }

  @$internal
  @override
  $ProviderElement<ProxyGroupSelectorState> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ProxyGroupSelectorState create(Ref ref) {
    final argument = this.argument as (String, String);
    return proxyGroupSelectorState(ref, argument.$1, argument.$2);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ProxyGroupSelectorState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ProxyGroupSelectorState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is ProxyGroupSelectorStateProvider &&
        other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$proxyGroupSelectorStateHash() =>
    r'c2a059873a38907071a2664409bacfe21b7d6c3c';

final class ProxyGroupSelectorStateFamily extends $Family
    with $FunctionalFamilyOverride<ProxyGroupSelectorState, (String, String)> {
  ProxyGroupSelectorStateFamily._()
    : super(
        retry: null,
        name: r'proxyGroupSelectorStateProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  ProxyGroupSelectorStateProvider call(String groupName, String query) =>
      ProxyGroupSelectorStateProvider._(
        argument: (groupName, query),
        from: this,
      );

  @override
  String toString() => r'proxyGroupSelectorStateProvider';
}

@ProviderFor(packageListSelectorState)
final packageListSelectorStateProvider = PackageListSelectorStateProvider._();

final class PackageListSelectorStateProvider
    extends
        $FunctionalProvider<
          PackageListSelectorState,
          PackageListSelectorState,
          PackageListSelectorState
        >
    with $Provider<PackageListSelectorState> {
  PackageListSelectorStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'packageListSelectorStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$packageListSelectorStateHash();

  @$internal
  @override
  $ProviderElement<PackageListSelectorState> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  PackageListSelectorState create(Ref ref) {
    return packageListSelectorState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PackageListSelectorState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PackageListSelectorState>(value),
    );
  }
}

String _$packageListSelectorStateHash() =>
    r'26ad58fec2cb0136ece373c7f3ec89b5aafd9324';

@ProviderFor(moreToolsSelectorState)
final moreToolsSelectorStateProvider = MoreToolsSelectorStateProvider._();

final class MoreToolsSelectorStateProvider
    extends
        $FunctionalProvider<
          MoreToolsSelectorState,
          MoreToolsSelectorState,
          MoreToolsSelectorState
        >
    with $Provider<MoreToolsSelectorState> {
  MoreToolsSelectorStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'moreToolsSelectorStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$moreToolsSelectorStateHash();

  @$internal
  @override
  $ProviderElement<MoreToolsSelectorState> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  MoreToolsSelectorState create(Ref ref) {
    return moreToolsSelectorState(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(MoreToolsSelectorState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<MoreToolsSelectorState>(value),
    );
  }
}

String _$moreToolsSelectorStateHash() =>
    r'e9560ecd2bccfe98f3360bf83c70f524d6ec1b12';

@ProviderFor(isCurrentPage)
final isCurrentPageProvider = IsCurrentPageFamily._();

final class IsCurrentPageProvider extends $FunctionalProvider<bool, bool, bool>
    with $Provider<bool> {
  IsCurrentPageProvider._({
    required IsCurrentPageFamily super.from,
    required (
      PageLabel, {
      bool Function(PageLabel pageLabel, ViewMode viewMode)? handler,
    })
    super.argument,
  }) : super(
         retry: null,
         name: r'isCurrentPageProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$isCurrentPageHash();

  @override
  String toString() {
    return r'isCurrentPageProvider'
        ''
        '$argument';
  }

  @$internal
  @override
  $ProviderElement<bool> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  bool create(Ref ref) {
    final argument =
        this.argument
            as (
              PageLabel, {
              bool Function(PageLabel pageLabel, ViewMode viewMode)? handler,
            });
    return isCurrentPage(ref, argument.$1, handler: argument.handler);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(bool value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<bool>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is IsCurrentPageProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$isCurrentPageHash() => r'7c300770aef90da23109d9fcfc3bf26140d8cd08';

final class IsCurrentPageFamily extends $Family
    with
        $FunctionalFamilyOverride<
          bool,
          (
            PageLabel, {
            bool Function(PageLabel pageLabel, ViewMode viewMode)? handler,
          })
        > {
  IsCurrentPageFamily._()
    : super(
        retry: null,
        name: r'isCurrentPageProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  IsCurrentPageProvider call(
    PageLabel pageLabel, {
    bool Function(PageLabel pageLabel, ViewMode viewMode)? handler,
  }) => IsCurrentPageProvider._(
    argument: (pageLabel, handler: handler),
    from: this,
  );

  @override
  String toString() => r'isCurrentPageProvider';
}

@ProviderFor(getRealTestUrl)
final getRealTestUrlProvider = GetRealTestUrlFamily._();

final class GetRealTestUrlProvider
    extends $FunctionalProvider<String, String, String>
    with $Provider<String> {
  GetRealTestUrlProvider._({
    required GetRealTestUrlFamily super.from,
    required String? super.argument,
  }) : super(
         retry: null,
         name: r'getRealTestUrlProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$getRealTestUrlHash();

  @override
  String toString() {
    return r'getRealTestUrlProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $ProviderElement<String> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  String create(Ref ref) {
    final argument = this.argument as String?;
    return getRealTestUrl(ref, argument);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(String value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<String>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is GetRealTestUrlProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$getRealTestUrlHash() => r'2e3aeb2fbaf4f62c016a3a8a4f712f75e93a2686';

final class GetRealTestUrlFamily extends $Family
    with $FunctionalFamilyOverride<String, String?> {
  GetRealTestUrlFamily._()
    : super(
        retry: null,
        name: r'getRealTestUrlProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  GetRealTestUrlProvider call([String? testUrl]) =>
      GetRealTestUrlProvider._(argument: testUrl, from: this);

  @override
  String toString() => r'getRealTestUrlProvider';
}

@ProviderFor(getDelay)
final getDelayProvider = GetDelayFamily._();

final class GetDelayProvider extends $FunctionalProvider<int?, int?, int?>
    with $Provider<int?> {
  GetDelayProvider._({
    required GetDelayFamily super.from,
    required ({String proxyName, String? testUrl}) super.argument,
  }) : super(
         retry: null,
         name: r'getDelayProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$getDelayHash();

  @override
  String toString() {
    return r'getDelayProvider'
        ''
        '$argument';
  }

  @$internal
  @override
  $ProviderElement<int?> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  int? create(Ref ref) {
    final argument = this.argument as ({String proxyName, String? testUrl});
    return getDelay(
      ref,
      proxyName: argument.proxyName,
      testUrl: argument.testUrl,
    );
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(int? value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<int?>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is GetDelayProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$getDelayHash() => r'541f25ef7ee423966a5e0d33a8522231c6ca12b1';

final class GetDelayFamily extends $Family
    with
        $FunctionalFamilyOverride<int?, ({String proxyName, String? testUrl})> {
  GetDelayFamily._()
    : super(
        retry: null,
        name: r'getDelayProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  GetDelayProvider call({required String proxyName, String? testUrl}) =>
      GetDelayProvider._(
        argument: (proxyName: proxyName, testUrl: testUrl),
        from: this,
      );

  @override
  String toString() => r'getDelayProvider';
}

@ProviderFor(selectedMap)
final selectedMapProvider = SelectedMapProvider._();

final class SelectedMapProvider
    extends $FunctionalProvider<SelectedMap, SelectedMap, SelectedMap>
    with $Provider<SelectedMap> {
  SelectedMapProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'selectedMapProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$selectedMapHash();

  @$internal
  @override
  $ProviderElement<SelectedMap> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  SelectedMap create(Ref ref) {
    return selectedMap(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(SelectedMap value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<SelectedMap>(value),
    );
  }
}

String _$selectedMapHash() => r'0d7a3610d9005e74e1a88595d7e22897dc8240a5';

@ProviderFor(unfoldSet)
final unfoldSetProvider = UnfoldSetProvider._();

final class UnfoldSetProvider
    extends $FunctionalProvider<Set<String>, Set<String>, Set<String>>
    with $Provider<Set<String>> {
  UnfoldSetProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'unfoldSetProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$unfoldSetHash();

  @$internal
  @override
  $ProviderElement<Set<String>> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  Set<String> create(Ref ref) {
    return unfoldSet(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(Set<String> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<Set<String>>(value),
    );
  }
}

String _$unfoldSetHash() => r'59a5b417611533069462ddf31eca080ab2f74ac9';

@ProviderFor(getHotKeyAction)
final getHotKeyActionProvider = GetHotKeyActionFamily._();

final class GetHotKeyActionProvider
    extends $FunctionalProvider<HotKeyAction, HotKeyAction, HotKeyAction>
    with $Provider<HotKeyAction> {
  GetHotKeyActionProvider._({
    required GetHotKeyActionFamily super.from,
    required HotAction super.argument,
  }) : super(
         retry: null,
         name: r'getHotKeyActionProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$getHotKeyActionHash();

  @override
  String toString() {
    return r'getHotKeyActionProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $ProviderElement<HotKeyAction> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  HotKeyAction create(Ref ref) {
    final argument = this.argument as HotAction;
    return getHotKeyAction(ref, argument);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(HotKeyAction value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<HotKeyAction>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is GetHotKeyActionProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$getHotKeyActionHash() => r'4dc74ea7ffb25624ce70c7c8214806f3ef022223';

final class GetHotKeyActionFamily extends $Family
    with $FunctionalFamilyOverride<HotKeyAction, HotAction> {
  GetHotKeyActionFamily._()
    : super(
        retry: null,
        name: r'getHotKeyActionProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  GetHotKeyActionProvider call(HotAction hotAction) =>
      GetHotKeyActionProvider._(argument: hotAction, from: this);

  @override
  String toString() => r'getHotKeyActionProvider';
}

@ProviderFor(currentProfile)
final currentProfileProvider = CurrentProfileProvider._();

final class CurrentProfileProvider
    extends $FunctionalProvider<Profile?, Profile?, Profile?>
    with $Provider<Profile?> {
  CurrentProfileProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'currentProfileProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$currentProfileHash();

  @$internal
  @override
  $ProviderElement<Profile?> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  Profile? create(Ref ref) {
    return currentProfile(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(Profile? value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<Profile?>(value),
    );
  }
}

String _$currentProfileHash() => r'55f3cb9570a0aa6b9e0b83a36693b69d52e753ab';

@ProviderFor(getProxiesColumns)
final getProxiesColumnsProvider = GetProxiesColumnsProvider._();

final class GetProxiesColumnsProvider extends $FunctionalProvider<int, int, int>
    with $Provider<int> {
  GetProxiesColumnsProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'getProxiesColumnsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$getProxiesColumnsHash();

  @$internal
  @override
  $ProviderElement<int> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  int create(Ref ref) {
    return getProxiesColumns(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(int value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<int>(value),
    );
  }
}

String _$getProxiesColumnsHash() => r'725066b5fc21f590a4c2656a1fd5e14ab7079079';

@ProviderFor(getProxyCardState)
final getProxyCardStateProvider = GetProxyCardStateFamily._();

final class GetProxyCardStateProvider
    extends $FunctionalProvider<ProxyCardState, ProxyCardState, ProxyCardState>
    with $Provider<ProxyCardState> {
  GetProxyCardStateProvider._({
    required GetProxyCardStateFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'getProxyCardStateProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$getProxyCardStateHash();

  @override
  String toString() {
    return r'getProxyCardStateProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $ProviderElement<ProxyCardState> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  ProxyCardState create(Ref ref) {
    final argument = this.argument as String;
    return getProxyCardState(ref, argument);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ProxyCardState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ProxyCardState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is GetProxyCardStateProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$getProxyCardStateHash() => r'b6efd96f9310627f8b9426efd98429f60a5c3c66';

final class GetProxyCardStateFamily extends $Family
    with $FunctionalFamilyOverride<ProxyCardState, String> {
  GetProxyCardStateFamily._()
    : super(
        retry: null,
        name: r'getProxyCardStateProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  GetProxyCardStateProvider call(String proxyName) =>
      GetProxyCardStateProvider._(argument: proxyName, from: this);

  @override
  String toString() => r'getProxyCardStateProvider';
}

@ProviderFor(getProxyName)
final getProxyNameProvider = GetProxyNameFamily._();

final class GetProxyNameProvider
    extends $FunctionalProvider<String?, String?, String?>
    with $Provider<String?> {
  GetProxyNameProvider._({
    required GetProxyNameFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'getProxyNameProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$getProxyNameHash();

  @override
  String toString() {
    return r'getProxyNameProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $ProviderElement<String?> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  String? create(Ref ref) {
    final argument = this.argument as String;
    return getProxyName(ref, argument);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(String? value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<String?>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is GetProxyNameProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$getProxyNameHash() => r'204a477ea18c8e1eeef55b3efd3d47e45b0d2350';

final class GetProxyNameFamily extends $Family
    with $FunctionalFamilyOverride<String?, String> {
  GetProxyNameFamily._()
    : super(
        retry: null,
        name: r'getProxyNameProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  GetProxyNameProvider call(String groupName) =>
      GetProxyNameProvider._(argument: groupName, from: this);

  @override
  String toString() => r'getProxyNameProvider';
}

@ProviderFor(getSelectedProxyName)
final getSelectedProxyNameProvider = GetSelectedProxyNameFamily._();

final class GetSelectedProxyNameProvider
    extends $FunctionalProvider<String?, String?, String?>
    with $Provider<String?> {
  GetSelectedProxyNameProvider._({
    required GetSelectedProxyNameFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'getSelectedProxyNameProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$getSelectedProxyNameHash();

  @override
  String toString() {
    return r'getSelectedProxyNameProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $ProviderElement<String?> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  String? create(Ref ref) {
    final argument = this.argument as String;
    return getSelectedProxyName(ref, argument);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(String? value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<String?>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is GetSelectedProxyNameProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$getSelectedProxyNameHash() =>
    r'13aeae1fede234983d262d824a85c7375f9e4e78';

final class GetSelectedProxyNameFamily extends $Family
    with $FunctionalFamilyOverride<String?, String> {
  GetSelectedProxyNameFamily._()
    : super(
        retry: null,
        name: r'getSelectedProxyNameProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  GetSelectedProxyNameProvider call(String groupName) =>
      GetSelectedProxyNameProvider._(argument: groupName, from: this);

  @override
  String toString() => r'getSelectedProxyNameProvider';
}

@ProviderFor(getProxyDesc)
final getProxyDescProvider = GetProxyDescFamily._();

final class GetProxyDescProvider
    extends $FunctionalProvider<String, String, String>
    with $Provider<String> {
  GetProxyDescProvider._({
    required GetProxyDescFamily super.from,
    required Proxy super.argument,
  }) : super(
         retry: null,
         name: r'getProxyDescProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$getProxyDescHash();

  @override
  String toString() {
    return r'getProxyDescProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $ProviderElement<String> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  String create(Ref ref) {
    final argument = this.argument as Proxy;
    return getProxyDesc(ref, argument);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(String value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<String>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is GetProxyDescProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$getProxyDescHash() => r'c173fe2393d9c4f5d5d17480e69f9126bb76a17d';

final class GetProxyDescFamily extends $Family
    with $FunctionalFamilyOverride<String, Proxy> {
  GetProxyDescFamily._()
    : super(
        retry: null,
        name: r'getProxyDescProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  GetProxyDescProvider call(Proxy proxy) =>
      GetProxyDescProvider._(argument: proxy, from: this);

  @override
  String toString() => r'getProxyDescProvider';
}

@ProviderFor(ProfileOverrideState)
final profileOverrideStateProvider = ProfileOverrideStateProvider._();

final class ProfileOverrideStateProvider
    extends $NotifierProvider<ProfileOverrideState, ProfileOverrideStateModel> {
  ProfileOverrideStateProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'profileOverrideStateProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$profileOverrideStateHash();

  @$internal
  @override
  ProfileOverrideState create() => ProfileOverrideState();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ProfileOverrideStateModel value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ProfileOverrideStateModel>(value),
    );
  }
}

String _$profileOverrideStateHash() =>
    r'0a1657ff3b4657fcc481a4cdd1deda5b353bf845';

abstract class _$ProfileOverrideState
    extends $Notifier<ProfileOverrideStateModel> {
  ProfileOverrideStateModel build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref =
        this.ref as $Ref<ProfileOverrideStateModel, ProfileOverrideStateModel>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<ProfileOverrideStateModel, ProfileOverrideStateModel>,
              ProfileOverrideStateModel,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

@ProviderFor(getProfileOverrideData)
final getProfileOverrideDataProvider = GetProfileOverrideDataFamily._();

final class GetProfileOverrideDataProvider
    extends $FunctionalProvider<OverrideData?, OverrideData?, OverrideData?>
    with $Provider<OverrideData?> {
  GetProfileOverrideDataProvider._({
    required GetProfileOverrideDataFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'getProfileOverrideDataProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$getProfileOverrideDataHash();

  @override
  String toString() {
    return r'getProfileOverrideDataProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $ProviderElement<OverrideData?> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  OverrideData? create(Ref ref) {
    final argument = this.argument as String;
    return getProfileOverrideData(ref, argument);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(OverrideData? value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<OverrideData?>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is GetProfileOverrideDataProvider &&
        other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$getProfileOverrideDataHash() =>
    r'a17ec085f1733b63b123ac08aa7737588c048c5f';

final class GetProfileOverrideDataFamily extends $Family
    with $FunctionalFamilyOverride<OverrideData?, String> {
  GetProfileOverrideDataFamily._()
    : super(
        retry: null,
        name: r'getProfileOverrideDataProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  GetProfileOverrideDataProvider call(String profileId) =>
      GetProfileOverrideDataProvider._(argument: profileId, from: this);

  @override
  String toString() => r'getProfileOverrideDataProvider';
}

@ProviderFor(layoutChange)
final layoutChangeProvider = LayoutChangeProvider._();

final class LayoutChangeProvider
    extends
        $FunctionalProvider<
          ({double a, TextScale b})?,
          ({double a, TextScale b})?,
          ({double a, TextScale b})?
        >
    with $Provider<({double a, TextScale b})?> {
  LayoutChangeProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'layoutChangeProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$layoutChangeHash();

  @$internal
  @override
  $ProviderElement<({double a, TextScale b})?> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ({double a, TextScale b})? create(Ref ref) {
    return layoutChange(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(({double a, TextScale b})? value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<({double a, TextScale b})?>(value),
    );
  }
}

String _$layoutChangeHash() => r'5e527deea13cf23dcdb98a4279e7742d8ec9f654';

@ProviderFor(checkIp)
final checkIpProvider = CheckIpProvider._();

final class CheckIpProvider
    extends
        $FunctionalProvider<
          ({int a, bool b}),
          ({int a, bool b}),
          ({int a, bool b})
        >
    with $Provider<({int a, bool b})> {
  CheckIpProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'checkIpProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$checkIpHash();

  @$internal
  @override
  $ProviderElement<({int a, bool b})> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ({int a, bool b}) create(Ref ref) {
    return checkIp(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(({int a, bool b}) value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<({int a, bool b})>(value),
    );
  }
}

String _$checkIpHash() => r'12d4e2923506bc82a49c2e876f063215fcc10fe3';

@ProviderFor(checkMediaUnlock)
final checkMediaUnlockProvider = CheckMediaUnlockProvider._();

final class CheckMediaUnlockProvider
    extends
        $FunctionalProvider<
          ({int a, bool b}),
          ({int a, bool b}),
          ({int a, bool b})
        >
    with $Provider<({int a, bool b})> {
  CheckMediaUnlockProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'checkMediaUnlockProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$checkMediaUnlockHash();

  @$internal
  @override
  $ProviderElement<({int a, bool b})> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ({int a, bool b}) create(Ref ref) {
    return checkMediaUnlock(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(({int a, bool b}) value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<({int a, bool b})>(value),
    );
  }
}

String _$checkMediaUnlockHash() => r'b04a7d53bd4ba1716700a3826fc9bef7ae2d2778';

@ProviderFor(genColorScheme)
final genColorSchemeProvider = GenColorSchemeFamily._();

final class GenColorSchemeProvider
    extends $FunctionalProvider<ColorScheme, ColorScheme, ColorScheme>
    with $Provider<ColorScheme> {
  GenColorSchemeProvider._({
    required GenColorSchemeFamily super.from,
    required (Brightness, {Color? color, bool ignoreConfig}) super.argument,
  }) : super(
         retry: null,
         name: r'genColorSchemeProvider',
         isAutoDispose: false,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$genColorSchemeHash();

  @override
  String toString() {
    return r'genColorSchemeProvider'
        ''
        '$argument';
  }

  @$internal
  @override
  $ProviderElement<ColorScheme> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  ColorScheme create(Ref ref) {
    final argument =
        this.argument as (Brightness, {Color? color, bool ignoreConfig});
    return genColorScheme(
      ref,
      argument.$1,
      color: argument.color,
      ignoreConfig: argument.ignoreConfig,
    );
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ColorScheme value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ColorScheme>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is GenColorSchemeProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$genColorSchemeHash() => r'92cdac158caaeb5385c58e3ae8f4d99962c08bdf';

final class GenColorSchemeFamily extends $Family
    with
        $FunctionalFamilyOverride<
          ColorScheme,
          (Brightness, {Color? color, bool ignoreConfig})
        > {
  GenColorSchemeFamily._()
    : super(
        retry: null,
        name: r'genColorSchemeProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: false,
      );

  GenColorSchemeProvider call(
    Brightness brightness, {
    Color? color,
    bool ignoreConfig = false,
  }) => GenColorSchemeProvider._(
    argument: (brightness, color: color, ignoreConfig: ignoreConfig),
    from: this,
  );

  @override
  String toString() => r'genColorSchemeProvider';
}

@ProviderFor(currentProfileScript)
final currentProfileScriptProvider = CurrentProfileScriptProvider._();

final class CurrentProfileScriptProvider
    extends $FunctionalProvider<Script?, Script?, Script?>
    with $Provider<Script?> {
  CurrentProfileScriptProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'currentProfileScriptProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$currentProfileScriptHash();

  @$internal
  @override
  $ProviderElement<Script?> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  Script? create(Ref ref) {
    return currentProfileScript(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(Script? value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<Script?>(value),
    );
  }
}

String _$currentProfileScriptHash() =>
    r'2dee96513396788b81b67296af450440e1433859';

@ProviderFor(currentProfileScriptActive)
final currentProfileScriptActiveProvider =
    CurrentProfileScriptActiveProvider._();

final class CurrentProfileScriptActiveProvider
    extends $FunctionalProvider<bool, bool, bool>
    with $Provider<bool> {
  CurrentProfileScriptActiveProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'currentProfileScriptActiveProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$currentProfileScriptActiveHash();

  @$internal
  @override
  $ProviderElement<bool> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  bool create(Ref ref) {
    return currentProfileScriptActive(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(bool value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<bool>(value),
    );
  }
}

String _$currentProfileScriptActiveHash() =>
    r'bece7356f9e4608d113ff8a296baf67101685676';

@ProviderFor(needSetup)
final needSetupProvider = NeedSetupProvider._();

final class NeedSetupProvider
    extends
        $FunctionalProvider<
          ({
            String? a,
            String? b,
            String? c,
            bool d,
            String e,
            String f,
            String g,
          }),
          ({
            String? a,
            String? b,
            String? c,
            bool d,
            String e,
            String f,
            String g,
          }),
          ({
            String? a,
            String? b,
            String? c,
            bool d,
            String e,
            String f,
            String g,
          })
        >
    with
        $Provider<
          ({
            String? a,
            String? b,
            String? c,
            bool d,
            String e,
            String f,
            String g,
          })
        > {
  NeedSetupProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'needSetupProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$needSetupHash();

  @$internal
  @override
  $ProviderElement<
    ({String? a, String? b, String? c, bool d, String e, String f, String g})
  >
  $createElement($ProviderPointer pointer) => $ProviderElement(pointer);

  @override
  ({String? a, String? b, String? c, bool d, String e, String f, String g})
  create(Ref ref) {
    return needSetup(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(
    ({String? a, String? b, String? c, bool d, String e, String f, String g})
    value,
  ) {
    return $ProviderOverride(
      origin: this,
      providerOverride:
          $SyncValueProvider<
            ({
              String? a,
              String? b,
              String? c,
              bool d,
              String e,
              String f,
              String g,
            })
          >(value),
    );
  }
}

String _$needSetupHash() => r'bb597a72b9af6bfa6421aed848f0470c58d59481';

@ProviderFor(currentBrightness)
final currentBrightnessProvider = CurrentBrightnessProvider._();

final class CurrentBrightnessProvider
    extends $FunctionalProvider<Brightness, Brightness, Brightness>
    with $Provider<Brightness> {
  CurrentBrightnessProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'currentBrightnessProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$currentBrightnessHash();

  @$internal
  @override
  $ProviderElement<Brightness> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  Brightness create(Ref ref) {
    return currentBrightness(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(Brightness value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<Brightness>(value),
    );
  }
}

String _$currentBrightnessHash() => r'ab56c47af4fcae773c8f9f81c91800c1e1890b70';

@ProviderFor(systemDnsTakeover)
final systemDnsTakeoverProvider = SystemDnsTakeoverProvider._();

final class SystemDnsTakeoverProvider
    extends $FunctionalProvider<bool, bool, bool>
    with $Provider<bool> {
  SystemDnsTakeoverProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'systemDnsTakeoverProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$systemDnsTakeoverHash();

  @$internal
  @override
  $ProviderElement<bool> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  bool create(Ref ref) {
    return systemDnsTakeover(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(bool value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<bool>(value),
    );
  }
}

String _$systemDnsTakeoverHash() => r'a0b4bb0b12473c486d576a2b77d9342e8c72f972';

@ProviderFor(Query)
final queryProvider = QueryProvider._();

final class QueryProvider extends $NotifierProvider<Query, String> {
  QueryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'queryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$queryHash();

  @$internal
  @override
  Query create() => Query();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(String value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<String>(value),
    );
  }
}

String _$queryHash() => r'e99b2a2439872f88f09fee8d63f0cc7fb4852186';

abstract class _$Query extends $Notifier<String> {
  String build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<String, String>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<String, String>,
              String,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

@ProviderFor(currentMainGroupName)
final currentMainGroupNameProvider = CurrentMainGroupNameProvider._();

final class CurrentMainGroupNameProvider
    extends $FunctionalProvider<String?, String?, String?>
    with $Provider<String?> {
  CurrentMainGroupNameProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'currentMainGroupNameProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$currentMainGroupNameHash();

  @$internal
  @override
  $ProviderElement<String?> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  String? create(Ref ref) {
    return currentMainGroupName(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(String? value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<String?>(value),
    );
  }
}

String _$currentMainGroupNameHash() =>
    r'64bce4cffd5ec70eb19f8ba06de79fc8f060bb67';

@ProviderFor(homeWidgetSnapshot)
final homeWidgetSnapshotProvider = HomeWidgetSnapshotProvider._();

final class HomeWidgetSnapshotProvider
    extends
        $FunctionalProvider<
          HomeWidgetSnapshot,
          HomeWidgetSnapshot,
          HomeWidgetSnapshot
        >
    with $Provider<HomeWidgetSnapshot> {
  HomeWidgetSnapshotProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'homeWidgetSnapshotProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$homeWidgetSnapshotHash();

  @$internal
  @override
  $ProviderElement<HomeWidgetSnapshot> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  HomeWidgetSnapshot create(Ref ref) {
    return homeWidgetSnapshot(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(HomeWidgetSnapshot value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<HomeWidgetSnapshot>(value),
    );
  }
}

String _$homeWidgetSnapshotHash() =>
    r'd88d6f0a3f36366a4c63fd52acdb09331ccf1aa8';

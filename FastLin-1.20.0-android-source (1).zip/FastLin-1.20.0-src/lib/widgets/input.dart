import 'dart:async';

import 'package:bett_box/common/common.dart';
import 'package:bett_box/models/common.dart';
import 'package:bett_box/state.dart';
import 'package:bett_box/widgets/dialog.dart';
import 'package:bett_box/widgets/null_status.dart';
import 'package:bett_box/widgets/text.dart';
import 'package:material_ui/material_ui.dart';

import 'card.dart';
import 'effect.dart';
import 'float_layout.dart';
import 'list.dart';
import 'scaffold.dart';
import 'tv_text_field.dart';

class OptionsDialog<T> extends StatelessWidget {
  final String title;
  final List<T> options;
  final T value;
  final String Function(T value) textBuilder;
  final String? Function(T value)? subtitleBuilder;

  const OptionsDialog({
    super.key,
    required this.title,
    required this.options,
    required this.textBuilder,
    this.subtitleBuilder,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return CommonDialog(
      title: title,
      padding: const EdgeInsets.fromLTRB(10, 12, 10, 14),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (final option in options)
            OptionItem(
              text: textBuilder(option),
              subtitle: subtitleBuilder?.call(option),
              selected: value == option,
              onTap: () {
                Navigator.of(context).pop(option);
              },
            ),
        ],
      ),
    );
  }
}

class OptionItem extends StatelessWidget {
  final String text;
  final String? subtitle;
  final bool selected;
  final VoidCallback onTap;

  const OptionItem({
    super.key,
    required this.text,
    this.subtitle,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = context.colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Material(
        color: selected ? colorScheme.secondaryContainer : Colors.transparent,
        shape: const RoundedSuperellipseBorder(
          borderRadius: BorderRadius.all(Radius.circular(20)),
        ),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          focusColor: colorScheme.primary.withValues(alpha: 0.18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              children: [
                Icon(
                  context.resolveIcon(
                    selected
                        ? Icons.check_circle_rounded
                        : Icons.circle_outlined,
                  ),
                  size: 21,
                  color: selected
                      ? colorScheme.primary
                      : colorScheme.onSurfaceVariant.withValues(alpha: 0.6),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (selected)
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: EmojiText(
                            text,
                            style: context.textTheme.bodyMedium?.copyWith(
                              color: colorScheme.onSecondaryContainer,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        )
                      else
                        EmojiText(
                          text,
                          style: context.textTheme.bodyMedium,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                      if (subtitle case final subtitle?
                          when subtitle.trim().isNotEmpty)
                        Text(
                          subtitle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: context.textTheme.bodySmall?.copyWith(
                            color: colorScheme.onSurfaceVariant,
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CommonCheckBox extends StatelessWidget {
  final bool? value;
  final ValueChanged<bool?>? onChanged;
  final bool isCircle;

  const CommonCheckBox({
    required this.value,
    required this.onChanged,
    this.isCircle = false,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Checkbox(
      shape: isCircle ? const CircleBorder() : null,
      value: value,
      onChanged: onChanged,
    );
  }
}

class InputDialog extends StatefulWidget {
  final String title;
  final String value;
  final String? suffixText;
  final String? labelText;
  final String? resetValue;
  final String? hintText;
  final FormFieldValidator<String>? validator;
  final AutovalidateMode? autovalidateMode;
  final bool? obscureText;
  final bool autofocus;
  final bool delayedFocus;
  final int maxLines;
  final TextInputType? keyboardType;
  final TextInputAction? textInputAction;

  const InputDialog({
    super.key,
    required this.title,
    required this.value,
    this.suffixText,
    this.resetValue,
    this.hintText,
    this.validator,
    this.obscureText,
    this.labelText,
    this.autofocus = false,
    this.delayedFocus = false,
    this.maxLines = 1,
    this.keyboardType,
    this.textInputAction,
    this.autovalidateMode = AutovalidateMode.onUserInteraction,
  });

  @override
  State<InputDialog> createState() => _InputDialogState();
}

class _InputDialogState extends State<InputDialog> with IdleAutofocusMixin {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController textController;
  late bool _obscure = widget.obscureText ?? false;
  String get value => widget.value;

  String get title => widget.title;

  String? get suffixText => widget.suffixText;

  @override
  void initState() {
    super.initState();
    textController = TextEditingController(text: value);
  }

  @override
  bool get autofocusWhenIdle => widget.autofocus || widget.delayedFocus;

  @override
  void dispose() {
    textController.dispose();
    super.dispose();
  }

  Future<void> _handleUpdate() async {
    final isValid = _formKey.currentState?.validate() ?? false;
    if (!isValid) {
      return;
    }
    final text = textController.value.text;
    await context.dismissKeyboard();
    if (!mounted) return;
    Navigator.of(context).pop<String>(text);
  }

  Future<void> _handleReset() async {
    final resetVal = widget.resetValue;
    if (resetVal == null) {
      return;
    }
    await context.dismissKeyboard();
    if (!mounted) return;
    Navigator.of(context).pop<String>(resetVal);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        await context.dismissKeyboard();
        if (!context.mounted) return;
        Navigator.of(context).pop();
      },
      child: CommonDialog(
        title: title,
        actions: [
          if (widget.resetValue != null &&
              textController.value.text != widget.resetValue) ...[
            TextButton(
              onPressed: _handleReset,
              child: Text(appLocalizations.reset),
            ),
            const SizedBox(width: 4),
          ],
          TextButton(
            onPressed: _handleUpdate,
            child: Text(appLocalizations.submit),
          ),
        ],
        child: Form(
          autovalidateMode: widget.autovalidateMode,
          key: _formKey,
          child: Wrap(
            runSpacing: 16,
            children: [
              TvTextField(
                focusNode: autofocusNode,
                builder: (tv) => TextFormField(
                  focusNode: tv.focusNode,
                  readOnly: tv.readOnly,
                  showCursor: tv.showCursor,
                  obscureText: _obscure,
                  keyboardType:
                      widget.keyboardType ??
                      (widget.obscureText == true
                          ? TextInputType.visiblePassword
                          : TextInputType.text),
                  textInputAction:
                      widget.textInputAction ?? TextInputAction.done,
                  maxLines: widget.obscureText == true ? 1 : widget.maxLines,
                  minLines: 1,
                  controller: textController,
                  onFieldSubmitted: (_) {
                    _handleUpdate();
                  },
                  decoration: InputDecoration(
                    border: const OutlineInputBorder(),
                    suffixText: suffixText,
                    hintText: widget.hintText,
                    labelText: widget.labelText,
                    suffixIcon: widget.obscureText == true
                        ? IconButton(
                            icon: Icon(
                              context.resolveIcon(
                                _obscure
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                              ),
                            ),
                            onPressed: () {
                              setState(() {
                                _obscure = !_obscure;
                              });
                            },
                          )
                        : null,
                  ),
                  validator: widget.validator,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ListInputPage extends StatelessWidget {
  final String title;
  final List<String> items;
  final Widget Function(String item) titleBuilder;
  final Widget Function(String item)? subtitleBuilder;
  final Widget Function(String item)? leadingBuilder;
  final String? valueLabel;
  final Function(List<String> items) onChange;

  const ListInputPage({
    super.key,
    required this.title,
    required this.items,
    required this.titleBuilder,
    required this.onChange,
    this.leadingBuilder,
    this.valueLabel,
    this.subtitleBuilder,
  });

  Future<void> _handleAddOrEdit([String? item]) async {
    uniqueValidator(String? value) {
      final index = items.indexWhere((entry) {
        return entry == value;
      });
      final current = item == value;
      if (index != -1 && !current) {
        return appLocalizations.existsTip(appLocalizations.value);
      }
      return null;
    }

    final valueField = Field(
      label: valueLabel ?? appLocalizations.value,
      value: item ?? '',
      validator: uniqueValidator,
    );
    final value = await globalState.showCommonDialog<String>(
      child: AddDialog(valueField: valueField, title: title),
    );
    if (value == null) return;
    final index = items.indexWhere((entry) {
      return entry == item;
    });
    final nextItems = List<String>.from(items);
    if (item != null) {
      nextItems[index] = value;
    } else {
      nextItems.add(value);
    }
    onChange(nextItems);
  }

  void _handleDelete(String? item) {
    final entries = List<String>.from(items);
    final index = entries.indexWhere((entry) {
      return entry == item;
    });
    if (index != -1) {
      entries.removeAt(index);
    }
    onChange(entries);
  }

  @override
  Widget build(BuildContext context) {
    return FloatLayout(
      floatingWidget: FloatWrapper(
        child: FloatingActionButton(
          onPressed: () async {
            await context.dismissKeyboard();
            if (!context.mounted) return;
            unawaited(_handleAddOrEdit());
          },
          child: Icon(context.resolveIcon(Icons.add)),
        ),
      ),
      child: items.isEmpty
          ? NullStatus(label: appLocalizations.noData)
          : ScrollEdgeRise(
              builder: (_, rise) => ReorderableListView.builder(
                padding: EdgeInsets.only(
                  top: rise,
                  bottom: 16 + 64 + MediaQuery.viewPaddingOf(context).bottom,
                ),
                buildDefaultDragHandles: false,
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final e = items[index];
                  return _InputItem(
                    key: ValueKey(e),
                    ReorderableDelayedDragStartListener(
                      index: index,
                      child: CommonCard(
                        elevated: false,
                        child: ListItem(
                          leading: leadingBuilder != null
                              ? leadingBuilder!(e)
                              : null,
                          title: titleBuilder(e),
                          subtitle: subtitleBuilder != null
                              ? subtitleBuilder!(e)
                              : null,
                          trailing: IconButton(
                            icon: Icon(
                              context.resolveIcon(Icons.delete_outline),
                            ),
                            onPressed: () {
                              _handleDelete(e);
                            },
                          ),
                        ),
                        onPressed: () {
                          _handleAddOrEdit(e);
                        },
                      ),
                    ),
                  );
                },
                // ignore: deprecated_member_use
                onReorder: (oldIndex, newIndex) {
                  if (oldIndex < newIndex) {
                    newIndex -= 1;
                  }
                  final nextItems = List<String>.from(items);
                  final item = nextItems.removeAt(oldIndex);
                  nextItems.insert(newIndex, item);
                  onChange(nextItems);
                },
              ),
            ),
    );
  }
}

class MapInputPage extends StatelessWidget {
  final String title;
  final Map<String, String> map;
  final Widget Function(MapEntry<String, String> item) titleBuilder;
  final Widget Function(MapEntry<String, String> item)? subtitleBuilder;
  final Widget Function(MapEntry<String, String> item)? leadingBuilder;
  final String? keyLabel;
  final String? valueLabel;
  final Function(Map<String, String> items) onChange;
  final bool Function(MapEntry<String, String> item)? canDelete;
  final Future<MapEntry<String, String>?> Function(
    MapEntry<String, String>? item,
  )?
  editor;

  const MapInputPage({
    super.key,
    required this.title,
    required this.map,
    required this.titleBuilder,
    required this.onChange,
    this.leadingBuilder,
    this.keyLabel,
    this.valueLabel,
    this.subtitleBuilder,
    this.canDelete,
    this.editor,
  });

  List<MapEntry<String, String>> get items =>
      List<MapEntry<String, String>>.from(map.entries);

  Future<void> _handleAddOrEdit([MapEntry<String, String>? item]) async {
    final editor = this.editor;
    final value = editor != null ? await editor(item) : await _showDialog(item);
    if (value == null) return;
    final index = items.indexWhere((entry) {
      return entry.key == item?.key;
    });

    final nextItems = List<MapEntry<String, String>>.from(items);
    if (item != null) {
      nextItems[index] = value;
    } else {
      nextItems.add(value);
    }
    onChange(Map.fromEntries(nextItems));
  }

  Future<MapEntry<String, String>?> _showDialog(
    MapEntry<String, String>? item,
  ) {
    uniqueValidator(String? value) {
      final index = items.indexWhere((entry) {
        return entry.key == value;
      });
      final current = item?.key == value;
      if (index != -1 && !current) {
        return appLocalizations.existsTip(appLocalizations.key);
      }
      return null;
    }

    final keyField = Field(
      label: keyLabel ?? appLocalizations.key,
      value: item == null ? '' : item.key,
      validator: uniqueValidator,
    );

    final valueField = Field(
      label: valueLabel ?? appLocalizations.value,
      value: item == null ? '' : item.value,
    );

    return globalState.showCommonDialog<MapEntry<String, String>>(
      child: AddDialog(
        keyField: keyField,
        valueField: valueField,
        title: title,
      ),
    );
  }

  void _handleDelete(MapEntry<String, String> item) {
    final entries = List<MapEntry<String, String>>.from(items);
    final index = entries.indexWhere((entry) {
      return entry.key == item.key && item.value == entry.value;
    });
    if (index != -1) {
      entries.removeAt(index);
    }
    onChange(Map.fromEntries(entries));
  }

  @override
  Widget build(BuildContext context) {
    return FloatLayout(
      floatingWidget: FloatWrapper(
        child: FloatingActionButton(
          onPressed: () async {
            await context.dismissKeyboard();
            if (!context.mounted) return;
            unawaited(_handleAddOrEdit());
          },
          child: Icon(context.resolveIcon(Icons.add)),
        ),
      ),
      child: items.isEmpty
          ? NullStatus(label: appLocalizations.noData)
          : ScrollEdgeRise(
              builder: (_, rise) => ReorderableListView.builder(
                padding: EdgeInsets.only(
                  top: rise,
                  bottom: 16 + 64 + MediaQuery.viewPaddingOf(context).bottom,
                ),
                proxyDecorator: proxyDecorator,
                buildDefaultDragHandles: false,
                itemCount: items.length,
                itemBuilder: (_, index) {
                  final e = items[index];
                  return _InputItem(
                    key: ValueKey(e.key),
                    ReorderableDelayedDragStartListener(
                      index: index,
                      child: CommonCard(
                        elevated: false,
                        child: ListItem(
                          leading: leadingBuilder != null
                              ? leadingBuilder!(e)
                              : null,
                          title: titleBuilder(e),
                          subtitle: subtitleBuilder != null
                              ? subtitleBuilder!(e)
                              : null,
                          trailing: (canDelete == null || canDelete!(e))
                              ? IconButton(
                                  icon: Icon(
                                    context.resolveIcon(Icons.delete_outline),
                                  ),
                                  onPressed: () {
                                    _handleDelete(e);
                                  },
                                )
                              : null,
                        ),
                        onPressed: () {
                          _handleAddOrEdit(e);
                        },
                      ),
                    ),
                  );
                },
                // ignore: deprecated_member_use
                onReorder: (oldIndex, newIndex) {
                  if (oldIndex < newIndex) {
                    newIndex -= 1;
                  }
                  final nextItems = List<MapEntry<String, String>>.from(items);
                  final item = nextItems.removeAt(oldIndex);
                  nextItems.insert(newIndex, item);
                  onChange(Map.fromEntries(nextItems));
                },
              ),
            ),
    );
  }
}

class AddDialog extends StatefulWidget {
  final String title;
  final Field? keyField;
  final Field valueField;

  const AddDialog({
    super.key,
    required this.title,
    this.keyField,
    required this.valueField,
  });

  @override
  State<AddDialog> createState() => _AddDialogState();
}

class _AddDialogState extends State<AddDialog> with IdleAutofocusMixin {
  TextEditingController? keyController;
  late TextEditingController valueController;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  Field? get keyField => widget.keyField;

  Field get valueField => widget.valueField;

  @override
  bool get autofocusWhenIdle => true;

  @override
  void initState() {
    super.initState();
    if (keyField != null) {
      keyController = TextEditingController(text: keyField!.value);
    }
    valueController = TextEditingController(text: valueField.value);
  }

  @override
  void dispose() {
    keyController?.dispose();
    valueController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    await context.dismissKeyboard();
    if (!mounted) return;
    if (keyField != null) {
      Navigator.of(context).pop<MapEntry<String, String>>(
        MapEntry(keyController!.text, valueController.text),
      );
    } else {
      Navigator.of(context).pop<String>(valueController.text);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        await context.dismissKeyboard();
        if (!context.mounted) return;
        Navigator.of(context).pop();
      },
      child: CommonDialog(
        title: widget.title,
        actions: [
          TextButton(onPressed: _submit, child: Text(appLocalizations.confirm)),
        ],
        child: Form(
          autovalidateMode: AutovalidateMode.onUserInteraction,
          key: _formKey,
          child: Wrap(
            runSpacing: 16,
            children: [
              if (keyField != null)
                TvTextField(
                  focusNode: autofocusNode,
                  builder: (tv) => TextFormField(
                    focusNode: tv.focusNode,
                    readOnly: tv.readOnly,
                    showCursor: tv.showCursor,
                    maxLines: 2,
                    minLines: 1,
                    controller: keyController,
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: keyField!.label,
                    ),
                    validator: (String? value) {
                      String? res;
                      if (keyField!.validator != null) {
                        res = keyField!.validator!(value);
                      }
                      if (res != null) {
                        return res;
                      }
                      if (value == null || value.isEmpty) {
                        return appLocalizations.emptyTip(appLocalizations.key);
                      }
                      return null;
                    },
                  ),
                ),
              TvTextField(
                focusNode: keyField == null ? autofocusNode : null,
                builder: (tv) => TextFormField(
                  focusNode: tv.focusNode,
                  readOnly: tv.readOnly,
                  showCursor: tv.showCursor,
                  maxLines: 3,
                  minLines: 1,
                  controller: valueController,
                  decoration: InputDecoration(
                    border: const OutlineInputBorder(),
                    labelText: valueField.label,
                  ),
                  validator: (String? value) {
                    String? res;
                    if (valueField.validator != null) {
                      res = valueField.validator!(value);
                    }
                    if (res != null) {
                      return res;
                    }
                    if (value == null || value.isEmpty) {
                      return appLocalizations.emptyTip(appLocalizations.value);
                    }
                    return null;
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InputItem extends StatelessWidget {
  final Widget child;

  const _InputItem(this.child, {super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      key: key,
      color: Colors.transparent,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16),
        margin: EdgeInsets.symmetric(vertical: 8),
        child: child,
      ),
    );
  }
}

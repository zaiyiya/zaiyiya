import 'dart:async';
import 'dart:io';

import 'package:bett_box/common/common.dart';
import 'package:bett_box/enum/enum.dart';
import 'package:bett_box/l10n/l10n.dart';
import 'package:bett_box/models/models.dart';
import 'package:bett_box/providers/providers.dart';
import 'package:bett_box/state.dart';
import 'package:bett_box/views/about.dart';
import 'package:bett_box/views/access.dart';
import 'package:bett_box/views/application_setting.dart';
import 'package:bett_box/views/config/config.dart';
import 'package:bett_box/views/config/experimental.dart';
import 'package:bett_box/views/config/general.dart';
import 'package:bett_box/views/config/network.dart';
import 'package:bett_box/views/config/ntp.dart';
import 'package:bett_box/views/config/sniffer.dart';
import 'package:bett_box/views/config/tunnel.dart';
import 'package:bett_box/views/connection/connections.dart';
import 'package:bett_box/views/hotkey.dart';
import 'package:bett_box/views/other_setting.dart';
import 'package:bett_box/views/profiles/scripts.dart';
import 'package:bett_box/views/resources.dart';
import 'package:bett_box/widgets/widgets.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' show dirname, join;

import 'backup_and_recovery.dart';
import 'developer.dart';
import 'theme.dart';

class _SearchItem {
  final String title;
  final String? subtitle;
  final String category;
  final Widget? leading;
  final void Function(BuildContext context, WidgetRef ref) onTap;

  const _SearchItem({
    required this.title,
    this.subtitle,
    required this.category,
    this.leading,
    required this.onTap,
  });
}

class ToolsShortcut {
  final Widget icon;
  final String title;
  final String? subtitle;
  final WidgetBuilder? builder;
  final VoidCallback? onTap;
  final bool wrap;

  const ToolsShortcut({
    required this.icon,
    required this.title,
    this.subtitle,
    this.builder,
    this.onTap,
    this.wrap = true,
  });

  void open(BuildContext context) {
    final builder = this.builder;
    if (builder == null) {
      onTap?.call();
      return;
    }
    showExtend(
      context,
      props: const ExtendProps(forceFull: true),
      builder: (_, type) {
        final child = builder(context);
        return wrap
            ? AdaptiveSheetScaffold(type: type, title: title, body: child)
            : child;
      },
    );
  }
}

List<ToolsShortcut> getToolsShortcuts(
  List<NavigationItem> moreItems,
  List<SidebarFlyoutEntry> entries,
) {
  ToolsShortcut? buildNavigationShortcut(PageLabel label) {
    final item = moreItems.where((item) => item.label == label).firstOrNull;
    if (item == null) {
      return null;
    }
    return ToolsShortcut(
      icon: item.icon,
      title: Intl.message(item.label.name),
      subtitle: switch (item.description) {
        final description? => Intl.message(description),
        null => null,
      },
      builder: item.builder,
      wrap: false,
    );
  }

  return [
    for (final entry in SidebarFlyoutEntry.supportedValues)
      if (entries.contains(entry))
        ?switch (entry) {
          SidebarFlyoutEntry.resources => ToolsShortcut(
            icon: const AppIcon(Icons.storage_outlined),
            title: appLocalizations.resources,
            subtitle: appLocalizations.resourcesDesc,
            builder: (_) => const ResourcesView(),
            wrap: false,
          ),
          SidebarFlyoutEntry.script => ToolsShortcut(
            icon: const AppIcon(Icons.terminal_outlined),
            title: appLocalizations.script,
            subtitle: appLocalizations.scriptDesc,
            builder: (_) => const ScriptsView(),
            wrap: false,
          ),
          SidebarFlyoutEntry.toolbox => buildNavigationShortcut(
            PageLabel.toolbox,
          ),
          SidebarFlyoutEntry.theme => ToolsShortcut(
            icon: const AppIcon(Icons.style_outlined),
            title: appLocalizations.theme,
            subtitle: appLocalizations.themeDesc,
            builder: (_) => const ThemeView(),
          ),
          SidebarFlyoutEntry.backupAndRecovery => ToolsShortcut(
            icon: const AppIcon(Icons.cloud_sync_outlined),
            title: appLocalizations.backupAndRecovery,
            subtitle: appLocalizations.backupAndRecoveryDesc,
            builder: (_) => const BackupAndRecovery(),
          ),
          SidebarFlyoutEntry.hotkeyManagement => ToolsShortcut(
            icon: const AppIcon(Icons.keyboard_outlined),
            title: appLocalizations.hotkeyManagement,
            subtitle: appLocalizations.hotkeyManagementDesc,
            builder: (_) => const HotKeyView(),
          ),
          SidebarFlyoutEntry.loopback => ToolsShortcut(
            icon: const AppIcon(Icons.lock_outlined),
            title: appLocalizations.loopback,
            subtitle: appLocalizations.loopbackDesc,
            onTap: () {
              windows?.runas(
                '"${join(dirname(Platform.resolvedExecutable), "WindowsLoopbackManager.exe")}"',
                '',
                showWindow: true,
              );
            },
          ),
          SidebarFlyoutEntry.basicConfig => ToolsShortcut(
            icon: const AppIcon(Icons.developer_board_outlined),
            title: appLocalizations.basicConfig,
            subtitle: appLocalizations.basicConfigDesc,
            builder: (_) => const ConfigView(),
          ),
          SidebarFlyoutEntry.otherSettings => ToolsShortcut(
            icon: const AppIcon(Icons.auto_fix_high_outlined),
            title: appLocalizations.otherSettings,
            subtitle: appLocalizations.otherSettingsDesc,
            builder: (_) => const OtherSettingView(),
          ),
          SidebarFlyoutEntry.application => ToolsShortcut(
            icon: const AppIcon(Icons.settings_outlined),
            title: appLocalizations.application,
            subtitle: appLocalizations.applicationDesc,
            builder: (_) => const ApplicationSettingView(),
          ),
          SidebarFlyoutEntry.about => ToolsShortcut(
            icon: const AppIcon(Icons.info_outline),
            title: appLocalizations.about,
            builder: (_) => const AboutView(),
          ),
        },
  ];
}

class _GeneralListView extends StatelessWidget {
  const _GeneralListView();

  @override
  Widget build(BuildContext context) {
    return generateListView(generalItems);
  }
}

class ToolsView extends ConsumerStatefulWidget {
  const ToolsView({super.key});

  @override
  ConsumerState<ToolsView> createState() => _ToolViewState();
}

class _ToolViewState extends ConsumerState<ToolsView> {
  Widget _buildNavigationPage(NavigationItem navigationItem) {
    if (navigationItem.label == PageLabel.connections) {
      return const ConnectionsView(respectCurrentPage: false);
    }
    return navigationItem.builder(context);
  }

  Widget _buildNavigationMenuItem(NavigationItem navigationItem) {
    return ListItem.next(
      leading: navigationItem.icon,
      title: Text(Intl.message(navigationItem.label.name)),
      subtitle: navigationItem.description != null
          ? Text(Intl.message(navigationItem.description!))
          : null,
      delegate: NextDelegate(
        title: Intl.message(navigationItem.label.name),
        builder: (_) => _buildNavigationPage(navigationItem),
        wrap: false,
      ),
    );
  }

  Widget _buildModernSection(
    BuildContext context, {
    String? title,
    required List<Widget> items,
  }) {
    return SectionContainer(title: title, items: items);
  }

  String _query = '';
  List<_SearchItem>? _cachedSearchItems;
  String _cachedMoreItemsKey = '';
  Timer? _searchTimer;

  @override
  void dispose() {
    _searchTimer?.cancel();
    super.dispose();
  }

  void _onSearchChanged(String query) {
    _searchTimer?.cancel();
    if (query.isEmpty) {
      if (_query.isNotEmpty || _cachedSearchItems != null) {
        setState(() {
          _query = '';
          _cachedSearchItems = null;
          _cachedMoreItemsKey = '';
        });
      }
      return;
    }
    _searchTimer = Timer(const Duration(milliseconds: 500), () {
      if (!mounted) return;
      setState(() {
        _query = query.toLowerCase();
      });
    });
  }

  String _moreItemsKey(List<NavigationItem> items) {
    return items
        .map((item) => '${item.label.name}\x00${item.description ?? ''}')
        .join('\x01');
  }

  List<_SearchItem> _getSearchItems(List<NavigationItem> moreItems) {
    if (_query.isEmpty) {
      return const [];
    }
    final key = _moreItemsKey(moreItems);
    if (_cachedSearchItems != null && _cachedMoreItemsKey == key) {
      return _cachedSearchItems!;
    }
    _cachedMoreItemsKey = key;
    _cachedSearchItems = _buildSearchItems(moreItems);
    return _cachedSearchItems!;
  }

  void _pushPage(BuildContext context, String title, Widget page) {
    showExtend(
      context,
      builder: (_, type) =>
          AdaptiveSheetScaffold(type: type, title: title, body: page),
    );
  }

  List<_SearchItem> _buildSearchItems(List<NavigationItem> moreItems) {
    final items = <_SearchItem>[];
    final settingsCategory = appLocalizations.settings;
    final configCategory = '$settingsCategory/${appLocalizations.basicConfig}';
    final themeCategory = '$settingsCategory/${appLocalizations.theme}';
    final backupCategory =
        '$settingsCategory/${appLocalizations.backupAndRecovery}';
    final appCategory = '$settingsCategory/${appLocalizations.application}';
    final otherCategory = appLocalizations.other;
    final otherSettingsCategory =
        '$settingsCategory/${appLocalizations.otherSettings}';

    for (final item in moreItems) {
      items.add(
        _SearchItem(
          title: Intl.message(item.label.name),
          subtitle: item.description != null
              ? Intl.message(item.description!)
              : null,
          category: appLocalizations.more,
          leading: item.icon,
          onTap: (context, _) => _pushPage(
            context,
            Intl.message(item.label.name),
            _buildNavigationPage(item),
          ),
        ),
      );
    }

    items.addAll([
      _SearchItem(
        title: appLocalizations.language,
        subtitle: appLocalizations.language,
        category: settingsCategory,
        leading: const AppIcon(Icons.language_outlined),
        onTap: (context, _) =>
            _pushPage(context, appLocalizations.language, const _LocaleItem()),
      ),
      _SearchItem(
        title: appLocalizations.theme,
        subtitle: appLocalizations.themeDesc,
        category: settingsCategory,
        leading: const AppIcon(Icons.style_outlined),
        onTap: (context, _) =>
            _pushPage(context, appLocalizations.theme, const ThemeView()),
      ),
      _SearchItem(
        title: appLocalizations.backupAndRecovery,
        subtitle: appLocalizations.backupAndRecoveryDesc,
        category: settingsCategory,
        leading: const AppIcon(Icons.cloud_sync_outlined),
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.backupAndRecovery,
          const BackupAndRecovery(),
        ),
      ),
      if (system.isDesktop)
        _SearchItem(
          title: appLocalizations.hotkeyManagement,
          subtitle: appLocalizations.hotkeyManagementDesc,
          category: settingsCategory,
          leading: const AppIcon(Icons.keyboard_outlined),
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.hotkeyManagement,
            const HotKeyView(),
          ),
        ),
      if (system.isWindows)
        _SearchItem(
          title: appLocalizations.loopback,
          subtitle: appLocalizations.loopbackDesc,
          category: settingsCategory,
          leading: const AppIcon(Icons.lock_outlined),
          onTap: (context, _) {
            windows?.runas(
              '"${join(dirname(Platform.resolvedExecutable), "WindowsLoopbackManager.exe")}"',
              '',
              showWindow: true,
            );
          },
        ),
      if (system.isAndroid)
        _SearchItem(
          title: appLocalizations.accessControl,
          subtitle: appLocalizations.accessControlDesc,
          category: settingsCategory,
          leading: const AppIcon(Icons.view_list_outlined),
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.appAccessControl,
            const AccessView(),
          ),
        ),
      _SearchItem(
        title: appLocalizations.basicConfig,
        subtitle: appLocalizations.basicConfigDesc,
        category: settingsCategory,
        leading: const AppIcon(Icons.developer_board_outlined),
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.basicConfig,
          const ConfigView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.otherSettings,
        subtitle: appLocalizations.otherSettingsDesc,
        category: settingsCategory,
        leading: const AppIcon(Icons.auto_fix_high_outlined),
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.otherSettings,
          const OtherSettingView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.application,
        subtitle: appLocalizations.applicationDesc,
        category: settingsCategory,
        leading: const AppIcon(Icons.settings_outlined),
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.application,
          const ApplicationSettingView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.disclaimer,
        category: otherCategory,
        leading: const AppIcon(Icons.gavel_outlined),
        onTap: (context, _) async {
          final accepted = await globalState.appController.showDisclaimer();
          if (!accepted) {
            unawaited(globalState.appController.handleExit());
          }
        },
      ),
      _SearchItem(
        title: appLocalizations.about,
        category: otherCategory,
        leading: const AppIcon(Icons.info_outline),
        onTap: (context, _) =>
            _pushPage(context, appLocalizations.about, const AboutView()),
      ),
      _SearchItem(
        title: appLocalizations.developerMode,
        category: otherCategory,
        leading: const AppIcon(Icons.developer_board_outlined),
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.developerMode,
          const DeveloperView(),
        ),
      ),
    ]);

    items.addAll([
      _SearchItem(
        title: appLocalizations.themeMode,
        category: themeCategory,
        onTap: (context, _) =>
            _pushPage(context, appLocalizations.theme, const ThemeView()),
      ),
      _SearchItem(
        title: appLocalizations.themeColor,
        category: themeCategory,
        onTap: (context, _) =>
            _pushPage(context, appLocalizations.theme, const ThemeView()),
      ),
      _SearchItem(
        title: appLocalizations.harmonyFont,
        subtitle: appLocalizations.harmonyFontDesc,
        category: themeCategory,
        onTap: (context, _) =>
            _pushPage(context, appLocalizations.theme, const ThemeView()),
      ),
      if (system.isWindows)
        _SearchItem(
          title: appLocalizations.trayIconInvert,
          subtitle: appLocalizations.trayIconInvertDesc,
          category: themeCategory,
          onTap: (context, _) =>
              _pushPage(context, appLocalizations.theme, const ThemeView()),
        ),
      _SearchItem(
        title: appLocalizations.textScale,
        category: themeCategory,
        onTap: (context, _) =>
            _pushPage(context, appLocalizations.theme, const ThemeView()),
      ),
    ]);

    items.addAll([
      _SearchItem(
        title: appLocalizations.remote,
        category: backupCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.backupAndRecovery,
          const BackupAndRecovery(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.local,
        category: backupCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.backupAndRecovery,
          const BackupAndRecovery(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.recoveryStrategy,
        category: backupCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.backupAndRecovery,
          const BackupAndRecovery(),
        ),
      ),
    ]);

    items.addAll([
      _SearchItem(
        title: appLocalizations.autoLaunch,
        subtitle: appLocalizations.autoLaunchDesc,
        category: appCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.application,
          const ApplicationSettingView(),
        ),
      ),
      if (system.isDesktop)
        _SearchItem(
          title: appLocalizations.silentLaunch,
          subtitle: appLocalizations.silentLaunchDesc,
          category: appCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.application,
            const ApplicationSettingView(),
          ),
        ),
      _SearchItem(
        title: appLocalizations.autoRun,
        subtitle: appLocalizations.autoRunDesc,
        category: appCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.application,
          const ApplicationSettingView(),
        ),
      ),
      if (system.isAndroid)
        _SearchItem(
          title: appLocalizations.exclude,
          subtitle: appLocalizations.excludeDesc,
          category: appCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.application,
            const ApplicationSettingView(),
          ),
        ),
      if (system.isDesktop && (system.isWindows || system.isLinux))
        _SearchItem(
          title: appLocalizations.alwaysShowTitleBar,
          subtitle: appLocalizations.alwaysShowTitleBarDesc,
          category: appCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.application,
            const ApplicationSettingView(),
          ),
        ),
      if (system.isMacOS)
        _SearchItem(
          title: appLocalizations.keepDockIcon,
          subtitle: appLocalizations.keepDockIconDesc,
          category: appCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.application,
            const ApplicationSettingView(),
          ),
        ),
      _SearchItem(
        title: appLocalizations.showStartSwitch,
        subtitle: appLocalizations.showStartSwitchDesc,
        category: appCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.application,
          const ApplicationSettingView(),
        ),
      ),
      if (system.isDesktop)
        _SearchItem(
          title: appLocalizations.sidebarFlyout,
          subtitle: appLocalizations.sidebarFlyoutDesc,
          category: appCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.application,
            const ApplicationSettingView(),
          ),
        ),
      if (system.isAndroid)
        _SearchItem(
          title: appLocalizations.navBarHapticFeedback,
          subtitle: appLocalizations.navBarHapticFeedbackDesc,
          category: appCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.application,
            const ApplicationSettingView(),
          ),
        ),
      if (system.isDesktop)
        _SearchItem(
          title: appLocalizations.autoCloseConnections,
          subtitle: appLocalizations.autoCloseConnectionsDesc,
          category: otherSettingsCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.otherSettings,
            const OtherSettingView(),
          ),
        ),
      _SearchItem(
        title: appLocalizations.onlyStatisticsProxy,
        subtitle: appLocalizations.onlyStatisticsProxyDesc,
        category: appCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.application,
          const ApplicationSettingView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.autoCheckUpdate,
        subtitle: appLocalizations.autoCheckUpdateDesc,
        category: appCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.application,
          const ApplicationSettingView(),
        ),
      ),
      if (appUpdater.isSupported)
        _SearchItem(
          title: appLocalizations.autoDownloadUpdate,
          subtitle: appLocalizations.autoDownloadUpdateDesc,
          category: appCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.application,
            const ApplicationSettingView(),
          ),
        ),
    ]);

    items.addAll([
      _SearchItem(
        title: appLocalizations.smartAutoStop,
        subtitle: appLocalizations.smartAutoStopDesc,
        category: otherSettingsCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.otherSettings,
          const OtherSettingView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.networkMatch,
        subtitle: appLocalizations.networkMatchHint,
        category: otherSettingsCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.otherSettings,
          const OtherSettingView(),
        ),
      ),
      if (system.isAndroid)
        _SearchItem(
          title: appLocalizations.dozeSuspend,
          subtitle: appLocalizations.dozeSuspendDesc,
          category: otherSettingsCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.otherSettings,
            const OtherSettingView(),
          ),
        ),
      if (system.isAndroid)
        _SearchItem(
          title: appLocalizations.quickResponse,
          subtitle: appLocalizations.quickResponseDesc,
          category: otherSettingsCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.otherSettings,
            const OtherSettingView(),
          ),
        ),
      if (system.isAndroid)
        _SearchItem(
          title: appLocalizations.storeFix,
          subtitle: appLocalizations.storeFixDesc,
          category: otherSettingsCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.otherSettings,
            const OtherSettingView(),
          ),
        ),
      _SearchItem(
        title: appLocalizations.loopbackProtection,
        subtitle: appLocalizations.loopbackProtectionDesc,
        category: otherSettingsCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.otherSettings,
          const OtherSettingView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.disableQuic,
        subtitle: appLocalizations.disableQuicDesc,
        category: otherSettingsCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.otherSettings,
          const OtherSettingView(),
        ),
      ),
      if (system.isAndroid)
        _SearchItem(
          title: appLocalizations.notificationHighPriority,
          subtitle: appLocalizations.notificationHighPriorityDesc,
          category: otherSettingsCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.otherSettings,
            const OtherSettingView(),
          ),
        ),
      if (system.isAndroid)
        _SearchItem(
          title: appLocalizations.networkSpeedNotification,
          subtitle: appLocalizations.networkSpeedNotificationDesc,
          category: otherSettingsCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.otherSettings,
            const OtherSettingView(),
          ),
        ),
      if (!system.isAndroid)
        _SearchItem(
          title: appLocalizations.trayEnhancement,
          subtitle: appLocalizations.trayEnhancementDesc,
          category: otherSettingsCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.otherSettings,
            const OtherSettingView(),
          ),
        ),
      if (system.isMacOS)
        _SearchItem(
          title: appLocalizations.enableTraySpeed,
          subtitle: appLocalizations.enableTraySpeedDesc,
          category: otherSettingsCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.otherSettings,
            const OtherSettingView(),
          ),
        ),
      if (system.isWindows)
        _SearchItem(
          title: appLocalizations.highPriority,
          subtitle: appLocalizations.highPriorityDesc,
          category: otherSettingsCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.otherSettings,
            const OtherSettingView(),
          ),
        ),
      if (system.isWindows)
        _SearchItem(
          title: appLocalizations.networkFix,
          subtitle: appLocalizations.networkFixDesc,
          category: otherSettingsCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.otherSettings,
            const OtherSettingView(),
          ),
        ),
      if (system.isAndroid)
        _SearchItem(
          title: appLocalizations.batteryOptimization,
          subtitle: appLocalizations.batteryOptimizationDesc,
          category: otherSettingsCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.otherSettings,
            const OtherSettingView(),
          ),
        ),
    ]);

    final generalCategory = '$configCategory/${appLocalizations.general}';
    items.addAll([
      _SearchItem(
        title: appLocalizations.logLevel,
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
      _SearchItem(
        title: 'UA',
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.keepAliveIntervalDesc,
        subtitle: appLocalizations.interval,
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.testUrl,
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.port,
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
      _SearchItem(
        title: 'IPv6',
        subtitle: appLocalizations.ipv6Desc,
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.allowLan,
        subtitle: appLocalizations.allowLanDesc,
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.unifiedDelay,
        subtitle: appLocalizations.unifiedDelayDesc,
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.findProcessMode,
        subtitle: appLocalizations.findProcessModeDesc,
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.tcpConcurrent,
        subtitle: appLocalizations.tcpConcurrentDesc,
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.externalController,
        subtitle: appLocalizations.externalControllerDesc,
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.controlSecret,
        subtitle: appLocalizations.controlSecretDesc,
        category: generalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.general,
          const _GeneralListView(),
        ),
      ),
    ]);

    final networkCategory = '$configCategory/${appLocalizations.network}';
    items.addAll([
      _SearchItem(
        title: 'VPN',
        subtitle: appLocalizations.vpnEnableDesc,
        category: networkCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.network,
          const NetworkListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.allowBypass,
        subtitle: appLocalizations.allowBypassDesc,
        category: networkCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.network,
          const NetworkListView(),
        ),
      ),
      if (system.isDesktop)
        _SearchItem(
          title: appLocalizations.systemProxy,
          subtitle: appLocalizations.systemProxyDesc,
          category: networkCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.network,
            const NetworkListView(),
          ),
        ),
      if (system.isDesktop)
        _SearchItem(
          title: appLocalizations.bypassDomain,
          subtitle: appLocalizations.bypassDomainDesc,
          category: networkCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.network,
            const NetworkListView(),
          ),
        ),
      if (system.isDesktop)
        _SearchItem(
          title: appLocalizations.tun,
          subtitle: appLocalizations.tunDesc,
          category: networkCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.network,
            const NetworkListView(),
          ),
        ),
      if (!system.isAndroid)
        _SearchItem(
          title: appLocalizations.strictRoute,
          subtitle: appLocalizations.strictRouteDesc,
          category: networkCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.network,
            const NetworkListView(),
          ),
        ),
      _SearchItem(
        title: appLocalizations.icmpForwarding,
        subtitle: appLocalizations.icmpForwardingDesc,
        category: networkCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.network,
          const NetworkListView(),
        ),
      ),
      if (system.isDesktop)
        _SearchItem(
          title: appLocalizations.dnsHijack,
          subtitle: appLocalizations.dnsHijackDesc,
          category: networkCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.network,
            const NetworkListView(),
          ),
        ),
      _SearchItem(
        title: appLocalizations.endpointIndependentNat,
        subtitle: appLocalizations.endpointIndependentNatDesc,
        category: networkCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.network,
          const NetworkListView(),
        ),
      ),
      if (system.isDesktop)
        _SearchItem(
          title: appLocalizations.networkInterface,
          category: networkCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.network,
            const NetworkListView(),
          ),
        ),
      if (AppIdentity.isStandard)
        _SearchItem(
          title: appLocalizations.stackMode,
          category: networkCategory,
          onTap: (context, _) => _pushPage(
            context,
            appLocalizations.network,
            const NetworkListView(),
          ),
        ),
      _SearchItem(
        title: 'MTU',
        category: networkCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.network,
          const NetworkListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.bypassPrivateRoute,
        subtitle: appLocalizations.bypassPrivateRouteDesc,
        category: networkCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.network,
          const NetworkListView(),
        ),
      ),
    ]);

    final ntpCategory = '$configCategory/NTP';
    items.addAll([
      _SearchItem(
        title: appLocalizations.overrideNtp,
        subtitle: appLocalizations.overrideNtpDesc,
        category: ntpCategory,
        onTap: (context, _) => _pushPage(context, 'NTP', const NtpListView()),
      ),
      _SearchItem(
        title: appLocalizations.ntpStatus,
        subtitle: appLocalizations.ntpStatusDesc,
        category: ntpCategory,
        onTap: (context, _) => _pushPage(context, 'NTP', const NtpListView()),
      ),
      _SearchItem(
        title: appLocalizations.writeToSystem,
        subtitle: appLocalizations.writeToSystemDesc,
        category: ntpCategory,
        onTap: (context, _) => _pushPage(context, 'NTP', const NtpListView()),
      ),
      _SearchItem(
        title: appLocalizations.ntpServer,
        category: ntpCategory,
        onTap: (context, _) => _pushPage(context, 'NTP', const NtpListView()),
      ),
      _SearchItem(
        title: appLocalizations.ntpPort,
        category: ntpCategory,
        onTap: (context, _) => _pushPage(context, 'NTP', const NtpListView()),
      ),
      _SearchItem(
        title: appLocalizations.ntpInterval,
        category: ntpCategory,
        onTap: (context, _) => _pushPage(context, 'NTP', const NtpListView()),
      ),
    ]);

    items.add(
      _SearchItem(
        title: 'Hosts',
        subtitle: appLocalizations.hostsDesc,
        category: '$configCategory/Hosts',
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.basicConfig,
          const ConfigView(),
        ),
      ),
    );

    final snifferCategory = '$configCategory/${appLocalizations.sniffer}';
    items.addAll([
      _SearchItem(
        title: appLocalizations.overrideSniffer,
        subtitle: appLocalizations.overrideSnifferDesc,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.snifferStatus,
        subtitle: appLocalizations.snifferStatusDesc,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.forceDnsMapping,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.parsePureIp,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.overrideDestination,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.httpPortSniffer,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.tlsPortSniffer,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.quicPortSniffer,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.forceDomain,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.skipDomain,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.skipSrcAddress,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.skipDstAddress,
        category: snifferCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.sniffer,
          const SnifferListView(),
        ),
      ),
    ]);

    items.add(
      _SearchItem(
        title: appLocalizations.tunnel,
        subtitle: appLocalizations.tunnelDesc,
        category: '$configCategory/${appLocalizations.tunnel}',
        onTap: (context, _) =>
            _pushPage(context, appLocalizations.tunnel, const TunnelListView()),
      ),
    );

    final experimentalCategory =
        '$configCategory/${appLocalizations.experimental}';
    items.addAll([
      _SearchItem(
        title: appLocalizations.overrideExperimental,
        subtitle: appLocalizations.overrideExperimentalDesc,
        category: experimentalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.experimental,
          const ExperimentalListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.quicGoDisableGso,
        category: experimentalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.experimental,
          const ExperimentalListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.quicGoDisableEcn,
        category: experimentalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.experimental,
          const ExperimentalListView(),
        ),
      ),
      _SearchItem(
        title: appLocalizations.dialerIp4pConvert,
        category: experimentalCategory,
        onTap: (context, _) => _pushPage(
          context,
          appLocalizations.experimental,
          const ExperimentalListView(),
        ),
      ),
    ]);

    return items;
  }

  List<Widget> _buildSearchResults(List<_SearchItem> items) {
    final query = _query.toLowerCase();
    final filtered = items.where((item) {
      return item.title.toLowerCase().contains(query) ||
          (item.subtitle?.toLowerCase().contains(query) ?? false) ||
          item.category.toLowerCase().contains(query);
    }).toList();

    if (filtered.isEmpty) {
      return [Center(child: NullStatus(label: appLocalizations.noData))];
    }

    final groups = <String, List<_SearchItem>>{};
    for (final item in filtered) {
      groups.putIfAbsent(item.category, () => []).add(item);
    }

    final sections = <Widget>[];
    for (final entry in groups.entries) {
      sections.add(
        _buildModernSection(
          context,
          title: entry.key,
          items: entry.value
              .map(
                (item) => ListItem(
                  leading: item.leading,
                  title: Text(item.title),
                  subtitle: item.subtitle != null ? Text(item.subtitle!) : null,
                  disableSplash: true,
                  onTap: () => item.onTap(context, ref),
                ),
              )
              .toList(),
        ),
      );
    }
    return sections;
  }

  @override
  Widget build(BuildContext context) {
    final vm2 = ref.watch(
      appSettingProvider.select(
        (state) => (a: state.locale, b: state.developerMode),
      ),
    );
    final isMobileView = ref.watch(isMobileViewProvider);
    final moreItems = ref.watch(
      moreToolsSelectorStateProvider.select((state) => state.navigationItems),
    );
    final logsItem = isMobileView && !globalState.isAndroidTV
        ? moreItems.where((item) => item.label == PageLabel.logs).firstOrNull
        : null;
    final searchItems = _getSearchItems(moreItems);
    final searchResults = _query.isEmpty
        ? const <Widget>[]
        : _buildSearchResults(searchItems);

    final items = [
      Consumer(
        builder: (_, ref, _) {
          final state = ref.watch(moreToolsSelectorStateProvider);
          final navigationItems = state.navigationItems
              .where((item) => logsItem == null || item.label != logsItem.label)
              .toList();
          if (navigationItems.isEmpty) {
            return Container();
          }
          return _buildModernSection(
            context,
            items: navigationItems
                .map((item) => _buildNavigationMenuItem(item))
                .toList(),
          );
        },
      ),
      _buildModernSection(
        context,
        title: appLocalizations.settings,
        items: [
          _LocaleItem(),
          _ThemeItem(),
          _BackupItem(),
          if (system.isDesktop) _HotkeyItem(),
          if (system.isWindows) _LoopbackItem(),
          if (system.isAndroid) _AccessItem(),
          _ConfigItem(),
          _OtherSettingItem(),
          _SettingItem(),
        ],
      ),
      _buildModernSection(
        context,
        title: appLocalizations.other,
        items: [_DisclaimerItem(), if (vm2.b) _DeveloperItem(), _InfoItem()],
      ),
    ];

    return CommonScaffold(
      title: isMobileView ? appLocalizations.tools : appLocalizations.settings,
      searchState: AppBarSearchState(onSearch: _onSearchChanged),
      actions: [
        if (logsItem != null)
          IconButton(
            onPressed: () => showExtend(
              context,
              props: const ExtendProps(forceFull: true),
              builder: (_, _) => _buildNavigationPage(logsItem),
            ),
            icon: logsItem.icon,
            tooltip: Intl.message(logsItem.label.name),
          ),
      ],
      body: ScrollEdgeRise(
        builder: (context, rise) => ListView.builder(
          key: _query.isEmpty ? toolsStoreKey : null,
          itemCount: _query.isEmpty ? items.length : searchResults.length,
          itemBuilder: (_, index) {
            return _query.isEmpty ? items[index] : searchResults[index];
          },
          padding: EdgeInsets.only(
            bottom:
                20.0 +
                (isMobileView ? getFloatingBottomBarReserveHeight(context) : 0),
            top: 8 + rise,
          ),
        ),
      ),
    );
  }
}

class _LocaleItem extends ConsumerWidget implements HasLeadingWidget {
  const _LocaleItem();

  @override
  bool get hasLeading => true;

  static final List<Locale> _localeOptions = _getOrderedLocales();
  static const Map<String, String> _nativeLocaleNames = {
    'zh_CN': '简体中文',
    'zh_TC': '繁體中文',
    'en': 'English',
    'ru': 'Русский',
    'fa': 'فارسی',
    'ja': '日本語',
    'ko': '한국어',
  };

  static List<Locale> _getOrderedLocales() {
    final priority = ['zh_CN', 'zh_TC', 'en', 'ru', 'fa', 'ja', 'ko'];
    final locales = List<Locale>.from(
      AppLocalizations.delegate.supportedLocales,
    );
    locales.sort((a, b) {
      final aKey = a.toString();
      final bKey = b.toString();
      final aIndex = priority.indexOf(aKey);
      final bIndex = priority.indexOf(bKey);
      if (aIndex != -1 && bIndex != -1) return aIndex.compareTo(bIndex);
      if (aIndex != -1) return -1;
      if (bIndex != -1) return 1;
      return aKey.compareTo(bKey);
    });
    return locales;
  }

  String _getLocaleString(Locale locale) {
    return _nativeLocaleNames[locale.toString()] ?? locale.toString();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(
      appSettingProvider.select((state) => state.locale),
    );
    final currentLocale =
        utils.getLocaleForString(locale) ?? utils.getSystemLocale();
    return ListItem<Locale>.options(
      leading: const AppIcon(Icons.language_outlined),
      title: Text(appLocalizations.language),
      subtitle: Text(_getLocaleString(currentLocale)),
      delegate: OptionsDelegate(
        title: appLocalizations.language,
        options: _localeOptions,
        onChanged: (Locale? locale) {
          if (locale == null) return;
          ref
              .read(appSettingProvider.notifier)
              .updateState(
                (state) => state.copyWith(locale: locale.toString()),
              );
        },
        textBuilder: (locale) => _getLocaleString(locale),
        value: currentLocale,
      ),
    );
  }
}

abstract class _ToolsItem extends StatelessWidget implements HasLeadingWidget {
  const _ToolsItem();

  @override
  bool get hasLeading => true;
}

class _ThemeItem extends _ToolsItem {
  const _ThemeItem();

  @override
  Widget build(BuildContext context) {
    return ListItem.next(
      leading: const AppIcon(Icons.style_outlined),
      title: Text(appLocalizations.theme),
      subtitle: Text(appLocalizations.themeDesc),
      delegate: NextDelegate(
        title: appLocalizations.theme,
        builder: (_) => const ThemeView(),
      ),
    );
  }
}

class _BackupItem extends _ToolsItem {
  const _BackupItem();

  @override
  Widget build(BuildContext context) {
    return ListItem.next(
      leading: const AppIcon(Icons.cloud_sync_outlined),
      title: Text(appLocalizations.backupAndRecovery),
      subtitle: Text(appLocalizations.backupAndRecoveryDesc),
      delegate: NextDelegate(
        title: appLocalizations.backupAndRecovery,
        builder: (_) => const BackupAndRecovery(),
      ),
    );
  }
}

class _HotkeyItem extends _ToolsItem {
  const _HotkeyItem();

  @override
  Widget build(BuildContext context) {
    return ListItem.next(
      leading: const AppIcon(Icons.keyboard_outlined),
      title: Text(appLocalizations.hotkeyManagement),
      subtitle: Text(appLocalizations.hotkeyManagementDesc),
      delegate: NextDelegate(
        title: appLocalizations.hotkeyManagement,
        builder: (_) => const HotKeyView(),
      ),
    );
  }
}

class _LoopbackItem extends _ToolsItem {
  const _LoopbackItem();

  @override
  Widget build(BuildContext context) {
    return ListItem(
      leading: const AppIcon(Icons.lock_outlined),
      title: Text(appLocalizations.loopback),
      subtitle: Text(appLocalizations.loopbackDesc),
      onTap: () {
        windows?.runas(
          '"${join(dirname(Platform.resolvedExecutable), "WindowsLoopbackManager.exe")}"',
          '',
          showWindow: true,
        );
      },
    );
  }
}

class _AccessItem extends _ToolsItem {
  const _AccessItem();

  @override
  Widget build(BuildContext context) {
    return ListItem.next(
      leading: const AppIcon(Icons.view_list_outlined),
      title: Text(appLocalizations.accessControl),
      subtitle: Text(appLocalizations.accessControlDesc),
      delegate: NextDelegate(
        title: appLocalizations.appAccessControl,
        builder: (_) => const AccessView(),
      ),
    );
  }
}

class _ConfigItem extends _ToolsItem {
  const _ConfigItem();

  @override
  Widget build(BuildContext context) {
    return ListItem.next(
      leading: const AppIcon(Icons.developer_board_outlined),
      title: Text(appLocalizations.basicConfig),
      subtitle: Text(appLocalizations.basicConfigDesc),
      delegate: NextDelegate(
        title: appLocalizations.basicConfig,
        builder: (_) => const ConfigView(),
      ),
    );
  }
}

class _OtherSettingItem extends _ToolsItem {
  const _OtherSettingItem();

  @override
  Widget build(BuildContext context) {
    return ListItem.next(
      leading: const AppIcon(Icons.auto_fix_high_outlined),
      title: Text(appLocalizations.otherSettings),
      subtitle: Text(appLocalizations.otherSettingsDesc),
      delegate: NextDelegate(
        title: appLocalizations.otherSettings,
        builder: (_) => const OtherSettingView(),
      ),
    );
  }
}

class _SettingItem extends _ToolsItem {
  const _SettingItem();

  @override
  Widget build(BuildContext context) {
    return ListItem.next(
      leading: const AppIcon(Icons.settings_outlined),
      title: Text(appLocalizations.application),
      subtitle: Text(appLocalizations.applicationDesc),
      delegate: NextDelegate(
        title: appLocalizations.application,
        builder: (_) => const ApplicationSettingView(),
      ),
    );
  }
}

class _DisclaimerItem extends _ToolsItem {
  const _DisclaimerItem();

  @override
  Widget build(BuildContext context) {
    return ListItem(
      leading: const AppIcon(Icons.gavel_outlined),
      title: Text(appLocalizations.disclaimer),
      onTap: () async {
        final isDisclaimerAccepted = await globalState.appController
            .showDisclaimer();
        if (!isDisclaimerAccepted) {
          unawaited(globalState.appController.handleExit());
        }
      },
    );
  }
}

class _InfoItem extends _ToolsItem {
  const _InfoItem();

  @override
  Widget build(BuildContext context) {
    return ListItem.next(
      leading: const AppIcon(Icons.info_outline),
      title: Text(appLocalizations.about),
      delegate: NextDelegate(
        title: appLocalizations.about,
        builder: (_) => const AboutView(),
      ),
    );
  }
}

class _DeveloperItem extends _ToolsItem {
  const _DeveloperItem();

  @override
  Widget build(BuildContext context) {
    return ListItem.next(
      leading: const AppIcon(Icons.developer_board_outlined),
      title: Text(appLocalizations.developerMode),
      delegate: NextDelegate(
        title: appLocalizations.developerMode,
        builder: (_) => const DeveloperView(),
      ),
    );
  }
}

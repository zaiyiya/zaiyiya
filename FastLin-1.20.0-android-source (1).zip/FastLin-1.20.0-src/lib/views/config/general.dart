import 'package:bett_box/common/common.dart';
import 'package:bett_box/enum/enum.dart';
import 'package:bett_box/models/models.dart';
import 'package:bett_box/providers/providers.dart';
import 'package:bett_box/state.dart';
import 'package:bett_box/views/config/network.dart';
import 'package:bett_box/views/config/user_auth.dart';
import 'package:bett_box/widgets/widgets.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

class LogLevelItem extends ConsumerWidget {
  const LogLevelItem({super.key});

  @override
  Widget build(BuildContext context, ref) {
    final logLevel = ref.watch(
      patchClashConfigProvider.select((state) => state.logLevel),
    );
    return ListItem<LogLevel>.options(
      leading: const AppIcon(Icons.info_outline),
      title: Text(appLocalizations.logLevel),
      subtitle: Text(logLevel.label),
      delegate: OptionsDelegate<LogLevel>(
        title: appLocalizations.logLevel,
        options: LogLevel.values,
        onChanged: (LogLevel? value) {
          if (value == null) {
            return;
          }
          ref
              .read(patchClashConfigProvider.notifier)
              .updateState((state) => state.copyWith(logLevel: value));
        },
        textBuilder: (logLevel) => logLevel.label,
        value: logLevel,
      ),
    );
  }
}

class UaItem extends ConsumerStatefulWidget {
  const UaItem({super.key});

  @override
  ConsumerState<UaItem> createState() => _UaItemState();
}

class _UaItemState extends ConsumerState<UaItem> {
  String _lastCustomUa = '';

  @override
  Widget build(BuildContext context) {
    final globalUa = ref.watch(
      patchClashConfigProvider.select((state) => state.globalUa),
    );
    final isCustom = globalUa != null;

    if (isCustom) {
      _lastCustomUa = globalUa;
    }

    return ListItem(
      leading: const AppIcon(Icons.computer_outlined),
      title: const Text('UA'),
      subtitle: Text(
        isCustom ? appLocalizations.custom : appLocalizations.defaultText,
      ),
      onTap: () async {
        final result = await pickUserAgent(
          current: globalUa,
          customValue: _lastCustomUa,
        );
        if (result == null || !mounted) return;
        ref
            .read(patchClashConfigProvider.notifier)
            .updateState((state) => state.copyWith(globalUa: result.value));
      },
    );
  }
}

class KeepAliveIntervalItem extends ConsumerWidget {
  const KeepAliveIntervalItem({super.key});

  @override
  Widget build(BuildContext context, ref) {
    final keepAliveInterval = ref.watch(
      patchClashConfigProvider.select((state) => state.keepAliveInterval),
    );
    return ListItem.input(
      leading: const AppIcon(Icons.timer_outlined),
      title: Text(appLocalizations.keepAliveIntervalDesc),
      subtitle: Text('$keepAliveInterval ${appLocalizations.seconds}'),
      delegate: InputDelegate(
        title: appLocalizations.keepAliveIntervalDesc,
        suffixText: appLocalizations.seconds,
        resetValue: '$defaultKeepAliveInterval',
        value: '$keepAliveInterval',
        validator: (String? value) {
          if (value == null || value.isEmpty) {
            return appLocalizations.emptyTip(appLocalizations.interval);
          }
          final intValue = int.tryParse(value);
          if (intValue == null) {
            return appLocalizations.numberTip(appLocalizations.interval);
          }
          return null;
        },
        onChanged: (String? value) {
          if (value == null) {
            return;
          }
          final intValue = int.parse(value);
          ref
              .read(patchClashConfigProvider.notifier)
              .updateState(
                (state) => state.copyWith(keepAliveInterval: intValue),
              );
        },
      ),
    );
  }
}

class TestUrlItem extends ConsumerWidget {
  const TestUrlItem({super.key});

  @override
  Widget build(BuildContext context, ref) {
    final testUrl = ref.watch(
      appSettingProvider.select((state) => state.testUrl),
    );

    return ListItem(
      leading: const AppIcon(Icons.timeline),
      title: Text(appLocalizations.testUrl),
      subtitle: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Text(testUrl),
      ),
      onTap: () async {
        await globalState.showAdaptiveSheet(
          child: _TestUrlDialog(currentUrl: testUrl),
        );
      },
    );
  }
}

class _TestUrlDialog extends ConsumerWidget {
  final String currentUrl;

  const _TestUrlDialog({required this.currentUrl});

  @override
  Widget build(BuildContext context, ref) {
    final isPresetUrl = presetTestUrls.contains(currentUrl);

    return CommonDialog(
      title: appLocalizations.testUrl,
      padding: const EdgeInsets.fromLTRB(10, 12, 10, 14),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (final url in presetTestUrls)
            OptionItem(
              text: url,
              selected: currentUrl == url,
              onTap: () async {
                ref
                    .read(appSettingProvider.notifier)
                    .updateState((state) => state.copyWith(testUrl: url));
                if (context.mounted) {
                  Navigator.of(context, rootNavigator: true).pop();
                }
              },
            ),
          OptionItem(
            text: appLocalizations.customUrl,
            selected: !isPresetUrl,
            onTap: () async {
              final notifier = ref.read(appSettingProvider.notifier);
              Navigator.of(context, rootNavigator: true).pop();
              final customUrl = await globalState.showCommonDialog<String>(
                child: InputDialog(
                  title: appLocalizations.customUrl,
                  value: isPresetUrl ? '' : currentUrl,
                  resetValue: defaultTestUrl,
                  validator: (String? inputValue) {
                    if (inputValue == null || inputValue.isEmpty) {
                      return appLocalizations.emptyTip(
                        appLocalizations.testUrl,
                      );
                    }
                    if (!inputValue.isHttpUrl) {
                      return appLocalizations.urlTip(appLocalizations.testUrl);
                    }
                    return null;
                  },
                ),
              );

              if (customUrl != null) {
                notifier.updateState(
                  (state) => state.copyWith(testUrl: customUrl),
                );
              }
            },
          ),
        ],
      ),
    );
  }
}

class PortItem extends ConsumerWidget {
  const PortItem({super.key});

  Future<void> handleShowPortDialog() async {
    await globalState.showCommonDialog(child: _PortDialog());
    // inputDelegate.onChanged(value);
  }

  @override
  Widget build(BuildContext context, ref) {
    final mixedPort = ref.watch(
      patchClashConfigProvider.select((state) => state.mixedPort),
    );
    return ListItem(
      leading: const AppIcon(Icons.adjust_outlined),
      title: Text(appLocalizations.port),
      subtitle: Text('$mixedPort'),
      onTap: () {
        handleShowPortDialog();
      },
    );
  }
}

class Ipv6Item extends ConsumerWidget {
  const Ipv6Item({super.key});

  @override
  Widget build(BuildContext context, ref) {
    final ipv6 = ref.watch(
      patchClashConfigProvider.select((state) => state.ipv6),
    );
    return ListItem.switchItem(
      leading: const AppIcon(Icons.filter_6_rounded),
      title: const Text('IPv6'),
      subtitle: Text(appLocalizations.ipv6Desc),
      delegate: SwitchDelegate(
        value: ipv6,
        onChanged: (bool value) async {
          ref
              .read(patchClashConfigProvider.notifier)
              .updateState((state) => state.copyWith(ipv6: value));
          showVpnRestartTip(ref);
        },
      ),
    );
  }
}

class AllowLanItem extends ConsumerWidget {
  const AllowLanItem({super.key});

  Future<void> _showUserAuthDialog() async {
    await globalState.showCommonDialog(child: const UserAuthDialog());
  }

  @override
  Widget build(BuildContext context, ref) {
    final allowLan = ref.watch(
      patchClashConfigProvider.select((state) => state.allowLan),
    );
    return ListItem.switchItem(
      leading: const AppIcon(Icons.device_hub),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(appLocalizations.allowLan),
          Tooltip(
            message: appLocalizations.userAuth,
            child: Material(
              color: Colors.transparent,
              child: InkResponse(
                radius: 16,
                highlightShape: BoxShape.circle,
                onTap: _showUserAuthDialog,
                child: Padding(
                  padding: const EdgeInsets.all(7),
                  child: AppIcon(
                    Icons.settings_outlined,
                    size: 18,
                    color: context.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      subtitle: Text(appLocalizations.allowLanDesc),
      delegate: SwitchDelegate(
        value: allowLan,
        onChanged: (bool value) async {
          ref
              .read(patchClashConfigProvider.notifier)
              .updateState((state) => state.copyWith(allowLan: value));
        },
      ),
    );
  }
}

class UnifiedDelayItem extends ConsumerWidget {
  const UnifiedDelayItem({super.key});

  @override
  Widget build(BuildContext context, ref) {
    final unifiedDelay = ref.watch(
      patchClashConfigProvider.select((state) => state.unifiedDelay),
    );

    return ListItem.switchItem(
      leading: const AppIcon(Icons.compress_outlined),
      title: Text(appLocalizations.unifiedDelay),
      subtitle: Text(appLocalizations.unifiedDelayDesc),
      delegate: SwitchDelegate(
        value: unifiedDelay,
        onChanged: (bool value) async {
          ref
              .read(patchClashConfigProvider.notifier)
              .updateState((state) => state.copyWith(unifiedDelay: value));
        },
      ),
    );
  }
}

class FindProcessItem extends ConsumerWidget {
  const FindProcessItem({super.key});

  @override
  Widget build(BuildContext context, ref) {
    final findProcessMode = ref.watch(
      patchClashConfigProvider.select((state) => state.findProcessMode),
    );

    return ListItem<FindProcessMode>.options(
      leading: const AppIcon(Icons.polymer_outlined),
      title: Text(appLocalizations.findProcessMode),
      subtitle: Text(_label(findProcessMode)),
      delegate: OptionsDelegate<FindProcessMode>(
        title: appLocalizations.findProcessMode,
        options: FindProcessMode.values,
        onChanged: (FindProcessMode? value) {
          if (value == null) {
            return;
          }
          ref
              .read(patchClashConfigProvider.notifier)
              .updateState((state) => state.copyWith(findProcessMode: value));
        },
        textBuilder: _label,
        subtitleBuilder: (mode) => switch (mode) {
          FindProcessMode.always => appLocalizations.findProcessAlwaysDesc,
          FindProcessMode.strict => appLocalizations.findProcessStrictDesc,
          FindProcessMode.off => appLocalizations.findProcessOffDesc,
        },
        value: findProcessMode,
      ),
    );
  }

  static String _label(FindProcessMode mode) => switch (mode) {
    FindProcessMode.always => appLocalizations.findProcessAlways,
    FindProcessMode.strict => appLocalizations.findProcessStrict,
    FindProcessMode.off => appLocalizations.findProcessOff,
  };
}

class TcpConcurrentItem extends ConsumerWidget {
  const TcpConcurrentItem({super.key});

  @override
  Widget build(BuildContext context, ref) {
    final tcpConcurrent = ref.watch(
      patchClashConfigProvider.select((state) => state.tcpConcurrent),
    );
    return ListItem.switchItem(
      leading: const AppIcon(Icons.double_arrow_outlined),
      title: Text(appLocalizations.tcpConcurrent),
      subtitle: Text(appLocalizations.tcpConcurrentDesc),
      delegate: SwitchDelegate(
        value: tcpConcurrent,
        onChanged: (value) async {
          ref
              .read(patchClashConfigProvider.notifier)
              .updateState((state) => state.copyWith(tcpConcurrent: value));
        },
      ),
    );
  }
}

class ExternalControllerItem extends ConsumerWidget {
  const ExternalControllerItem({super.key});

  @override
  Widget build(BuildContext context, ref) {
    final hasExternalController = ref.watch(
      patchClashConfigProvider.select(
        (state) => state.externalController == ExternalControllerStatus.open,
      ),
    );
    final secret = hasExternalController
        ? ref.watch(patchClashConfigProvider.select((state) => state.secret)) ??
              ''
        : '';
    final port = ref.watch(
      patchClashConfigProvider.select((state) => state.externalControllerPort),
    );

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ListItem.switchItem(
          leading: const AppIcon(Icons.api_outlined),
          title: Text(appLocalizations.externalController),
          subtitle: Text(appLocalizations.externalControllerDesc),
          delegate: SwitchDelegate(
            value: hasExternalController,
            onChanged: (bool value) async {
              if (value) {
                final newSecret = utils.generateSecret();
                ref
                    .read(patchClashConfigProvider.notifier)
                    .updateState(
                      (state) => state.copyWith(
                        externalController: ExternalControllerStatus.open,
                        secret: newSecret,
                      ),
                    );
                await globalState.appController.applyProfile();
              } else {
                ref
                    .read(patchClashConfigProvider.notifier)
                    .updateState(
                      (state) => state.copyWith(
                        externalController: ExternalControllerStatus.close,
                      ),
                    );
                await globalState.appController.applyProfile();
              }
            },
          ),
        ),
        if (hasExternalController) ...[
          Divider(
            height: 1,
            thickness: 1,
            color: context.colorScheme.outlineVariant.withValues(
              alpha: context.colorScheme.brightness == Brightness.light
                  ? 0.6
                  : 0.45,
            ),
            indent: 16,
            endIndent: 16,
          ),
          ListItem(
            leading: const AppIcon(Icons.password_outlined),
            title: Text(appLocalizations.controlSecret),
            subtitle: Text(
              secret.isEmpty ? appLocalizations.controlSecretDesc : secret,
            ),
            trailing: secret.isNotEmpty
                ? Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const AppIcon(Icons.open_in_new),
                        tooltip: appLocalizations.onlinePanel,
                        onPressed: () async {
                          final uri = Uri.parse(
                            'http://127.0.0.1:$port/ui/#/setup?hostname=127.0.0.1&port=$port&secret=$secret',
                          );
                          if (await canLaunchUrl(uri)) {
                            await launchUrl(
                              uri,
                              mode: LaunchMode.externalApplication,
                            );
                          }
                        },
                      ),
                      IconButton(
                        icon: const AppIcon(Icons.copy),
                        tooltip: appLocalizations.copy,
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: secret));
                          if (context.mounted) {
                            context.showSnackBar(appLocalizations.secretCopied);
                          }
                        },
                      ),
                    ],
                  )
                : null,
            onTap: () async {
              await globalState.showCommonDialog(
                child: _SecretDialog(currentSecret: secret),
              );
            },
          ),
        ],
      ],
    );
  }
}

class _SecretDialog extends ConsumerStatefulWidget {
  final String currentSecret;

  const _SecretDialog({required this.currentSecret});

  @override
  ConsumerState<_SecretDialog> createState() => _SecretDialogState();
}

class _SecretDialogState extends ConsumerState<_SecretDialog> {
  late TextEditingController _controller;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.currentSecret);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _handleSave() async {
    if (_formKey.currentState?.validate() == false) return;
    ref
        .read(patchClashConfigProvider.notifier)
        .updateState((state) => state.copyWith(secret: _controller.text));
    Navigator.of(context).pop();
    // Apply config after manual password change
    await globalState.appController.applyProfile();
  }

  @override
  Widget build(BuildContext context) {
    return CommonDialog(
      title: appLocalizations.controlSecret,
      actions: [
        TextButton(onPressed: _handleSave, child: Text(appLocalizations.save)),
      ],
      child: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.only(top: 8),
          child: TvTextField(
            builder: (tv) => TextFormField(
              focusNode: tv.focusNode,
              readOnly: tv.readOnly,
              showCursor: tv.showCursor,
              controller: _controller,
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                labelText: appLocalizations.controlSecret,
                hintText: appLocalizations.controlSecretDesc,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

List<Widget> get generalItems => generateSection(
  items: [
    const LogLevelItem(),
    const UaItem(),
    if (system.isDesktop) const KeepAliveIntervalItem(),
    const TestUrlItem(),
    const PortItem(),
    const FindProcessItem(),
    const Ipv6Item(),
    const AllowLanItem(),
    const UnifiedDelayItem(),
    const TcpConcurrentItem(),
    const ExternalControllerItem(),
  ],
);

class GeneralListView extends StatelessWidget {
  const GeneralListView({super.key});

  @override
  Widget build(BuildContext context) {
    return generateListView(generalItems);
  }
}

class _PortDialog extends ConsumerStatefulWidget {
  const _PortDialog();

  @override
  ConsumerState<_PortDialog> createState() => _PortDialogState();
}

class _PortDialogState extends ConsumerState<_PortDialog> {
  final _formKey = GlobalKey<FormState>();
  bool _isMore = false;

  late TextEditingController _mixedPortController;
  late TextEditingController _portController;
  late TextEditingController _socksPortController;
  late TextEditingController _redirPortController;
  late TextEditingController _tProxyPortController;
  late TextEditingController _externalControllerPortController;

  @override
  void initState() {
    super.initState();
    final vm5 = ref.read(
      patchClashConfigProvider.select((state) {
        return (
          a: state.mixedPort,
          b: state.port,
          c: state.socksPort,
          d: state.redirPort,
          e: state.tproxyPort,
          f: state.externalControllerPort,
        );
      }),
    );
    _mixedPortController = TextEditingController(text: vm5.a.toString());
    _portController = TextEditingController(text: vm5.b.toString());
    _socksPortController = TextEditingController(text: vm5.c.toString());
    _redirPortController = TextEditingController(text: vm5.d.toString());
    _tProxyPortController = TextEditingController(text: vm5.e.toString());
    _externalControllerPortController = TextEditingController(
      text: vm5.f.toString(),
    );
  }

  @override
  void dispose() {
    _mixedPortController.dispose();
    _portController.dispose();
    _socksPortController.dispose();
    _redirPortController.dispose();
    _tProxyPortController.dispose();
    _externalControllerPortController.dispose();
    super.dispose();
  }

  Future<void> _handleReset() async {
    final res = await globalState.showMessage(
      message: TextSpan(text: appLocalizations.resetTip),
    );
    if (res != true || !mounted) {
      return;
    }
    ref
        .read(patchClashConfigProvider.notifier)
        .updateState(
          (state) => state.copyWith(
            mixedPort: 7890,
            port: 0,
            socksPort: 0,
            redirPort: 0,
            tproxyPort: 0,
            externalControllerPort: defaultExternalControllerPort,
          ),
        );
    if (mounted) {
      Navigator.of(context).pop();
    }
  }

  void _handleUpdate() {
    if (_formKey.currentState?.validate() == false) return;
    ref
        .read(patchClashConfigProvider.notifier)
        .updateState(
          (state) => state.copyWith(
            mixedPort: int.parse(_mixedPortController.text),
            port: int.parse(_portController.text),
            socksPort: int.parse(_socksPortController.text),
            redirPort: int.parse(_redirPortController.text),
            tproxyPort: int.parse(_tProxyPortController.text),
            externalControllerPort: int.parse(
              _externalControllerPortController.text,
            ),
          ),
        );
    Navigator.of(context).pop();
  }

  void _handleMore() {
    setState(() {
      _isMore = !_isMore;
    });
  }

  @override
  Widget build(BuildContext context) {
    return CommonDialog(
      title: appLocalizations.port,
      actions: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton.filledTonal(
              onPressed: _handleMore,
              icon: CommonExpandIcon(expand: _isMore),
            ),
            Row(
              children: [
                TextButton(
                  onPressed: _handleReset,
                  child: Text(appLocalizations.reset),
                ),
                const SizedBox(width: 4),
                TextButton(
                  onPressed: _handleUpdate,
                  child: Text(appLocalizations.submit),
                ),
              ],
            ),
          ],
        ),
      ],
      child: Form(
        autovalidateMode: AutovalidateMode.onUserInteraction,
        key: _formKey,
        child: Padding(
          padding: EdgeInsets.only(top: 8),
          child: AnimatedSize(
            duration: midDuration,
            curve: Curves.easeOutQuad,
            alignment: Alignment.topCenter,
            child: Column(
              spacing: 24,
              children: [
                TvTextField(
                  builder: (tv) => TextFormField(
                    focusNode: tv.focusNode,
                    readOnly: tv.readOnly,
                    showCursor: tv.showCursor,
                    keyboardType: TextInputType.url,
                    maxLines: 1,
                    minLines: 1,
                    controller: _mixedPortController,
                    onFieldSubmitted: (_) {
                      _handleUpdate();
                    },
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: appLocalizations.mixedPort,
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return appLocalizations.emptyTip(
                          appLocalizations.mixedPort,
                        );
                      }
                      final port = int.tryParse(value);
                      if (port == null) {
                        return appLocalizations.numberTip(
                          appLocalizations.mixedPort,
                        );
                      }
                      if (port == 0) {
                        return null;
                      }
                      if (port < 1024 || port > 49151) {
                        return appLocalizations.portTip(
                          appLocalizations.mixedPort,
                        );
                      }
                      final ports = [
                        _portController.text,
                        _socksPortController.text,
                        _tProxyPortController.text,
                        _redirPortController.text,
                        _externalControllerPortController.text,
                      ].map((item) => item.trim());
                      if (ports.contains(value.trim())) {
                        return appLocalizations.portConflictTip;
                      }
                      return null;
                    },
                  ),
                ),
                TvTextField(
                  builder: (tv) => TextFormField(
                    focusNode: tv.focusNode,
                    readOnly: tv.readOnly,
                    showCursor: tv.showCursor,
                    keyboardType: TextInputType.url,
                    maxLines: 1,
                    minLines: 1,
                    controller: _externalControllerPortController,
                    onFieldSubmitted: (_) {
                      _handleUpdate();
                    },
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      labelText: appLocalizations.externalControllerPort,
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return appLocalizations.emptyTip(
                          appLocalizations.externalControllerPort,
                        );
                      }
                      final port = int.tryParse(value);
                      if (port == null) {
                        return appLocalizations.numberTip(
                          appLocalizations.externalControllerPort,
                        );
                      }
                      if (port < 1024 || port > 49151) {
                        return appLocalizations.portTip(
                          appLocalizations.externalControllerPort,
                        );
                      }
                      final ports = [
                        _mixedPortController.text,
                        _portController.text,
                        _socksPortController.text,
                        _tProxyPortController.text,
                        _redirPortController.text,
                      ].map((item) => item.trim());
                      if (ports.contains(value.trim())) {
                        return appLocalizations.portConflictTip;
                      }
                      return null;
                    },
                  ),
                ),
                if (_isMore) ...[
                  TvTextField(
                    builder: (tv) => TextFormField(
                      focusNode: tv.focusNode,
                      readOnly: tv.readOnly,
                      showCursor: tv.showCursor,
                      keyboardType: TextInputType.url,
                      maxLines: 1,
                      minLines: 1,
                      controller: _portController,
                      onFieldSubmitted: (_) {
                        _handleUpdate();
                      },
                      decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        labelText: appLocalizations.port,
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return appLocalizations.emptyTip(
                            appLocalizations.port,
                          );
                        }
                        final port = int.tryParse(value);
                        if (port == null) {
                          return appLocalizations.numberTip(
                            appLocalizations.port,
                          );
                        }
                        if (port == 0) {
                          return null;
                        }
                        if (port < 1024 || port > 49151) {
                          return appLocalizations.portTip(
                            appLocalizations.port,
                          );
                        }
                        final ports = [
                          _mixedPortController.text,
                          _socksPortController.text,
                          _tProxyPortController.text,
                          _redirPortController.text,
                          _externalControllerPortController.text,
                        ].map((item) => item.trim());
                        if (ports.contains(value.trim())) {
                          return appLocalizations.portConflictTip;
                        }
                        return null;
                      },
                    ),
                  ),
                  TvTextField(
                    builder: (tv) => TextFormField(
                      focusNode: tv.focusNode,
                      readOnly: tv.readOnly,
                      showCursor: tv.showCursor,
                      keyboardType: TextInputType.url,
                      maxLines: 1,
                      minLines: 1,
                      controller: _socksPortController,
                      onFieldSubmitted: (_) {
                        _handleUpdate();
                      },
                      decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        labelText: appLocalizations.socksPort,
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return appLocalizations.emptyTip(
                            appLocalizations.socksPort,
                          );
                        }
                        final port = int.tryParse(value);
                        if (port == null) {
                          return appLocalizations.numberTip(
                            appLocalizations.socksPort,
                          );
                        }
                        if (port == 0) {
                          return null;
                        }
                        if (port < 1024 || port > 49151) {
                          return appLocalizations.portTip(
                            appLocalizations.socksPort,
                          );
                        }
                        final ports = [
                          _portController.text,
                          _mixedPortController.text,
                          _tProxyPortController.text,
                          _redirPortController.text,
                          _externalControllerPortController.text,
                        ].map((item) => item.trim());
                        if (ports.contains(value.trim())) {
                          return appLocalizations.portConflictTip;
                        }
                        return null;
                      },
                    ),
                  ),
                  TvTextField(
                    builder: (tv) => TextFormField(
                      focusNode: tv.focusNode,
                      readOnly: tv.readOnly,
                      showCursor: tv.showCursor,
                      keyboardType: TextInputType.url,
                      maxLines: 1,
                      minLines: 1,
                      controller: _redirPortController,
                      onFieldSubmitted: (_) {
                        _handleUpdate();
                      },
                      decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        labelText: appLocalizations.redirPort,
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return appLocalizations.emptyTip(
                            appLocalizations.redirPort,
                          );
                        }
                        final port = int.tryParse(value);
                        if (port == null) {
                          return appLocalizations.numberTip(
                            appLocalizations.redirPort,
                          );
                        }
                        if (port == 0) {
                          return null;
                        }
                        if (port < 1024 || port > 49151) {
                          return appLocalizations.portTip(
                            appLocalizations.redirPort,
                          );
                        }
                        final ports = [
                          _portController.text,
                          _socksPortController.text,
                          _tProxyPortController.text,
                          _mixedPortController.text,
                          _externalControllerPortController.text,
                        ].map((item) => item.trim());
                        if (ports.contains(value.trim())) {
                          return appLocalizations.portConflictTip;
                        }
                        return null;
                      },
                    ),
                  ),
                  TvTextField(
                    builder: (tv) => TextFormField(
                      focusNode: tv.focusNode,
                      readOnly: tv.readOnly,
                      showCursor: tv.showCursor,
                      keyboardType: TextInputType.url,
                      maxLines: 1,
                      minLines: 1,
                      controller: _tProxyPortController,
                      onFieldSubmitted: (_) {
                        _handleUpdate();
                      },
                      decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        labelText: appLocalizations.tproxyPort,
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return appLocalizations.emptyTip(
                            appLocalizations.tproxyPort,
                          );
                        }
                        final port = int.tryParse(value);
                        if (port == null) {
                          return appLocalizations.numberTip(
                            appLocalizations.tproxyPort,
                          );
                        }
                        if (port == 0) {
                          return null;
                        }
                        if (port < 1024 || port > 49151) {
                          return appLocalizations.portTip(
                            appLocalizations.tproxyPort,
                          );
                        }
                        final ports = [
                          _portController.text,
                          _socksPortController.text,
                          _mixedPortController.text,
                          _redirPortController.text,
                          _externalControllerPortController.text,
                        ].map((item) => item.trim());
                        if (ports.contains(value.trim())) {
                          return appLocalizations.portConflictTip;
                        }

                        return null;
                      },
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class AppLocalizations {
  AppLocalizations();

  static AppLocalizations? _current;

  static AppLocalizations get current {
    assert(
      _current != null,
      'No instance of AppLocalizations was loaded. Try to initialize the AppLocalizations delegate before accessing AppLocalizations.current.',
    );
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<AppLocalizations> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = AppLocalizations();
      AppLocalizations._current = instance;

      return instance;
    });
  }

  static AppLocalizations of(BuildContext context) {
    final instance = AppLocalizations.maybeOf(context);
    assert(
      instance != null,
      'No instance of AppLocalizations present in the widget tree. Did you add AppLocalizations.delegate in localizationsDelegates?',
    );
    return instance!;
  }

  static AppLocalizations? maybeOf(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  /// `Rule`
  String get rule {
    return Intl.message('Rule', name: 'rule', desc: '', args: []);
  }

  /// `Global`
  String get global {
    return Intl.message('Global', name: 'global', desc: '', args: []);
  }

  /// `Direct`
  String get direct {
    return Intl.message('Direct', name: 'direct', desc: '', args: []);
  }

  /// `Home`
  String get dashboard {
    return Intl.message('Home', name: 'dashboard', desc: '', args: []);
  }

  /// `Custom Title`
  String get customDashboardTitle {
    return Intl.message(
      'Custom Title',
      name: 'customDashboardTitle',
      desc: '',
      args: [],
    );
  }

  /// `Title is too long, maximum 20 characters supported`
  String get titleTooLong {
    return Intl.message(
      'Title is too long, maximum 20 characters supported',
      name: 'titleTooLong',
      desc: '',
      args: [],
    );
  }

  /// `Proxies`
  String get proxies {
    return Intl.message('Proxies', name: 'proxies', desc: '', args: []);
  }

  /// `Profile`
  String get profile {
    return Intl.message('Profile', name: 'profile', desc: '', args: []);
  }

  /// `Profiles`
  String get profiles {
    return Intl.message('Profiles', name: 'profiles', desc: '', args: []);
  }

  /// `Tools`
  String get tools {
    return Intl.message('Tools', name: 'tools', desc: '', args: []);
  }

  /// `Logs`
  String get logs {
    return Intl.message('Logs', name: 'logs', desc: '', args: []);
  }

  /// `View captured logs`
  String get logsDesc {
    return Intl.message(
      'View captured logs',
      name: 'logsDesc',
      desc: '',
      args: [],
    );
  }

  /// `External Resources`
  String get resources {
    return Intl.message(
      'External Resources',
      name: 'resources',
      desc: '',
      args: [],
    );
  }

  /// `Sync All`
  String get syncAll {
    return Intl.message('Sync All', name: 'syncAll', desc: '', args: []);
  }

  /// `Sync Failed`
  String get syncFailed {
    return Intl.message('Sync Failed', name: 'syncFailed', desc: '', args: []);
  }

  /// `View external resources and rule sets`
  String get resourcesDesc {
    return Intl.message(
      'View external resources and rule sets',
      name: 'resourcesDesc',
      desc: '',
      args: [],
    );
  }

  /// `Configure JavaScript override scripts`
  String get scriptDesc {
    return Intl.message(
      'Configure JavaScript override scripts',
      name: 'scriptDesc',
      desc: '',
      args: [],
    );
  }

  /// `Traffic Usage`
  String get trafficUsage {
    return Intl.message(
      'Traffic Usage',
      name: 'trafficUsage',
      desc: '',
      args: [],
    );
  }

  /// `Core Info`
  String get coreInfo {
    return Intl.message('Core Info', name: 'coreInfo', desc: '', args: []);
  }

  /// `Network Speed`
  String get networkSpeed {
    return Intl.message(
      'Network Speed',
      name: 'networkSpeed',
      desc: '',
      args: [],
    );
  }

  /// `Real-time Speed`
  String get realTimeSpeed {
    return Intl.message(
      'Real-time Speed',
      name: 'realTimeSpeed',
      desc: '',
      args: [],
    );
  }

  /// `Connections Sort`
  String get connectionsSort {
    return Intl.message(
      'Connections Sort',
      name: 'connectionsSort',
      desc: '',
      args: [],
    );
  }

  /// `Total Traffic`
  String get totalTraffic {
    return Intl.message(
      'Total Traffic',
      name: 'totalTraffic',
      desc: '',
      args: [],
    );
  }

  /// `Restart App`
  String get restartApp {
    return Intl.message('Restart App', name: 'restartApp', desc: '', args: []);
  }

  /// `Background Watermark`
  String get backgroundWatermark {
    return Intl.message(
      'Background Watermark',
      name: 'backgroundWatermark',
      desc: '',
      args: [],
    );
  }

  /// `Outbound Mode`
  String get outboundMode {
    return Intl.message(
      'Outbound Mode',
      name: 'outboundMode',
      desc: '',
      args: [],
    );
  }

  /// `Running Mode`
  String get runningMode {
    return Intl.message(
      'Running Mode',
      name: 'runningMode',
      desc: '',
      args: [],
    );
  }

  /// `Network`
  String get networkDetection {
    return Intl.message(
      'Network',
      name: 'networkDetection',
      desc: '',
      args: [],
    );
  }

  /// `Upload`
  String get upload {
    return Intl.message('Upload', name: 'upload', desc: '', args: []);
  }

  /// `Download`
  String get download {
    return Intl.message('Download', name: 'download', desc: '', args: []);
  }

  /// `No Proxy`
  String get noProxy {
    return Intl.message('No Proxy', name: 'noProxy', desc: '', args: []);
  }

  /// `Please create or add a valid profile`
  String get noProxyDesc {
    return Intl.message(
      'Please create or add a valid profile',
      name: 'noProxyDesc',
      desc: '',
      args: [],
    );
  }

  /// `Direct mode, no proxies`
  String get directModeNoProxy {
    return Intl.message(
      'Direct mode, no proxies',
      name: 'directModeNoProxy',
      desc: '',
      args: [],
    );
  }

  /// `No profile. Please add one.`
  String get nullProfileDesc {
    return Intl.message(
      'No profile. Please add one.',
      name: 'nullProfileDesc',
      desc: '',
      args: [],
    );
  }

  /// `Settings`
  String get settings {
    return Intl.message('Settings', name: 'settings', desc: '', args: []);
  }

  /// `Language`
  String get language {
    return Intl.message('Language', name: 'language', desc: '', args: []);
  }

  /// `Default`
  String get defaultText {
    return Intl.message('Default', name: 'defaultText', desc: '', args: []);
  }

  /// `More`
  String get more {
    return Intl.message('More', name: 'more', desc: '', args: []);
  }

  /// `Other`
  String get other {
    return Intl.message('Other', name: 'other', desc: '', args: []);
  }

  /// `Enhanced Tools`
  String get otherSettings {
    return Intl.message(
      'Enhanced Tools',
      name: 'otherSettings',
      desc: '',
      args: [],
    );
  }

  /// `Modify enhanced tool settings`
  String get otherSettingsDesc {
    return Intl.message(
      'Modify enhanced tool settings',
      name: 'otherSettingsDesc',
      desc: '',
      args: [],
    );
  }

  /// `Smart Auto-Stop`
  String get smartAutoStop {
    return Intl.message(
      'Smart Auto-Stop',
      name: 'smartAutoStop',
      desc: '',
      args: [],
    );
  }

  /// `Stop VPN on specific networks`
  String get smartAutoStopDesc {
    return Intl.message(
      'Stop VPN on specific networks',
      name: 'smartAutoStopDesc',
      desc: '',
      args: [],
    );
  }

  /// `Network Match`
  String get networkMatch {
    return Intl.message(
      'Network Match',
      name: 'networkMatch',
      desc: '',
      args: [],
    );
  }

  /// `Enter IP, CIDR or Gateway:IP/CIDR`
  String get networkMatchHint {
    return Intl.message(
      'Enter IP, CIDR or Gateway:IP/CIDR',
      name: 'networkMatchHint',
      desc: '',
      args: [],
    );
  }

  /// `Smart Auto-Stop running`
  String get smartAutoStopServiceRunning {
    return Intl.message(
      'Smart Auto-Stop running',
      name: 'smartAutoStopServiceRunning',
      desc: '',
      args: [],
    );
  }

  /// `Service Running`
  String get serviceRunning {
    return Intl.message(
      'Service Running',
      name: 'serviceRunning',
      desc: '',
      args: [],
    );
  }

  /// `Connected`
  String get coreConnected {
    return Intl.message('Connected', name: 'coreConnected', desc: '', args: []);
  }

  /// `Suspended`
  String get coreSuspended {
    return Intl.message('Suspended', name: 'coreSuspended', desc: '', args: []);
  }

  /// `Invalid IP or CIDR format`
  String get invalidIpFormat {
    return Intl.message(
      'Invalid IP or CIDR format',
      name: 'invalidIpFormat',
      desc: '',
      args: [],
    );
  }

  /// `Max 5 rules allowed`
  String get tooManyRules {
    return Intl.message(
      'Max 5 rules allowed',
      name: 'tooManyRules',
      desc: '',
      args: [],
    );
  }

  /// `Doze Support`
  String get dozeSuspend {
    return Intl.message(
      'Doze Support',
      name: 'dozeSuspend',
      desc: '',
      args: [],
    );
  }

  /// `Sync with system Doze mode`
  String get dozeSuspendDesc {
    return Intl.message(
      'Sync with system Doze mode',
      name: 'dozeSuspendDesc',
      desc: '',
      args: [],
    );
  }

  /// `Store Fix`
  String get storeFix {
    return Intl.message('Store Fix', name: 'storeFix', desc: '', args: []);
  }

  /// `Fix Play Store download issues`
  String get storeFixDesc {
    return Intl.message(
      'Fix Play Store download issues',
      name: 'storeFixDesc',
      desc: '',
      args: [],
    );
  }

  /// `Loopback Protection`
  String get loopbackProtection {
    return Intl.message(
      'Loopback Protection',
      name: 'loopbackProtection',
      desc: '',
      args: [],
    );
  }

  /// `Block loopback traffic from errors`
  String get loopbackProtectionDesc {
    return Intl.message(
      'Block loopback traffic from errors',
      name: 'loopbackProtectionDesc',
      desc: '',
      args: [],
    );
  }

  /// `Disable QUIC`
  String get disableQuic {
    return Intl.message(
      'Disable QUIC',
      name: 'disableQuic',
      desc: '',
      args: [],
    );
  }

  /// `Disable QUIC to mitigate specific network issues`
  String get disableQuicDesc {
    return Intl.message(
      'Disable QUIC to mitigate specific network issues',
      name: 'disableQuicDesc',
      desc: '',
      args: [],
    );
  }

  /// `High Priority`
  String get notificationHighPriority {
    return Intl.message(
      'High Priority',
      name: 'notificationHighPriority',
      desc: '',
      args: [],
    );
  }

  /// `Foreground high-priority notification`
  String get notificationHighPriorityDesc {
    return Intl.message(
      'Foreground high-priority notification',
      name: 'notificationHighPriorityDesc',
      desc: '',
      args: [],
    );
  }

  /// `High-priority notifications can alleviate background core keep-alive issues on some customized systems. If your VPN service is currently running normally, it is recommended to keep this option disabled. Are you sure you want to enable it?`
  String get notificationHighPriorityTip {
    return Intl.message(
      'High-priority notifications can alleviate background core keep-alive issues on some customized systems. If your VPN service is currently running normally, it is recommended to keep this option disabled. Are you sure you want to enable it?',
      name: 'notificationHighPriorityTip',
      desc: '',
      args: [],
    );
  }

  /// `Speed in Notification`
  String get networkSpeedNotification {
    return Intl.message(
      'Speed in Notification',
      name: 'networkSpeedNotification',
      desc: '',
      args: [],
    );
  }

  /// `Show speed and subscription info in notification bar`
  String get networkSpeedNotificationDesc {
    return Intl.message(
      'Show speed and subscription info in notification bar',
      name: 'networkSpeedNotificationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Title Buttons`
  String get alwaysShowTitleBar {
    return Intl.message(
      'Title Buttons',
      name: 'alwaysShowTitleBar',
      desc: '',
      args: [],
    );
  }

  /// `Always show top-right title bar buttons`
  String get alwaysShowTitleBarDesc {
    return Intl.message(
      'Always show top-right title bar buttons',
      name: 'alwaysShowTitleBarDesc',
      desc: '',
      args: [],
    );
  }

  /// `Keep in Dock`
  String get keepDockIcon {
    return Intl.message(
      'Keep in Dock',
      name: 'keepDockIcon',
      desc: '',
      args: [],
    );
  }

  /// `Keep the app icon in the Dock`
  String get keepDockIconDesc {
    return Intl.message(
      'Keep the app icon in the Dock',
      name: 'keepDockIconDesc',
      desc: '',
      args: [],
    );
  }

  /// `Tray Enhancement`
  String get trayEnhancement {
    return Intl.message(
      'Tray Enhancement',
      name: 'trayEnhancement',
      desc: '',
      args: [],
    );
  }

  /// `Control proxy groups via tray menu`
  String get trayEnhancementDesc {
    return Intl.message(
      'Control proxy groups via tray menu',
      name: 'trayEnhancementDesc',
      desc: '',
      args: [],
    );
  }

  /// `Tray Click Behavior`
  String get trayClickBehavior {
    return Intl.message(
      'Tray Click Behavior',
      name: 'trayClickBehavior',
      desc: '',
      args: [],
    );
  }

  /// `Left Click`
  String get leftClickBehavior {
    return Intl.message(
      'Left Click',
      name: 'leftClickBehavior',
      desc: '',
      args: [],
    );
  }

  /// `Right Click`
  String get rightClickBehavior {
    return Intl.message(
      'Right Click',
      name: 'rightClickBehavior',
      desc: '',
      args: [],
    );
  }

  /// `Show Window`
  String get showPanel {
    return Intl.message('Show Window', name: 'showPanel', desc: '', args: []);
  }

  /// `Open Menu`
  String get showMenu {
    return Intl.message('Open Menu', name: 'showMenu', desc: '', args: []);
  }

  /// `Tray Speed`
  String get enableTraySpeed {
    return Intl.message(
      'Tray Speed',
      name: 'enableTraySpeed',
      desc: '',
      args: [],
    );
  }

  /// `Show network speed in menu bar`
  String get enableTraySpeedDesc {
    return Intl.message(
      'Show network speed in menu bar',
      name: 'enableTraySpeedDesc',
      desc: '',
      args: [],
    );
  }

  /// `FCM Optimization`
  String get fcmOptimization {
    return Intl.message(
      'FCM Optimization',
      name: 'fcmOptimization',
      desc: '',
      args: [],
    );
  }

  /// `Enhance FCM connection stability`
  String get fcmOptimizationDesc {
    return Intl.message(
      'Enhance FCM connection stability',
      name: 'fcmOptimizationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Quick Response`
  String get quickResponse {
    return Intl.message(
      'Quick Response',
      name: 'quickResponse',
      desc: '',
      args: [],
    );
  }

  /// `Close connections on network change or node switch`
  String get quickResponseDesc {
    return Intl.message(
      'Close connections on network change or node switch',
      name: 'quickResponseDesc',
      desc: '',
      args: [],
    );
  }

  /// `Network Fix`
  String get networkFix {
    return Intl.message('Network Fix', name: 'networkFix', desc: '', args: []);
  }

  /// `Fix system network globe icon issue`
  String get networkFixDesc {
    return Intl.message(
      'Fix system network globe icon issue',
      name: 'networkFixDesc',
      desc: '',
      args: [],
    );
  }

  /// `High Priority`
  String get highPriority {
    return Intl.message(
      'High Priority',
      name: 'highPriority',
      desc: '',
      args: [],
    );
  }

  /// `Elevate app & core process priority`
  String get highPriorityDesc {
    return Intl.message(
      'Elevate app & core process priority',
      name: 'highPriorityDesc',
      desc: '',
      args: [],
    );
  }

  /// `Battery Optimization`
  String get batteryOptimization {
    return Intl.message(
      'Battery Optimization',
      name: 'batteryOptimization',
      desc: '',
      args: [],
    );
  }

  /// `Request battery optimization whitelist`
  String get batteryOptimizationDesc {
    return Intl.message(
      'Request battery optimization whitelist',
      name: 'batteryOptimizationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Already in whitelist`
  String get alreadyInWhitelist {
    return Intl.message(
      'Already in whitelist',
      name: 'alreadyInWhitelist',
      desc: '',
      args: [],
    );
  }

  /// `About`
  String get about {
    return Intl.message('About', name: 'about', desc: '', args: []);
  }

  /// `Theme`
  String get theme {
    return Intl.message('Theme', name: 'theme', desc: '', args: []);
  }

  /// `Set theme color options`
  String get themeDesc {
    return Intl.message(
      'Set theme color options',
      name: 'themeDesc',
      desc: '',
      args: [],
    );
  }

  /// `Override`
  String get override {
    return Intl.message('Override', name: 'override', desc: '', args: []);
  }

  /// `Override proxy configurations`
  String get overrideDesc {
    return Intl.message(
      'Override proxy configurations',
      name: 'overrideDesc',
      desc: '',
      args: [],
    );
  }

  /// `Allow LAN`
  String get allowLan {
    return Intl.message('Allow LAN', name: 'allowLan', desc: '', args: []);
  }

  /// `Allow LAN access to proxy`
  String get allowLanDesc {
    return Intl.message(
      'Allow LAN access to proxy',
      name: 'allowLanDesc',
      desc: '',
      args: [],
    );
  }

  /// `TUN`
  String get tun {
    return Intl.message('TUN', name: 'tun', desc: '', args: []);
  }

  /// `Use TUN to take over device traffic`
  String get tunDesc {
    return Intl.message(
      'Use TUN to take over device traffic',
      name: 'tunDesc',
      desc: '',
      args: [],
    );
  }

  /// `Minimize on Exit`
  String get minimizeOnExit {
    return Intl.message(
      'Minimize on Exit',
      name: 'minimizeOnExit',
      desc: '',
      args: [],
    );
  }

  /// `Override default exit behavior`
  String get minimizeOnExitDesc {
    return Intl.message(
      'Override default exit behavior',
      name: 'minimizeOnExitDesc',
      desc: '',
      args: [],
    );
  }

  /// `Auto Launch`
  String get autoLaunch {
    return Intl.message('Auto Launch', name: 'autoLaunch', desc: '', args: []);
  }

  /// `Launch on system startup`
  String get autoLaunchDesc {
    return Intl.message(
      'Launch on system startup',
      name: 'autoLaunchDesc',
      desc: '',
      args: [],
    );
  }

  /// `Smart Delay`
  String get smartDelayLaunch {
    return Intl.message(
      'Smart Delay',
      name: 'smartDelayLaunch',
      desc: '',
      args: [],
    );
  }

  /// `Launch after network connected`
  String get smartDelayLaunchDesc {
    return Intl.message(
      'Launch after network connected',
      name: 'smartDelayLaunchDesc',
      desc: '',
      args: [],
    );
  }

  /// `Silent Launch`
  String get silentLaunch {
    return Intl.message(
      'Silent Launch',
      name: 'silentLaunch',
      desc: '',
      args: [],
    );
  }

  /// `Start in the background`
  String get silentLaunchDesc {
    return Intl.message(
      'Start in the background',
      name: 'silentLaunchDesc',
      desc: '',
      args: [],
    );
  }

  /// `Auto Run`
  String get autoRun {
    return Intl.message('Auto Run', name: 'autoRun', desc: '', args: []);
  }

  /// `Connect on app launch`
  String get autoRunDesc {
    return Intl.message(
      'Connect on app launch',
      name: 'autoRunDesc',
      desc: '',
      args: [],
    );
  }

  /// `Log Capture`
  String get logcat {
    return Intl.message('Log Capture', name: 'logcat', desc: '', args: []);
  }

  /// `Show log capture entry`
  String get logcatDesc {
    return Intl.message(
      'Show log capture entry',
      name: 'logcatDesc',
      desc: '',
      args: [],
    );
  }

  /// `Crash Analytics`
  String get enableCrashReport {
    return Intl.message(
      'Crash Analytics',
      name: 'enableCrashReport',
      desc: '',
      args: [],
    );
  }

  /// `Upload crash logs when needed`
  String get enableCrashReportDesc {
    return Intl.message(
      'Upload crash logs when needed',
      name: 'enableCrashReportDesc',
      desc: '',
      args: [],
    );
  }

  /// `Auto Check Updates`
  String get autoCheckUpdate {
    return Intl.message(
      'Auto Check Updates',
      name: 'autoCheckUpdate',
      desc: '',
      args: [],
    );
  }

  /// `Check updates on app launch`
  String get autoCheckUpdateDesc {
    return Intl.message(
      'Check updates on app launch',
      name: 'autoCheckUpdateDesc',
      desc: '',
      args: [],
    );
  }

  /// `Auto Download Updates`
  String get autoDownloadUpdate {
    return Intl.message(
      'Auto Download Updates',
      name: 'autoDownloadUpdate',
      desc: '',
      args: [],
    );
  }

  /// `Download new versions in the background`
  String get autoDownloadUpdateDesc {
    return Intl.message(
      'Download new versions in the background',
      name: 'autoDownloadUpdateDesc',
      desc: '',
      args: [],
    );
  }

  /// `Update download failed`
  String get updateDownloadFailed {
    return Intl.message(
      'Update download failed',
      name: 'updateDownloadFailed',
      desc: '',
      args: [],
    );
  }

  /// `Update install failed`
  String get updateInstallFailed {
    return Intl.message(
      'Update install failed',
      name: 'updateInstallFailed',
      desc: '',
      args: [],
    );
  }

  /// `Install`
  String get install {
    return Intl.message('Install', name: 'install', desc: '', args: []);
  }

  /// `Update download started`
  String get updateDownloadStarted {
    return Intl.message(
      'Update download started',
      name: 'updateDownloadStarted',
      desc: '',
      args: [],
    );
  }

  /// `Update is downloading`
  String get updateDownloading {
    return Intl.message(
      'Update is downloading',
      name: 'updateDownloading',
      desc: '',
      args: [],
    );
  }

  /// `Update downloaded`
  String get updateDownloaded {
    return Intl.message(
      'Update downloaded',
      name: 'updateDownloaded',
      desc: '',
      args: [],
    );
  }

  /// `Upgrade Notice`
  String get updateTip {
    return Intl.message(
      'Upgrade Notice',
      name: 'updateTip',
      desc: '',
      args: [],
    );
  }

  /// `The new version package is ready. To keep the service safe, the running {appName} will be closed before upgrading. Confirm to start the installation.`
  String updateReadyAppTip(Object appName) {
    return Intl.message(
      'The new version package is ready. To keep the service safe, the running $appName will be closed before upgrading. Confirm to start the installation.',
      name: 'updateReadyAppTip',
      desc: '',
      args: [appName],
    );
  }

  /// `Access Control`
  String get accessControl {
    return Intl.message(
      'Access Control',
      name: 'accessControl',
      desc: '',
      args: [],
    );
  }

  /// `App allowlist and blocklist`
  String get accessControlDesc {
    return Intl.message(
      'App allowlist and blocklist',
      name: 'accessControlDesc',
      desc: '',
      args: [],
    );
  }

  /// `Clear Cache`
  String get clearCacheTitle {
    return Intl.message(
      'Clear Cache',
      name: 'clearCacheTitle',
      desc: '',
      args: [],
    );
  }

  /// `FakeIP and DNS cache cleared`
  String get dnsCacheCleared {
    return Intl.message(
      'FakeIP and DNS cache cleared',
      name: 'dnsCacheCleared',
      desc: '',
      args: [],
    );
  }

  /// `Force Garbage Collection`
  String get forceGCTitle {
    return Intl.message(
      'Force Garbage Collection',
      name: 'forceGCTitle',
      desc: '',
      args: [],
    );
  }

  /// `Firebase Cloud Messaging (FCM) is a cross-platform messaging solution. Its connection support depends on the device and network, so the results are for reference only.`
  String get fcmTip {
    return Intl.message(
      'Firebase Cloud Messaging (FCM) is a cross-platform messaging solution. Its connection support depends on the device and network, so the results are for reference only.',
      name: 'fcmTip',
      desc: '',
      args: [],
    );
  }

  /// ` Due to system permission reasons, on Android you may need to disable "Allow bypass VPN" in network settings to get more accurate results`
  String get fcmAndroidTip {
    return Intl.message(
      ' Due to system permission reasons, on Android you may need to disable "Allow bypass VPN" in network settings to get more accurate results',
      name: 'fcmAndroidTip',
      desc: '',
      args: [],
    );
  }

  /// `Application`
  String get application {
    return Intl.message('Application', name: 'application', desc: '', args: []);
  }

  /// `Modify application settings`
  String get applicationDesc {
    return Intl.message(
      'Modify application settings',
      name: 'applicationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Edit`
  String get edit {
    return Intl.message('Edit', name: 'edit', desc: '', args: []);
  }

  /// `Confirm`
  String get confirm {
    return Intl.message('Confirm', name: 'confirm', desc: '', args: []);
  }

  /// `Update`
  String get update {
    return Intl.message('Update', name: 'update', desc: '', args: []);
  }

  /// `Add`
  String get add {
    return Intl.message('Add', name: 'add', desc: '', args: []);
  }

  /// `Save`
  String get save {
    return Intl.message('Save', name: 'save', desc: '', args: []);
  }

  /// `Delete`
  String get delete {
    return Intl.message('Delete', name: 'delete', desc: '', args: []);
  }

  /// `{count, plural, one{year} other{years}}`
  String years(num count) {
    return Intl.plural(
      count,
      one: 'year',
      other: 'years',
      name: 'years',
      desc: '',
      args: [count],
    );
  }

  /// `{count, plural, one{month} other{months}}`
  String months(num count) {
    return Intl.plural(
      count,
      one: 'month',
      other: 'months',
      name: 'months',
      desc: '',
      args: [count],
    );
  }

  /// `{count, plural, one{hour} other{hours}}`
  String hours(num count) {
    return Intl.plural(
      count,
      one: 'hour',
      other: 'hours',
      name: 'hours',
      desc: '',
      args: [count],
    );
  }

  /// `{count, plural, one{day} other{days}}`
  String days(num count) {
    return Intl.plural(
      count,
      one: 'day',
      other: 'days',
      name: 'days',
      desc: '',
      args: [count],
    );
  }

  /// `{count, plural, one{minute} other{minutes}}`
  String minutes(num count) {
    return Intl.plural(
      count,
      one: 'minute',
      other: 'minutes',
      name: 'minutes',
      desc: '',
      args: [count],
    );
  }

  /// `Seconds`
  String get seconds {
    return Intl.message('Seconds', name: 'seconds', desc: '', args: []);
  }

  /// ` ago`
  String get ago {
    return Intl.message(' ago', name: 'ago', desc: '', args: []);
  }

  /// `Please close TUN first`
  String get pleaseCloseTunFirst {
    return Intl.message(
      'Please close TUN first',
      name: 'pleaseCloseTunFirst',
      desc: '',
      args: [],
    );
  }

  /// `Please close System Proxy first`
  String get pleaseCloseSystemProxyFirst {
    return Intl.message(
      'Please close System Proxy first',
      name: 'pleaseCloseSystemProxyFirst',
      desc: '',
      args: [],
    );
  }

  /// `Just now`
  String get just {
    return Intl.message('Just now', name: 'just', desc: '', args: []);
  }

  /// `QR Code`
  String get qrcode {
    return Intl.message('QR Code', name: 'qrcode', desc: '', args: []);
  }

  /// `Scan QR code to import profile`
  String get qrcodeDesc {
    return Intl.message(
      'Scan QR code to import profile',
      name: 'qrcodeDesc',
      desc: '',
      args: [],
    );
  }

  /// `Clipboard`
  String get clipboard {
    return Intl.message('Clipboard', name: 'clipboard', desc: '', args: []);
  }

  /// `Get profile link from clipboard`
  String get clipboardDesc {
    return Intl.message(
      'Get profile link from clipboard',
      name: 'clipboardDesc',
      desc: '',
      args: [],
    );
  }

  /// `URL`
  String get url {
    return Intl.message('URL', name: 'url', desc: '', args: []);
  }

  /// `Get profile via URL`
  String get urlDesc {
    return Intl.message(
      'Get profile via URL',
      name: 'urlDesc',
      desc: '',
      args: [],
    );
  }

  /// `File`
  String get file {
    return Intl.message('File', name: 'file', desc: '', args: []);
  }

  /// `Upload profile file`
  String get fileDesc {
    return Intl.message(
      'Upload profile file',
      name: 'fileDesc',
      desc: '',
      args: [],
    );
  }

  /// `Name`
  String get name {
    return Intl.message('Name', name: 'name', desc: '', args: []);
  }

  /// `Please enter a profile name`
  String get profileNameNullValidationDesc {
    return Intl.message(
      'Please enter a profile name',
      name: 'profileNameNullValidationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Please enter a profile URL`
  String get profileUrlNullValidationDesc {
    return Intl.message(
      'Please enter a profile URL',
      name: 'profileUrlNullValidationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Please enter a valid URL`
  String get profileUrlInvalidValidationDesc {
    return Intl.message(
      'Please enter a valid URL',
      name: 'profileUrlInvalidValidationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Auto Update`
  String get autoUpdate {
    return Intl.message('Auto Update', name: 'autoUpdate', desc: '', args: []);
  }

  /// `Auto update interval (min)`
  String get autoUpdateInterval {
    return Intl.message(
      'Auto update interval (min)',
      name: 'autoUpdateInterval',
      desc: '',
      args: [],
    );
  }

  /// `Please enter update interval`
  String get profileAutoUpdateIntervalNullValidationDesc {
    return Intl.message(
      'Please enter update interval',
      name: 'profileAutoUpdateIntervalNullValidationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Please enter a valid interval`
  String get profileAutoUpdateIntervalInvalidValidationDesc {
    return Intl.message(
      'Please enter a valid interval',
      name: 'profileAutoUpdateIntervalInvalidValidationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Theme Mode`
  String get themeMode {
    return Intl.message('Theme Mode', name: 'themeMode', desc: '', args: []);
  }

  /// `Theme Color`
  String get themeColor {
    return Intl.message('Theme Color', name: 'themeColor', desc: '', args: []);
  }

  /// `Dynamic color`
  String get dynamicColor {
    return Intl.message(
      'Dynamic color',
      name: 'dynamicColor',
      desc: '',
      args: [],
    );
  }

  /// `Preview`
  String get preview {
    return Intl.message('Preview', name: 'preview', desc: '', args: []);
  }

  /// `Runtime Config`
  String get runtimeConfig {
    return Intl.message(
      'Runtime Config',
      name: 'runtimeConfig',
      desc: '',
      args: [],
    );
  }

  /// `Camera Permission Denied`
  String get cameraPermissionDenied {
    return Intl.message(
      'Camera Permission Denied',
      name: 'cameraPermissionDenied',
      desc: '',
      args: [],
    );
  }

  /// `Camera permission is required to scan QR codes. Please grant it in settings.`
  String get cameraPermissionDesc {
    return Intl.message(
      'Camera permission is required to scan QR codes. Please grant it in settings.',
      name: 'cameraPermissionDesc',
      desc: '',
      args: [],
    );
  }

  /// `Open Settings`
  String get openSettings {
    return Intl.message(
      'Open Settings',
      name: 'openSettings',
      desc: '',
      args: [],
    );
  }

  /// `Retry`
  String get retry {
    return Intl.message('Retry', name: 'retry', desc: '', args: []);
  }

  /// `Permission to access installed apps is required. Grant now?`
  String get packageListPermissionRequired {
    return Intl.message(
      'Permission to access installed apps is required. Grant now?',
      name: 'packageListPermissionRequired',
      desc: '',
      args: [],
    );
  }

  /// `Permission denied. Cannot access app list.`
  String get packageListPermissionDenied {
    return Intl.message(
      'Permission denied. Cannot access app list.',
      name: 'packageListPermissionDenied',
      desc: '',
      args: [],
    );
  }

  /// `Auto`
  String get auto {
    return Intl.message('Auto', name: 'auto', desc: '', args: []);
  }

  /// `Light`
  String get light {
    return Intl.message('Light', name: 'light', desc: '', args: []);
  }

  /// `Dark`
  String get dark {
    return Intl.message('Dark', name: 'dark', desc: '', args: []);
  }

  /// `Import from URL`
  String get importFromURL {
    return Intl.message(
      'Import from URL',
      name: 'importFromURL',
      desc: '',
      args: [],
    );
  }

  /// `Submit`
  String get submit {
    return Intl.message('Submit', name: 'submit', desc: '', args: []);
  }

  /// `Do you want to pass`
  String get doYouWantToPass {
    return Intl.message(
      'Do you want to pass',
      name: 'doYouWantToPass',
      desc: '',
      args: [],
    );
  }

  /// `Create`
  String get create {
    return Intl.message('Create', name: 'create', desc: '', args: []);
  }

  /// `Default Sort`
  String get defaultSort {
    return Intl.message(
      'Default Sort',
      name: 'defaultSort',
      desc: '',
      args: [],
    );
  }

  /// `Sort by Delay`
  String get delaySort {
    return Intl.message('Sort by Delay', name: 'delaySort', desc: '', args: []);
  }

  /// `Sort by Name`
  String get nameSort {
    return Intl.message('Sort by Name', name: 'nameSort', desc: '', args: []);
  }

  /// `Please upload a file`
  String get pleaseUploadFile {
    return Intl.message(
      'Please upload a file',
      name: 'pleaseUploadFile',
      desc: '',
      args: [],
    );
  }

  /// `Please upload a valid QR code`
  String get pleaseUploadValidQrcode {
    return Intl.message(
      'Please upload a valid QR code',
      name: 'pleaseUploadValidQrcode',
      desc: '',
      args: [],
    );
  }

  /// `Blacklist Mode`
  String get blacklistMode {
    return Intl.message(
      'Blacklist Mode',
      name: 'blacklistMode',
      desc: '',
      args: [],
    );
  }

  /// `Whitelist Mode`
  String get whitelistMode {
    return Intl.message(
      'Whitelist Mode',
      name: 'whitelistMode',
      desc: '',
      args: [],
    );
  }

  /// `Filter System Apps`
  String get filterSystemApp {
    return Intl.message(
      'Filter System Apps',
      name: 'filterSystemApp',
      desc: '',
      args: [],
    );
  }

  /// `Show System Apps`
  String get cancelFilterSystemApp {
    return Intl.message(
      'Show System Apps',
      name: 'cancelFilterSystemApp',
      desc: '',
      args: [],
    );
  }

  /// `Select All`
  String get selectAll {
    return Intl.message('Select All', name: 'selectAll', desc: '', args: []);
  }

  /// `Deselect All`
  String get cancelSelectAll {
    return Intl.message(
      'Deselect All',
      name: 'cancelSelectAll',
      desc: '',
      args: [],
    );
  }

  /// `App Access Control`
  String get appAccessControl {
    return Intl.message(
      'App Access Control',
      name: 'appAccessControl',
      desc: '',
      args: [],
    );
  }

  /// `Only route selected apps through VPN`
  String get accessControlAllowDesc {
    return Intl.message(
      'Only route selected apps through VPN',
      name: 'accessControlAllowDesc',
      desc: '',
      args: [],
    );
  }

  /// `Exclude selected apps from VPN`
  String get accessControlNotAllowDesc {
    return Intl.message(
      'Exclude selected apps from VPN',
      name: 'accessControlNotAllowDesc',
      desc: '',
      args: [],
    );
  }

  /// `Selected`
  String get selected {
    return Intl.message('Selected', name: 'selected', desc: '', args: []);
  }

  /// `Current`
  String get currentSelection {
    return Intl.message(
      'Current',
      name: 'currentSelection',
      desc: '',
      args: [],
    );
  }

  /// `Unable to update current profile`
  String get unableToUpdateCurrentProfileDesc {
    return Intl.message(
      'Unable to update current profile',
      name: 'unableToUpdateCurrentProfileDesc',
      desc: '',
      args: [],
    );
  }

  /// `No more info`
  String get noMoreInfoDesc {
    return Intl.message(
      'No more info',
      name: 'noMoreInfoDesc',
      desc: '',
      args: [],
    );
  }

  /// `Profile parse error`
  String get profileParseErrorDesc {
    return Intl.message(
      'Profile parse error',
      name: 'profileParseErrorDesc',
      desc: '',
      args: [],
    );
  }

  /// `Proxy Port`
  String get proxyPort {
    return Intl.message('Proxy Port', name: 'proxyPort', desc: '', args: []);
  }

  /// `Set the Clash listening port`
  String get proxyPortDesc {
    return Intl.message(
      'Set the Clash listening port',
      name: 'proxyPortDesc',
      desc: '',
      args: [],
    );
  }

  /// `Port`
  String get port {
    return Intl.message('Port', name: 'port', desc: '', args: []);
  }

  /// `Log Level`
  String get logLevel {
    return Intl.message('Log Level', name: 'logLevel', desc: '', args: []);
  }

  /// `AI Search`
  String get logAiSearch {
    return Intl.message('AI Search', name: 'logAiSearch', desc: '', args: []);
  }

  /// `Show`
  String get show {
    return Intl.message('Show', name: 'show', desc: '', args: []);
  }

  /// `Exit`
  String get exit {
    return Intl.message('Exit', name: 'exit', desc: '', args: []);
  }

  /// `System Proxy`
  String get systemProxy {
    return Intl.message(
      'System Proxy',
      name: 'systemProxy',
      desc: '',
      args: [],
    );
  }

  /// `Project`
  String get project {
    return Intl.message('Project', name: 'project', desc: '', args: []);
  }

  /// `Core`
  String get core {
    return Intl.message('Core', name: 'core', desc: '', args: []);
  }

  /// `Linkage Switch`
  String get showStartSwitch {
    return Intl.message(
      'Linkage Switch',
      name: 'showStartSwitch',
      desc: '',
      args: [],
    );
  }

  /// `Show standalone switch on homepage`
  String get showStartSwitchDesc {
    return Intl.message(
      'Show standalone switch on homepage',
      name: 'showStartSwitchDesc',
      desc: '',
      args: [],
    );
  }

  /// `Style`
  String get startSwitchStyle {
    return Intl.message('Style', name: 'startSwitchStyle', desc: '', args: []);
  }

  /// `Tonal`
  String get startSwitchTonal {
    return Intl.message('Tonal', name: 'startSwitchTonal', desc: '', args: []);
  }

  /// `Outlined`
  String get startSwitchOutlined {
    return Intl.message(
      'Outlined',
      name: 'startSwitchOutlined',
      desc: '',
      args: [],
    );
  }

  /// `Personalized Display`
  String get startSwitchPersonalized {
    return Intl.message(
      'Personalized Display',
      name: 'startSwitchPersonalized',
      desc: '',
      args: [],
    );
  }

  /// `Text when on`
  String get startSwitchOnLabel {
    return Intl.message(
      'Text when on',
      name: 'startSwitchOnLabel',
      desc: '',
      args: [],
    );
  }

  /// `Text when off`
  String get startSwitchOffLabel {
    return Intl.message(
      'Text when off',
      name: 'startSwitchOffLabel',
      desc: '',
      args: [],
    );
  }

  /// `Hover Panel`
  String get sidebarFlyout {
    return Intl.message(
      'Hover Panel',
      name: 'sidebarFlyout',
      desc: '',
      args: [],
    );
  }

  /// `Show sidebar settings hover card`
  String get sidebarFlyoutDesc {
    return Intl.message(
      'Show sidebar settings hover card',
      name: 'sidebarFlyoutDesc',
      desc: '',
      args: [],
    );
  }

  /// `Only show outside the “Tools” page`
  String get sidebarFlyoutOutsideTools {
    return Intl.message(
      'Only show outside the “Tools” page',
      name: 'sidebarFlyoutOutsideTools',
      desc: '',
      args: [],
    );
  }

  /// `Trigger Delay`
  String get sidebarFlyoutDelay {
    return Intl.message(
      'Trigger Delay',
      name: 'sidebarFlyoutDelay',
      desc: '',
      args: [],
    );
  }

  /// `Entries`
  String get sidebarFlyoutEntries {
    return Intl.message(
      'Entries',
      name: 'sidebarFlyoutEntries',
      desc: '',
      args: [],
    );
  }

  /// `Fast`
  String get fast {
    return Intl.message('Fast', name: 'fast', desc: '', args: []);
  }

  /// `Slow`
  String get slow {
    return Intl.message('Slow', name: 'slow', desc: '', args: []);
  }

  /// `FastLin is deeply crafted on the powerful and flexible Mihomo kernel, dedicated to a superior client experience. Our vision: Connecting Open Source and AI, Accelerating Innovation`
  String get desc {
    return Intl.message(
      'FastLin is deeply crafted on the powerful and flexible Mihomo kernel, dedicated to a superior client experience. Our vision: Connecting Open Source and AI, Accelerating Innovation',
      name: 'desc',
      desc: '',
      args: [],
    );
  }

  /// `Starting...`
  String get startVpn {
    return Intl.message('Starting...', name: 'startVpn', desc: '', args: []);
  }

  /// `Stopping...`
  String get stopVpn {
    return Intl.message('Stopping...', name: 'stopVpn', desc: '', args: []);
  }

  /// `New Version Found`
  String get discovery {
    return Intl.message(
      'New Version Found',
      name: 'discovery',
      desc: '',
      args: [],
    );
  }

  /// `Compatible Mode`
  String get compatible {
    return Intl.message(
      'Compatible Mode',
      name: 'compatible',
      desc: '',
      args: [],
    );
  }

  /// `Enabling this mode may limit some features, but provides full Clash support`
  String get compatibleDesc {
    return Intl.message(
      'Enabling this mode may limit some features, but provides full Clash support',
      name: 'compatibleDesc',
      desc: '',
      args: [],
    );
  }

  /// `Current proxy group cannot be selected.`
  String get notSelectedTip {
    return Intl.message(
      'Current proxy group cannot be selected.',
      name: 'notSelectedTip',
      desc: '',
      args: [],
    );
  }

  /// `Tip`
  String get tip {
    return Intl.message('Tip', name: 'tip', desc: '', args: []);
  }

  /// `Backup & Restore`
  String get backupAndRecovery {
    return Intl.message(
      'Backup & Restore',
      name: 'backupAndRecovery',
      desc: '',
      args: [],
    );
  }

  /// `Sync data via WebDAV or locally`
  String get backupAndRecoveryDesc {
    return Intl.message(
      'Sync data via WebDAV or locally',
      name: 'backupAndRecoveryDesc',
      desc: '',
      args: [],
    );
  }

  /// `Account`
  String get account {
    return Intl.message('Account', name: 'account', desc: '', args: []);
  }

  /// `Backup`
  String get backup {
    return Intl.message('Backup', name: 'backup', desc: '', args: []);
  }

  /// `Restore`
  String get recovery {
    return Intl.message('Restore', name: 'recovery', desc: '', args: []);
  }

  /// `Restore Profiles Only`
  String get recoveryProfiles {
    return Intl.message(
      'Restore Profiles Only',
      name: 'recoveryProfiles',
      desc: '',
      args: [],
    );
  }

  /// `Restore All Data`
  String get recoveryAll {
    return Intl.message(
      'Restore All Data',
      name: 'recoveryAll',
      desc: '',
      args: [],
    );
  }

  /// `Back Up Profiles Only`
  String get backupProfiles {
    return Intl.message(
      'Back Up Profiles Only',
      name: 'backupProfiles',
      desc: '',
      args: [],
    );
  }

  /// `Back Up All Data`
  String get backupAll {
    return Intl.message(
      'Back Up All Data',
      name: 'backupAll',
      desc: '',
      args: [],
    );
  }

  /// `Subscriptions, override scripts, nodes and managed mode`
  String get backupScopeProfilesDesc {
    return Intl.message(
      'Subscriptions, override scripts, nodes and managed mode',
      name: 'backupScopeProfilesDesc',
      desc: '',
      args: [],
    );
  }

  /// `Profiles and all app settings`
  String get backupScopeAllDesc {
    return Intl.message(
      'Profiles and all app settings',
      name: 'backupScopeAllDesc',
      desc: '',
      args: [],
    );
  }

  /// `Select Backup Version`
  String get selectBackupVersion {
    return Intl.message(
      'Select Backup Version',
      name: 'selectBackupVersion',
      desc: '',
      args: [],
    );
  }

  /// `No backup file found`
  String get noBackupFileFound {
    return Intl.message(
      'No backup file found',
      name: 'noBackupFileFound',
      desc: '',
      args: [],
    );
  }

  /// `Restore Successful`
  String get recoverySuccess {
    return Intl.message(
      'Restore Successful',
      name: 'recoverySuccess',
      desc: '',
      args: [],
    );
  }

  /// `Backup Successful`
  String get backupSuccess {
    return Intl.message(
      'Backup Successful',
      name: 'backupSuccess',
      desc: '',
      args: [],
    );
  }

  /// `Backup Password`
  String get backupPassword {
    return Intl.message(
      'Backup Password',
      name: 'backupPassword',
      desc: '',
      args: [],
    );
  }

  /// `AES-256 encrypted, leave blank for none`
  String get backupPasswordDesc {
    return Intl.message(
      'AES-256 encrypted, leave blank for none',
      name: 'backupPasswordDesc',
      desc: '',
      args: [],
    );
  }

  /// `This backup is encrypted, please enter the password`
  String get backupPasswordRequired {
    return Intl.message(
      'This backup is encrypted, please enter the password',
      name: 'backupPasswordRequired',
      desc: '',
      args: [],
    );
  }

  /// `Incorrect backup password`
  String get backupPasswordWrong {
    return Intl.message(
      'Incorrect backup password',
      name: 'backupPasswordWrong',
      desc: '',
      args: [],
    );
  }

  /// `Only English letters, digits and symbols are supported`
  String get backupPasswordTip {
    return Intl.message(
      'Only English letters, digits and symbols are supported',
      name: 'backupPasswordTip',
      desc: '',
      args: [],
    );
  }

  /// `Backup encrypted with AES-256`
  String get backupEncryptedTip {
    return Intl.message(
      'Backup encrypted with AES-256',
      name: 'backupEncryptedTip',
      desc: '',
      args: [],
    );
  }

  /// `Decrypted and restored with the current password`
  String get recoveryDecryptedTip {
    return Intl.message(
      'Decrypted and restored with the current password',
      name: 'recoveryDecryptedTip',
      desc: '',
      args: [],
    );
  }

  /// `No Info`
  String get noInfo {
    return Intl.message('No Info', name: 'noInfo', desc: '', args: []);
  }

  /// `Please bind WebDAV`
  String get pleaseBindWebDAV {
    return Intl.message(
      'Please bind WebDAV',
      name: 'pleaseBindWebDAV',
      desc: '',
      args: [],
    );
  }

  /// `Bind`
  String get bind {
    return Intl.message('Bind', name: 'bind', desc: '', args: []);
  }

  /// `Connectivity:`
  String get connectivity {
    return Intl.message(
      'Connectivity:',
      name: 'connectivity',
      desc: '',
      args: [],
    );
  }

  /// `WebDAV Configuration`
  String get webDAVConfiguration {
    return Intl.message(
      'WebDAV Configuration',
      name: 'webDAVConfiguration',
      desc: '',
      args: [],
    );
  }

  /// `Address`
  String get address {
    return Intl.message('Address', name: 'address', desc: '', args: []);
  }

  /// `WebDAV server address`
  String get addressHelp {
    return Intl.message(
      'WebDAV server address',
      name: 'addressHelp',
      desc: '',
      args: [],
    );
  }

  /// `Please enter a valid WebDAV address`
  String get addressTip {
    return Intl.message(
      'Please enter a valid WebDAV address',
      name: 'addressTip',
      desc: '',
      args: [],
    );
  }

  /// `Password`
  String get password {
    return Intl.message('Password', name: 'password', desc: '', args: []);
  }

  /// `Check for Updates`
  String get checkUpdate {
    return Intl.message(
      'Check for Updates',
      name: 'checkUpdate',
      desc: '',
      args: [],
    );
  }

  /// `New Version Available`
  String get discoverNewVersion {
    return Intl.message(
      'New Version Available',
      name: 'discoverNewVersion',
      desc: '',
      args: [],
    );
  }

  /// `Already on the latest version`
  String get checkUpdateError {
    return Intl.message(
      'Already on the latest version',
      name: 'checkUpdateError',
      desc: '',
      args: [],
    );
  }

  /// `Download Now`
  String get goDownload {
    return Intl.message('Download Now', name: 'goDownload', desc: '', args: []);
  }

  /// `View Changelog`
  String get viewChangelog {
    return Intl.message(
      'View Changelog',
      name: 'viewChangelog',
      desc: '',
      args: [],
    );
  }

  /// `Unknown`
  String get unknown {
    return Intl.message('Unknown', name: 'unknown', desc: '', args: []);
  }

  /// `GeoData`
  String get geoData {
    return Intl.message('GeoData', name: 'geoData', desc: '', args: []);
  }

  /// `External Resources`
  String get externalResources {
    return Intl.message(
      'External Resources',
      name: 'externalResources',
      desc: '',
      args: [],
    );
  }

  /// `Checking...`
  String get checking {
    return Intl.message('Checking...', name: 'checking', desc: '', args: []);
  }

  /// `Country`
  String get country {
    return Intl.message('Country', name: 'country', desc: '', args: []);
  }

  /// `Check Failed`
  String get checkError {
    return Intl.message('Check Failed', name: 'checkError', desc: '', args: []);
  }

  /// `Search`
  String get search {
    return Intl.message('Search', name: 'search', desc: '', args: []);
  }

  /// `Replace`
  String get replace {
    return Intl.message('Replace', name: 'replace', desc: '', args: []);
  }

  /// `Replace All`
  String get replaceAll {
    return Intl.message('Replace All', name: 'replaceAll', desc: '', args: []);
  }

  /// `Allow Bypassing VPN`
  String get allowBypass {
    return Intl.message(
      'Allow Bypassing VPN',
      name: 'allowBypass',
      desc: '',
      args: [],
    );
  }

  /// `Allow specific apps to bypass VPN`
  String get allowBypassDesc {
    return Intl.message(
      'Allow specific apps to bypass VPN',
      name: 'allowBypassDesc',
      desc: '',
      args: [],
    );
  }

  /// `External Controller`
  String get externalController {
    return Intl.message(
      'External Controller',
      name: 'externalController',
      desc: '',
      args: [],
    );
  }

  /// `Control core via online port`
  String get externalControllerDesc {
    return Intl.message(
      'Control core via online port',
      name: 'externalControllerDesc',
      desc: '',
      args: [],
    );
  }

  /// `Control Secret`
  String get controlSecret {
    return Intl.message(
      'Control Secret',
      name: 'controlSecret',
      desc: '',
      args: [],
    );
  }

  /// `RESTful API access password`
  String get controlSecretDesc {
    return Intl.message(
      'RESTful API access password',
      name: 'controlSecretDesc',
      desc: '',
      args: [],
    );
  }

  /// `Generate`
  String get generateSecret {
    return Intl.message('Generate', name: 'generateSecret', desc: '', args: []);
  }

  /// `Secret copied to clipboard`
  String get secretCopied {
    return Intl.message(
      'Secret copied to clipboard',
      name: 'secretCopied',
      desc: '',
      args: [],
    );
  }

  /// `Enable IPv6 traffic routing`
  String get ipv6Desc {
    return Intl.message(
      'Enable IPv6 traffic routing',
      name: 'ipv6Desc',
      desc: '',
      args: [],
    );
  }

  /// `App`
  String get app {
    return Intl.message('App', name: 'app', desc: '', args: []);
  }

  /// `General`
  String get general {
    return Intl.message('General', name: 'general', desc: '', args: []);
  }

  /// `Attach HTTP proxy to VpnService`
  String get vpnSystemProxyDesc {
    return Intl.message(
      'Attach HTTP proxy to VpnService',
      name: 'vpnSystemProxyDesc',
      desc: '',
      args: [],
    );
  }

  /// `Set system proxy`
  String get systemProxyDesc {
    return Intl.message(
      'Set system proxy',
      name: 'systemProxyDesc',
      desc: '',
      args: [],
    );
  }

  /// `Unified Delay`
  String get unifiedDelay {
    return Intl.message(
      'Unified Delay',
      name: 'unifiedDelay',
      desc: '',
      args: [],
    );
  }

  /// `Exclude handshake delays from testing`
  String get unifiedDelayDesc {
    return Intl.message(
      'Exclude handshake delays from testing',
      name: 'unifiedDelayDesc',
      desc: '',
      args: [],
    );
  }

  /// `TCP Concurrent`
  String get tcpConcurrent {
    return Intl.message(
      'TCP Concurrent',
      name: 'tcpConcurrent',
      desc: '',
      args: [],
    );
  }

  /// `Allow concurrent TCP connections`
  String get tcpConcurrentDesc {
    return Intl.message(
      'Allow concurrent TCP connections',
      name: 'tcpConcurrentDesc',
      desc: '',
      args: [],
    );
  }

  /// `GEO Low Memory`
  String get geodataLoader {
    return Intl.message(
      'GEO Low Memory',
      name: 'geodataLoader',
      desc: '',
      args: [],
    );
  }

  /// `Use GEO low memory loader`
  String get geodataLoaderDesc {
    return Intl.message(
      'Use GEO low memory loader',
      name: 'geodataLoaderDesc',
      desc: '',
      args: [],
    );
  }

  /// `Find Process`
  String get findProcessMode {
    return Intl.message(
      'Find Process',
      name: 'findProcessMode',
      desc: '',
      args: [],
    );
  }

  /// `Init`
  String get init {
    return Intl.message('Init', name: 'init', desc: '', args: []);
  }

  /// `Never Expires`
  String get infiniteTime {
    return Intl.message(
      'Never Expires',
      name: 'infiniteTime',
      desc: '',
      args: [],
    );
  }

  /// `Expiration Time`
  String get expirationTime {
    return Intl.message(
      'Expiration Time',
      name: 'expirationTime',
      desc: '',
      args: [],
    );
  }

  /// `Connections`
  String get connections {
    return Intl.message('Connections', name: 'connections', desc: '', args: []);
  }

  /// `View active and closed connections`
  String get connectionsDesc {
    return Intl.message(
      'View active and closed connections',
      name: 'connectionsDesc',
      desc: '',
      args: [],
    );
  }

  /// `Active`
  String get connectionsActive {
    return Intl.message(
      'Active',
      name: 'connectionsActive',
      desc: '',
      args: [],
    );
  }

  /// `Closed`
  String get connectionsClosed {
    return Intl.message(
      'Closed',
      name: 'connectionsClosed',
      desc: '',
      args: [],
    );
  }

  /// `Local IP`
  String get intranetIP {
    return Intl.message('Local IP', name: 'intranetIP', desc: '', args: []);
  }

  /// `View`
  String get view {
    return Intl.message('View', name: 'view', desc: '', args: []);
  }

  /// `Cut`
  String get cut {
    return Intl.message('Cut', name: 'cut', desc: '', args: []);
  }

  /// `Copy`
  String get copy {
    return Intl.message('Copy', name: 'copy', desc: '', args: []);
  }

  /// `Paste`
  String get paste {
    return Intl.message('Paste', name: 'paste', desc: '', args: []);
  }

  /// `Test URL`
  String get testUrl {
    return Intl.message('Test URL', name: 'testUrl', desc: '', args: []);
  }

  /// `Delay Test`
  String get startTest {
    return Intl.message('Delay Test', name: 'startTest', desc: '', args: []);
  }

  /// `Add Profile`
  String get addProfile {
    return Intl.message('Add Profile', name: 'addProfile', desc: '', args: []);
  }

  /// `Custom URL`
  String get customUrl {
    return Intl.message('Custom URL', name: 'customUrl', desc: '', args: []);
  }

  /// `Sync`
  String get sync {
    return Intl.message('Sync', name: 'sync', desc: '', args: []);
  }

  /// `Hide from Recents`
  String get exclude {
    return Intl.message(
      'Hide from Recents',
      name: 'exclude',
      desc: '',
      args: [],
    );
  }

  /// `Hide app from recent tasks list`
  String get excludeDesc {
    return Intl.message(
      'Hide app from recent tasks list',
      name: 'excludeDesc',
      desc: '',
      args: [],
    );
  }

  /// `1 Column`
  String get oneColumn {
    return Intl.message('1 Column', name: 'oneColumn', desc: '', args: []);
  }

  /// `2 Columns`
  String get twoColumns {
    return Intl.message('2 Columns', name: 'twoColumns', desc: '', args: []);
  }

  /// `3 Columns`
  String get threeColumns {
    return Intl.message('3 Columns', name: 'threeColumns', desc: '', args: []);
  }

  /// `4 Columns`
  String get fourColumns {
    return Intl.message('4 Columns', name: 'fourColumns', desc: '', args: []);
  }

  /// `Standard`
  String get expand {
    return Intl.message('Standard', name: 'expand', desc: '', args: []);
  }

  /// `Compact`
  String get shrink {
    return Intl.message('Compact', name: 'shrink', desc: '', args: []);
  }

  /// `Min`
  String get min {
    return Intl.message('Min', name: 'min', desc: '', args: []);
  }

  /// `Tab`
  String get tab {
    return Intl.message('Tab', name: 'tab', desc: '', args: []);
  }

  /// `List`
  String get list {
    return Intl.message('List', name: 'list', desc: '', args: []);
  }

  /// `Delay`
  String get delay {
    return Intl.message('Delay', name: 'delay', desc: '', args: []);
  }

  /// `Style`
  String get style {
    return Intl.message('Style', name: 'style', desc: '', args: []);
  }

  /// `Size`
  String get size {
    return Intl.message('Size', name: 'size', desc: '', args: []);
  }

  /// `Delay Animation`
  String get delayAnimation {
    return Intl.message(
      'Delay Animation',
      name: 'delayAnimation',
      desc: '',
      args: [],
    );
  }

  /// `Customize animation during delay testing`
  String get delayAnimationDesc {
    return Intl.message(
      'Customize animation during delay testing',
      name: 'delayAnimationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Sync animation to other pages`
  String get syncDelayAnimation {
    return Intl.message(
      'Sync animation to other pages',
      name: 'syncDelayAnimation',
      desc: '',
      args: [],
    );
  }

  /// `Default`
  String get noAnimation {
    return Intl.message('Default', name: 'noAnimation', desc: '', args: []);
  }

  /// `Rotating Circle`
  String get rotatingCircle {
    return Intl.message(
      'Rotating Circle',
      name: 'rotatingCircle',
      desc: '',
      args: [],
    );
  }

  /// `Pulse`
  String get pulse {
    return Intl.message('Pulse', name: 'pulse', desc: '', args: []);
  }

  /// `Spinning Lines`
  String get spinningLines {
    return Intl.message(
      'Spinning Lines',
      name: 'spinningLines',
      desc: '',
      args: [],
    );
  }

  /// `Three In Out`
  String get threeInOut {
    return Intl.message('Three In Out', name: 'threeInOut', desc: '', args: []);
  }

  /// `Three Bounce`
  String get threeBounce {
    return Intl.message(
      'Three Bounce',
      name: 'threeBounce',
      desc: '',
      args: [],
    );
  }

  /// `Circle`
  String get circle {
    return Intl.message('Circle', name: 'circle', desc: '', args: []);
  }

  /// `Fading Circle`
  String get fadingCircle {
    return Intl.message(
      'Fading Circle',
      name: 'fadingCircle',
      desc: '',
      args: [],
    );
  }

  /// `Fading Four`
  String get fadingFour {
    return Intl.message('Fading Four', name: 'fadingFour', desc: '', args: []);
  }

  /// `Wave`
  String get wave {
    return Intl.message('Wave', name: 'wave', desc: '', args: []);
  }

  /// `Double Bounce`
  String get doubleBounce {
    return Intl.message(
      'Double Bounce',
      name: 'doubleBounce',
      desc: '',
      args: [],
    );
  }

  /// `Chasing Dots`
  String get chasingDots {
    return Intl.message(
      'Chasing Dots',
      name: 'chasingDots',
      desc: '',
      args: [],
    );
  }

  /// `Cube Grid`
  String get cubeGrid {
    return Intl.message('Cube Grid', name: 'cubeGrid', desc: '', args: []);
  }

  /// `Dancing Square`
  String get dancingSquare {
    return Intl.message(
      'Dancing Square',
      name: 'dancingSquare',
      desc: '',
      args: [],
    );
  }

  /// `Dual Ring`
  String get dualRing {
    return Intl.message('Dual Ring', name: 'dualRing', desc: '', args: []);
  }

  /// `Fading Cube`
  String get fadingCube {
    return Intl.message('Fading Cube', name: 'fadingCube', desc: '', args: []);
  }

  /// `Fading Grid`
  String get fadingGrid {
    return Intl.message('Fading Grid', name: 'fadingGrid', desc: '', args: []);
  }

  /// `Folding Cube`
  String get foldingCube {
    return Intl.message(
      'Folding Cube',
      name: 'foldingCube',
      desc: '',
      args: [],
    );
  }

  /// `Hourglass`
  String get hourGlass {
    return Intl.message('Hourglass', name: 'hourGlass', desc: '', args: []);
  }

  /// `Piano Wave`
  String get pianoWave {
    return Intl.message('Piano Wave', name: 'pianoWave', desc: '', args: []);
  }

  /// `Pouring Hourglass`
  String get pouringHourGlass {
    return Intl.message(
      'Pouring Hourglass',
      name: 'pouringHourGlass',
      desc: '',
      args: [],
    );
  }

  /// `Refined Hourglass`
  String get pouringHourGlassRefined {
    return Intl.message(
      'Refined Hourglass',
      name: 'pouringHourGlassRefined',
      desc: '',
      args: [],
    );
  }

  /// `Pulsing Grid`
  String get pulsingGrid {
    return Intl.message(
      'Pulsing Grid',
      name: 'pulsingGrid',
      desc: '',
      args: [],
    );
  }

  /// `Pumping Heart`
  String get pumpingHeart {
    return Intl.message(
      'Pumping Heart',
      name: 'pumpingHeart',
      desc: '',
      args: [],
    );
  }

  /// `Ring`
  String get ring {
    return Intl.message('Ring', name: 'ring', desc: '', args: []);
  }

  /// `Ripple`
  String get ripple {
    return Intl.message('Ripple', name: 'ripple', desc: '', args: []);
  }

  /// `Rotating Plain`
  String get rotatingPlain {
    return Intl.message(
      'Rotating Plain',
      name: 'rotatingPlain',
      desc: '',
      args: [],
    );
  }

  /// `Spinning Circle`
  String get spinningCircle {
    return Intl.message(
      'Spinning Circle',
      name: 'spinningCircle',
      desc: '',
      args: [],
    );
  }

  /// `Square Circle`
  String get squareCircle {
    return Intl.message(
      'Square Circle',
      name: 'squareCircle',
      desc: '',
      args: [],
    );
  }

  /// `Wandering Cubes`
  String get wanderingCubes {
    return Intl.message(
      'Wandering Cubes',
      name: 'wanderingCubes',
      desc: '',
      args: [],
    );
  }

  /// `Wave Spinner`
  String get waveSpinner {
    return Intl.message(
      'Wave Spinner',
      name: 'waveSpinner',
      desc: '',
      args: [],
    );
  }

  /// `Sort`
  String get sort {
    return Intl.message('Sort', name: 'sort', desc: '', args: []);
  }

  /// `Columns`
  String get columns {
    return Intl.message('Columns', name: 'columns', desc: '', args: []);
  }

  /// `Proxy Settings`
  String get proxiesSetting {
    return Intl.message(
      'Proxy Settings',
      name: 'proxiesSetting',
      desc: '',
      args: [],
    );
  }

  /// `Proxy Group`
  String get proxyGroup {
    return Intl.message('Proxy Group', name: 'proxyGroup', desc: '', args: []);
  }

  /// `Go`
  String get go {
    return Intl.message('Go', name: 'go', desc: '', args: []);
  }

  /// `External Link`
  String get externalLink {
    return Intl.message(
      'External Link',
      name: 'externalLink',
      desc: '',
      args: [],
    );
  }

  /// `Other Contributors (Random Order)`
  String get otherContributors {
    return Intl.message(
      'Other Contributors (Random Order)',
      name: 'otherContributors',
      desc: '',
      args: [],
    );
  }

  /// `Auto-Close Connections`
  String get autoCloseConnections {
    return Intl.message(
      'Auto-Close Connections',
      name: 'autoCloseConnections',
      desc: '',
      args: [],
    );
  }

  /// `Close connections when switching nodes`
  String get autoCloseConnectionsDesc {
    return Intl.message(
      'Close connections when switching nodes',
      name: 'autoCloseConnectionsDesc',
      desc: '',
      args: [],
    );
  }

  /// `Proxy Traffic Only`
  String get onlyStatisticsProxy {
    return Intl.message(
      'Proxy Traffic Only',
      name: 'onlyStatisticsProxy',
      desc: '',
      args: [],
    );
  }

  /// `Only record proxy traffic`
  String get onlyStatisticsProxyDesc {
    return Intl.message(
      'Only record proxy traffic',
      name: 'onlyStatisticsProxyDesc',
      desc: '',
      args: [],
    );
  }

  /// `TCP keep-alive interval`
  String get keepAliveIntervalDesc {
    return Intl.message(
      'TCP keep-alive interval',
      name: 'keepAliveIntervalDesc',
      desc: '',
      args: [],
    );
  }

  /// ` entries`
  String get entries {
    return Intl.message(' entries', name: 'entries', desc: '', args: []);
  }

  /// `Local`
  String get local {
    return Intl.message('Local', name: 'local', desc: '', args: []);
  }

  /// `Remote`
  String get remote {
    return Intl.message('Remote', name: 'remote', desc: '', args: []);
  }

  /// `Backup data to WebDAV`
  String get remoteBackupDesc {
    return Intl.message(
      'Backup data to WebDAV',
      name: 'remoteBackupDesc',
      desc: '',
      args: [],
    );
  }

  /// `Restore data from WebDAV`
  String get remoteRecoveryDesc {
    return Intl.message(
      'Restore data from WebDAV',
      name: 'remoteRecoveryDesc',
      desc: '',
      args: [],
    );
  }

  /// `Auto Backup`
  String get autoBackup {
    return Intl.message('Auto Backup', name: 'autoBackup', desc: '', args: []);
  }

  /// `Auto back up on profile changes`
  String get autoBackupDesc {
    return Intl.message(
      'Auto back up on profile changes',
      name: 'autoBackupDesc',
      desc: '',
      args: [],
    );
  }

  /// `Auto backed up to WebDAV`
  String get autoBackupSuccess {
    return Intl.message(
      'Auto backed up to WebDAV',
      name: 'autoBackupSuccess',
      desc: '',
      args: [],
    );
  }

  /// `Auto backup failed: {error}`
  String autoBackupFailed(Object error) {
    return Intl.message(
      'Auto backup failed: $error',
      name: 'autoBackupFailed',
      desc: '',
      args: [error],
    );
  }

  /// `Backup data locally`
  String get localBackupDesc {
    return Intl.message(
      'Backup data locally',
      name: 'localBackupDesc',
      desc: '',
      args: [],
    );
  }

  /// `Restore data from file`
  String get localRecoveryDesc {
    return Intl.message(
      'Restore data from file',
      name: 'localRecoveryDesc',
      desc: '',
      args: [],
    );
  }

  /// `Mode`
  String get mode {
    return Intl.message('Mode', name: 'mode', desc: '', args: []);
  }

  /// `Time`
  String get time {
    return Intl.message('Time', name: 'time', desc: '', args: []);
  }

  /// `Source`
  String get source {
    return Intl.message('Source', name: 'source', desc: '', args: []);
  }

  /// `All Apps`
  String get allApps {
    return Intl.message('All Apps', name: 'allApps', desc: '', args: []);
  }

  /// `Third-Party Apps Only`
  String get onlyOtherApps {
    return Intl.message(
      'Third-Party Apps Only',
      name: 'onlyOtherApps',
      desc: '',
      args: [],
    );
  }

  /// `Action`
  String get action {
    return Intl.message('Action', name: 'action', desc: '', args: []);
  }

  /// `Smart Select`
  String get intelligentSelected {
    return Intl.message(
      'Smart Select',
      name: 'intelligentSelected',
      desc: '',
      args: [],
    );
  }

  /// `Auto-select using preset rules?`
  String get intelligentSelectedConfirm {
    return Intl.message(
      'Auto-select using preset rules?',
      name: 'intelligentSelectedConfirm',
      desc: '',
      args: [],
    );
  }

  /// `Import from Clipboard`
  String get clipboardImport {
    return Intl.message(
      'Import from Clipboard',
      name: 'clipboardImport',
      desc: '',
      args: [],
    );
  }

  /// `Export to Clipboard`
  String get clipboardExport {
    return Intl.message(
      'Export to Clipboard',
      name: 'clipboardExport',
      desc: '',
      args: [],
    );
  }

  /// `Layout`
  String get layout {
    return Intl.message('Layout', name: 'layout', desc: '', args: []);
  }

  /// `Compact`
  String get tight {
    return Intl.message('Compact', name: 'tight', desc: '', args: []);
  }

  /// `Standard`
  String get standard {
    return Intl.message('Standard', name: 'standard', desc: '', args: []);
  }

  /// `Loose`
  String get loose {
    return Intl.message('Loose', name: 'loose', desc: '', args: []);
  }

  /// `Profile Sorting`
  String get profilesSort {
    return Intl.message(
      'Profile Sorting',
      name: 'profilesSort',
      desc: '',
      args: [],
    );
  }

  /// `Start`
  String get start {
    return Intl.message('Start', name: 'start', desc: '', args: []);
  }

  /// `No usage data`
  String get noUsageData {
    return Intl.message(
      'No usage data',
      name: 'noUsageData',
      desc: '',
      args: [],
    );
  }

  /// `Local File`
  String get localFile {
    return Intl.message('Local File', name: 'localFile', desc: '', args: []);
  }

  /// `Expired`
  String get expired {
    return Intl.message('Expired', name: 'expired', desc: '', args: []);
  }

  /// `Last edited`
  String get lastEdit {
    return Intl.message('Last edited', name: 'lastEdit', desc: '', args: []);
  }

  /// `Stop`
  String get stop {
    return Intl.message('Stop', name: 'stop', desc: '', args: []);
  }

  /// `Power`
  String get powerSwitch {
    return Intl.message('Power', name: 'powerSwitch', desc: '', args: []);
  }

  /// `Uptime`
  String get runTime {
    return Intl.message('Uptime', name: 'runTime', desc: '', args: []);
  }

  /// `Please add a profile first`
  String get checkOrAddProfile {
    return Intl.message(
      'Please add a profile first',
      name: 'checkOrAddProfile',
      desc: '',
      args: [],
    );
  }

  /// `Service Ready`
  String get serviceReady {
    return Intl.message(
      'Service Ready',
      name: 'serviceReady',
      desc: '',
      args: [],
    );
  }

  /// `App-related settings`
  String get appDesc {
    return Intl.message(
      'App-related settings',
      name: 'appDesc',
      desc: '',
      args: [],
    );
  }

  /// `VPN-related settings`
  String get vpnDesc {
    return Intl.message(
      'VPN-related settings',
      name: 'vpnDesc',
      desc: '',
      args: [],
    );
  }

  /// `Key`
  String get key {
    return Intl.message('Key', name: 'key', desc: '', args: []);
  }

  /// `Value`
  String get value {
    return Intl.message('Value', name: 'value', desc: '', args: []);
  }

  /// `Append hosts to current config`
  String get hostsDesc {
    return Intl.message(
      'Append hosts to current config',
      name: 'hostsDesc',
      desc: '',
      args: [],
    );
  }

  /// `Restart VPN to apply changes`
  String get vpnTip {
    return Intl.message(
      'Restart VPN to apply changes',
      name: 'vpnTip',
      desc: '',
      args: [],
    );
  }

  /// `Route traffic via VpnService`
  String get vpnEnableDesc {
    return Intl.message(
      'Route traffic via VpnService',
      name: 'vpnEnableDesc',
      desc: '',
      args: [],
    );
  }

  /// `Options`
  String get options {
    return Intl.message('Options', name: 'options', desc: '', args: []);
  }

  /// `Loopback Unlock`
  String get loopback {
    return Intl.message(
      'Loopback Unlock',
      name: 'loopback',
      desc: '',
      args: [],
    );
  }

  /// `UWP loopback unlocking tool`
  String get loopbackDesc {
    return Intl.message(
      'UWP loopback unlocking tool',
      name: 'loopbackDesc',
      desc: '',
      args: [],
    );
  }

  /// `Providers`
  String get providers {
    return Intl.message('Providers', name: 'providers', desc: '', args: []);
  }

  /// `Proxy Providers`
  String get proxyProviders {
    return Intl.message(
      'Proxy Providers',
      name: 'proxyProviders',
      desc: '',
      args: [],
    );
  }

  /// `Rule Providers`
  String get ruleProviders {
    return Intl.message(
      'Rule Providers',
      name: 'ruleProviders',
      desc: '',
      args: [],
    );
  }

  /// `Advanced Settings`
  String get advancedSettings {
    return Intl.message(
      'Advanced Settings',
      name: 'advancedSettings',
      desc: '',
      args: [],
    );
  }

  /// `Node Exclusion`
  String get nodeExclusion {
    return Intl.message(
      'Node Exclusion',
      name: 'nodeExclusion',
      desc: '',
      args: [],
    );
  }

  /// `Exclude all matched nodes`
  String get nodeExclusionDesc {
    return Intl.message(
      'Exclude all matched nodes',
      name: 'nodeExclusionDesc',
      desc: '',
      args: [],
    );
  }

  /// `HK|Hong Kong|🇭🇰`
  String get nodeExclusionPlaceholder {
    return Intl.message(
      'HK|Hong Kong|🇭🇰',
      name: 'nodeExclusionPlaceholder',
      desc: '',
      args: [],
    );
  }

  /// `Please check the format`
  String get formatError {
    return Intl.message(
      'Please check the format',
      name: 'formatError',
      desc: '',
      args: [],
    );
  }

  /// `Timeout`
  String get healthCheckTimeout {
    return Intl.message(
      'Timeout',
      name: 'healthCheckTimeout',
      desc: '',
      args: [],
    );
  }

  /// `Node health check timeout`
  String get healthCheckTimeoutDesc {
    return Intl.message(
      'Node health check timeout',
      name: 'healthCheckTimeoutDesc',
      desc: '',
      args: [],
    );
  }

  /// `Concurrency Limit`
  String get concurrencyLimit {
    return Intl.message(
      'Concurrency Limit',
      name: 'concurrencyLimit',
      desc: '',
      args: [],
    );
  }

  /// `Maximum concurrent delay tests`
  String get concurrencyLimitDesc {
    return Intl.message(
      'Maximum concurrent delay tests',
      name: 'concurrencyLimitDesc',
      desc: '',
      args: [],
    );
  }

  /// `Not Recommended`
  String get notRecommended {
    return Intl.message(
      'Not Recommended',
      name: 'notRecommended',
      desc: '',
      args: [],
    );
  }

  /// `NTP`
  String get ntp {
    return Intl.message('NTP', name: 'ntp', desc: '', args: []);
  }

  /// `Use NTP time service`
  String get ntpDesc {
    return Intl.message(
      'Use NTP time service',
      name: 'ntpDesc',
      desc: '',
      args: [],
    );
  }

  /// `Override NTP`
  String get overrideNtp {
    return Intl.message(
      'Override NTP',
      name: 'overrideNtp',
      desc: '',
      args: [],
    );
  }

  /// `Override profile's NTP settings`
  String get overrideNtpDesc {
    return Intl.message(
      'Override profile\'s NTP settings',
      name: 'overrideNtpDesc',
      desc: '',
      args: [],
    );
  }

  /// `Status`
  String get ntpStatus {
    return Intl.message('Status', name: 'ntpStatus', desc: '', args: []);
  }

  /// `Enable NTP time service`
  String get ntpStatusDesc {
    return Intl.message(
      'Enable NTP time service',
      name: 'ntpStatusDesc',
      desc: '',
      args: [],
    );
  }

  /// `Write to System`
  String get writeToSystem {
    return Intl.message(
      'Write to System',
      name: 'writeToSystem',
      desc: '',
      args: [],
    );
  }

  /// `Requires administrator privileges`
  String get writeToSystemDesc {
    return Intl.message(
      'Requires administrator privileges',
      name: 'writeToSystemDesc',
      desc: '',
      args: [],
    );
  }

  /// `Server`
  String get ntpServer {
    return Intl.message('Server', name: 'ntpServer', desc: '', args: []);
  }

  /// `Port`
  String get ntpPort {
    return Intl.message('Port', name: 'ntpPort', desc: '', args: []);
  }

  /// `Update Interval`
  String get ntpInterval {
    return Intl.message(
      'Update Interval',
      name: 'ntpInterval',
      desc: '',
      args: [],
    );
  }

  /// `Sniffer`
  String get sniffer {
    return Intl.message('Sniffer', name: 'sniffer', desc: '', args: []);
  }

  /// `Modify domain sniffer config`
  String get snifferDesc {
    return Intl.message(
      'Modify domain sniffer config',
      name: 'snifferDesc',
      desc: '',
      args: [],
    );
  }

  /// `Override Sniffer`
  String get overrideSniffer {
    return Intl.message(
      'Override Sniffer',
      name: 'overrideSniffer',
      desc: '',
      args: [],
    );
  }

  /// `Override profile's Sniffer settings`
  String get overrideSnifferDesc {
    return Intl.message(
      'Override profile\'s Sniffer settings',
      name: 'overrideSnifferDesc',
      desc: '',
      args: [],
    );
  }

  /// `Status`
  String get snifferStatus {
    return Intl.message('Status', name: 'snifferStatus', desc: '', args: []);
  }

  /// `Enable Sniffer service`
  String get snifferStatusDesc {
    return Intl.message(
      'Enable Sniffer service',
      name: 'snifferStatusDesc',
      desc: '',
      args: [],
    );
  }

  /// `Force DNS Mapping`
  String get forceDnsMapping {
    return Intl.message(
      'Force DNS Mapping',
      name: 'forceDnsMapping',
      desc: '',
      args: [],
    );
  }

  /// `Force mapping DNS results to connections`
  String get forceDnsMappingDesc {
    return Intl.message(
      'Force mapping DNS results to connections',
      name: 'forceDnsMappingDesc',
      desc: '',
      args: [],
    );
  }

  /// `Parse Pure IP`
  String get parsePureIp {
    return Intl.message(
      'Parse Pure IP',
      name: 'parsePureIp',
      desc: '',
      args: [],
    );
  }

  /// `Parse pure IP connections`
  String get parsePureIpDesc {
    return Intl.message(
      'Parse pure IP connections',
      name: 'parsePureIpDesc',
      desc: '',
      args: [],
    );
  }

  /// `Override Destination`
  String get overrideDestination {
    return Intl.message(
      'Override Destination',
      name: 'overrideDestination',
      desc: '',
      args: [],
    );
  }

  /// `Override destination with sniffed result`
  String get overrideDestinationDesc {
    return Intl.message(
      'Override destination with sniffed result',
      name: 'overrideDestinationDesc',
      desc: '',
      args: [],
    );
  }

  /// `HTTP Port Sniffing`
  String get httpPortSniffer {
    return Intl.message(
      'HTTP Port Sniffing',
      name: 'httpPortSniffer',
      desc: '',
      args: [],
    );
  }

  /// `TLS Port Sniffing`
  String get tlsPortSniffer {
    return Intl.message(
      'TLS Port Sniffing',
      name: 'tlsPortSniffer',
      desc: '',
      args: [],
    );
  }

  /// `QUIC Port Sniffing`
  String get quicPortSniffer {
    return Intl.message(
      'QUIC Port Sniffing',
      name: 'quicPortSniffer',
      desc: '',
      args: [],
    );
  }

  /// `Force Sniff Domain`
  String get forceDomain {
    return Intl.message(
      'Force Sniff Domain',
      name: 'forceDomain',
      desc: '',
      args: [],
    );
  }

  /// `Skip Domain`
  String get skipDomain {
    return Intl.message('Skip Domain', name: 'skipDomain', desc: '', args: []);
  }

  /// `Skip Source IP`
  String get skipSrcAddress {
    return Intl.message(
      'Skip Source IP',
      name: 'skipSrcAddress',
      desc: '',
      args: [],
    );
  }

  /// `Skip Destination IP`
  String get skipDstAddress {
    return Intl.message(
      'Skip Destination IP',
      name: 'skipDstAddress',
      desc: '',
      args: [],
    );
  }

  /// `Ports`
  String get snifferPorts {
    return Intl.message('Ports', name: 'snifferPorts', desc: '', args: []);
  }

  /// `e.g.: 80, 8080-8880`
  String get snifferPortsHint {
    return Intl.message(
      'e.g.: 80, 8080-8880',
      name: 'snifferPortsHint',
      desc: '',
      args: [],
    );
  }

  /// `One domain per line`
  String get snifferDomainHint {
    return Intl.message(
      'One domain per line',
      name: 'snifferDomainHint',
      desc: '',
      args: [],
    );
  }

  /// `One address per line`
  String get snifferAddressHint {
    return Intl.message(
      'One address per line',
      name: 'snifferAddressHint',
      desc: '',
      args: [],
    );
  }

  /// `Tunnel`
  String get tunnel {
    return Intl.message('Tunnel', name: 'tunnel', desc: '', args: []);
  }

  /// `Use traffic forwarding tunnel`
  String get tunnelDesc {
    return Intl.message(
      'Use traffic forwarding tunnel',
      name: 'tunnelDesc',
      desc: '',
      args: [],
    );
  }

  /// `Override Tunnel`
  String get overrideTunnel {
    return Intl.message(
      'Override Tunnel',
      name: 'overrideTunnel',
      desc: '',
      args: [],
    );
  }

  /// `Override profile's Tunnel settings`
  String get overrideTunnelDesc {
    return Intl.message(
      'Override profile\'s Tunnel settings',
      name: 'overrideTunnelDesc',
      desc: '',
      args: [],
    );
  }

  /// `Forwarding List`
  String get tunnelList {
    return Intl.message(
      'Forwarding List',
      name: 'tunnelList',
      desc: '',
      args: [],
    );
  }

  /// `Add Forwarding`
  String get addTunnel {
    return Intl.message(
      'Add Forwarding',
      name: 'addTunnel',
      desc: '',
      args: [],
    );
  }

  /// `Edit Forwarding`
  String get editTunnel {
    return Intl.message(
      'Edit Forwarding',
      name: 'editTunnel',
      desc: '',
      args: [],
    );
  }

  /// `Delete Forwarding`
  String get deleteTunnel {
    return Intl.message(
      'Delete Forwarding',
      name: 'deleteTunnel',
      desc: '',
      args: [],
    );
  }

  /// `Network Protocol`
  String get tunnelNetwork {
    return Intl.message(
      'Network Protocol',
      name: 'tunnelNetwork',
      desc: '',
      args: [],
    );
  }

  /// `e.g.: tcp, udp`
  String get tunnelNetworkHint {
    return Intl.message(
      'e.g.: tcp, udp',
      name: 'tunnelNetworkHint',
      desc: '',
      args: [],
    );
  }

  /// `Listen Address`
  String get tunnelAddress {
    return Intl.message(
      'Listen Address',
      name: 'tunnelAddress',
      desc: '',
      args: [],
    );
  }

  /// `e.g.: 127.0.0.1:6553`
  String get tunnelAddressHint {
    return Intl.message(
      'e.g.: 127.0.0.1:6553',
      name: 'tunnelAddressHint',
      desc: '',
      args: [],
    );
  }

  /// `Target Address`
  String get tunnelTarget {
    return Intl.message(
      'Target Address',
      name: 'tunnelTarget',
      desc: '',
      args: [],
    );
  }

  /// `e.g.: 114.114.114.114:53`
  String get tunnelTargetHint {
    return Intl.message(
      'e.g.: 114.114.114.114:53',
      name: 'tunnelTargetHint',
      desc: '',
      args: [],
    );
  }

  /// `Proxy Name`
  String get tunnelProxy {
    return Intl.message('Proxy Name', name: 'tunnelProxy', desc: '', args: []);
  }

  /// `e.g.: proxy (optional)`
  String get tunnelProxyHint {
    return Intl.message(
      'e.g.: proxy (optional)',
      name: 'tunnelProxyHint',
      desc: '',
      args: [],
    );
  }

  /// `Experimental`
  String get experimental {
    return Intl.message(
      'Experimental',
      name: 'experimental',
      desc: '',
      args: [],
    );
  }

  /// `Use with caution`
  String get experimentalDesc {
    return Intl.message(
      'Use with caution',
      name: 'experimentalDesc',
      desc: '',
      args: [],
    );
  }

  /// `Override Experimental`
  String get overrideExperimental {
    return Intl.message(
      'Override Experimental',
      name: 'overrideExperimental',
      desc: '',
      args: [],
    );
  }

  /// `Override profile's Experimental settings`
  String get overrideExperimentalDesc {
    return Intl.message(
      'Override profile\'s Experimental settings',
      name: 'overrideExperimentalDesc',
      desc: '',
      args: [],
    );
  }

  /// `Disable QUIC GSO`
  String get quicGoDisableGso {
    return Intl.message(
      'Disable QUIC GSO',
      name: 'quicGoDisableGso',
      desc: '',
      args: [],
    );
  }

  /// `Disable QUIC GSO`
  String get quicGoDisableGsoDesc {
    return Intl.message(
      'Disable QUIC GSO',
      name: 'quicGoDisableGsoDesc',
      desc: '',
      args: [],
    );
  }

  /// `Disable QUIC ECN`
  String get quicGoDisableEcn {
    return Intl.message(
      'Disable QUIC ECN',
      name: 'quicGoDisableEcn',
      desc: '',
      args: [],
    );
  }

  /// `Disable QUIC ECN`
  String get quicGoDisableEcnDesc {
    return Intl.message(
      'Disable QUIC ECN',
      name: 'quicGoDisableEcnDesc',
      desc: '',
      args: [],
    );
  }

  /// `Enable Dialer IP4P Conversion`
  String get dialerIp4pConvert {
    return Intl.message(
      'Enable Dialer IP4P Conversion',
      name: 'dialerIp4pConvert',
      desc: '',
      args: [],
    );
  }

  /// `Enable dialer IP4P conversion`
  String get dialerIp4pConvertDesc {
    return Intl.message(
      'Enable dialer IP4P conversion',
      name: 'dialerIp4pConvertDesc',
      desc: '',
      args: [],
    );
  }

  /// `DNS Mode`
  String get dnsMode {
    return Intl.message('DNS Mode', name: 'dnsMode', desc: '', args: []);
  }

  /// `Specify FakeIP filter mode`
  String get fakeIpFilterModeDesc {
    return Intl.message(
      'Specify FakeIP filter mode',
      name: 'fakeIpFilterModeDesc',
      desc: '',
      args: [],
    );
  }

  /// `IP/CIDR`
  String get ipcidr {
    return Intl.message('IP/CIDR', name: 'ipcidr', desc: '', args: []);
  }

  /// `Domain`
  String get domain {
    return Intl.message('Domain', name: 'domain', desc: '', args: []);
  }

  /// `Reset`
  String get reset {
    return Intl.message('Reset', name: 'reset', desc: '', args: []);
  }

  /// `Show/Hide`
  String get action_view {
    return Intl.message('Show/Hide', name: 'action_view', desc: '', args: []);
  }

  /// `Start/Stop`
  String get action_start {
    return Intl.message('Start/Stop', name: 'action_start', desc: '', args: []);
  }

  /// `Switch Mode`
  String get action_mode {
    return Intl.message('Switch Mode', name: 'action_mode', desc: '', args: []);
  }

  /// `System Proxy`
  String get action_proxy {
    return Intl.message(
      'System Proxy',
      name: 'action_proxy',
      desc: '',
      args: [],
    );
  }

  /// `TUN`
  String get action_tun {
    return Intl.message('TUN', name: 'action_tun', desc: '', args: []);
  }

  /// `Disclaimer`
  String get disclaimer {
    return Intl.message('Disclaimer', name: 'disclaimer', desc: '', args: []);
  }

  /// `This free open-source software is for non-commercial learning and personal use only. Proxy services are independent of this software. By agreeing, you acknowledge this; otherwise, please exit.`
  String get disclaimerDesc {
    return Intl.message(
      'This free open-source software is for non-commercial learning and personal use only. Proxy services are independent of this software. By agreeing, you acknowledge this; otherwise, please exit.',
      name: 'disclaimerDesc',
      desc: '',
      args: [],
    );
  }

  /// `Agree`
  String get agree {
    return Intl.message('Agree', name: 'agree', desc: '', args: []);
  }

  /// `Hotkey Management`
  String get hotkeyManagement {
    return Intl.message(
      'Hotkey Management',
      name: 'hotkeyManagement',
      desc: '',
      args: [],
    );
  }

  /// `Control app via keyboard`
  String get hotkeyManagementDesc {
    return Intl.message(
      'Control app via keyboard',
      name: 'hotkeyManagementDesc',
      desc: '',
      args: [],
    );
  }

  /// `Press a key`
  String get pressKeyboard {
    return Intl.message(
      'Press a key',
      name: 'pressKeyboard',
      desc: '',
      args: [],
    );
  }

  /// `Enter a valid hotkey`
  String get inputCorrectHotkey {
    return Intl.message(
      'Enter a valid hotkey',
      name: 'inputCorrectHotkey',
      desc: '',
      args: [],
    );
  }

  /// `Hotkey Conflict`
  String get hotkeyConflict {
    return Intl.message(
      'Hotkey Conflict',
      name: 'hotkeyConflict',
      desc: '',
      args: [],
    );
  }

  /// `Remove`
  String get remove {
    return Intl.message('Remove', name: 'remove', desc: '', args: []);
  }

  /// `No Hotkeys`
  String get noHotKey {
    return Intl.message('No Hotkeys', name: 'noHotKey', desc: '', args: []);
  }

  /// `No Network`
  String get noNetwork {
    return Intl.message('No Network', name: 'noNetwork', desc: '', args: []);
  }

  /// `Allow IPv6 inbound`
  String get ipv6InboundDesc {
    return Intl.message(
      'Allow IPv6 inbound',
      name: 'ipv6InboundDesc',
      desc: '',
      args: [],
    );
  }

  /// `Export Logs`
  String get exportLogs {
    return Intl.message('Export Logs', name: 'exportLogs', desc: '', args: []);
  }

  /// `Export Successful`
  String get exportSuccess {
    return Intl.message(
      'Export Successful',
      name: 'exportSuccess',
      desc: '',
      args: [],
    );
  }

  /// `Icon Style`
  String get iconStyle {
    return Intl.message('Icon Style', name: 'iconStyle', desc: '', args: []);
  }

  /// `Icon Only`
  String get onlyIcon {
    return Intl.message('Icon Only', name: 'onlyIcon', desc: '', args: []);
  }

  /// `No Icon`
  String get noIcon {
    return Intl.message('No Icon', name: 'noIcon', desc: '', args: []);
  }

  /// `Network Interface`
  String get networkInterface {
    return Intl.message(
      'Network Interface',
      name: 'networkInterface',
      desc: '',
      args: [],
    );
  }

  /// `Stack Mode`
  String get stackMode {
    return Intl.message('Stack Mode', name: 'stackMode', desc: '', args: []);
  }

  /// `Strict Route`
  String get strictRoute {
    return Intl.message(
      'Strict Route',
      name: 'strictRoute',
      desc: '',
      args: [],
    );
  }

  /// `Use TUN strict routing mode`
  String get strictRouteDesc {
    return Intl.message(
      'Use TUN strict routing mode',
      name: 'strictRouteDesc',
      desc: '',
      args: [],
    );
  }

  /// `ICMP Forwarding`
  String get icmpForwarding {
    return Intl.message(
      'ICMP Forwarding',
      name: 'icmpForwarding',
      desc: '',
      args: [],
    );
  }

  /// `Enable ICMP Ping`
  String get icmpForwardingDesc {
    return Intl.message(
      'Enable ICMP Ping',
      name: 'icmpForwardingDesc',
      desc: '',
      args: [],
    );
  }

  /// `DNS Hijack`
  String get dnsHijack {
    return Intl.message('DNS Hijack', name: 'dnsHijack', desc: '', args: []);
  }

  /// `Take over system DNS and route it to the core`
  String get dnsHijackDesc {
    return Intl.message(
      'Take over system DNS and route it to the core',
      name: 'dnsHijackDesc',
      desc: '',
      args: [],
    );
  }

  /// `NAT Enhancement`
  String get endpointIndependentNat {
    return Intl.message(
      'NAT Enhancement',
      name: 'endpointIndependentNat',
      desc: '',
      args: [],
    );
  }

  /// `Optimize UDP/P2P application experience`
  String get endpointIndependentNatDesc {
    return Intl.message(
      'Optimize UDP/P2P application experience',
      name: 'endpointIndependentNatDesc',
      desc: '',
      args: [],
    );
  }

  /// `Enabling Endpoint-Independent NAT feature may slightly degrade performance. It is recommended to enable it only if necessary and you are familiar with it.`
  String get endpointIndependentNatConfirmDesc {
    return Intl.message(
      'Enabling Endpoint-Independent NAT feature may slightly degrade performance. It is recommended to enable it only if necessary and you are familiar with it.',
      name: 'endpointIndependentNatConfirmDesc',
      desc: '',
      args: [],
    );
  }

  /// `Network`
  String get network {
    return Intl.message('Network', name: 'network', desc: '', args: []);
  }

  /// `Modify network-related settings`
  String get networkDesc {
    return Intl.message(
      'Modify network-related settings',
      name: 'networkDesc',
      desc: '',
      args: [],
    );
  }

  /// `Bypass Domain`
  String get bypassDomain {
    return Intl.message(
      'Bypass Domain',
      name: 'bypassDomain',
      desc: '',
      args: [],
    );
  }

  /// `Active only when System Proxy is on`
  String get bypassDomainDesc {
    return Intl.message(
      'Active only when System Proxy is on',
      name: 'bypassDomainDesc',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure you want to reset?`
  String get resetTip {
    return Intl.message(
      'Are you sure you want to reset?',
      name: 'resetTip',
      desc: '',
      args: [],
    );
  }

  /// `RegExp`
  String get regExp {
    return Intl.message('RegExp', name: 'regExp', desc: '', args: []);
  }

  /// `Icon`
  String get icon {
    return Intl.message('Icon', name: 'icon', desc: '', args: []);
  }

  /// `Icon Settings`
  String get iconConfiguration {
    return Intl.message(
      'Icon Settings',
      name: 'iconConfiguration',
      desc: '',
      args: [],
    );
  }

  /// `Customize proxy group ICON icons`
  String get iconConfigurationDesc {
    return Intl.message(
      'Customize proxy group ICON icons',
      name: 'iconConfigurationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Reset Icon Cache`
  String get resetIconCache {
    return Intl.message(
      'Reset Icon Cache',
      name: 'resetIconCache',
      desc: '',
      args: [],
    );
  }

  /// `Reset the local icon cache? This is safe, the app will fetch icons from their remote links again automatically.`
  String get resetIconCacheDesc {
    return Intl.message(
      'Reset the local icon cache? This is safe, the app will fetch icons from their remote links again automatically.',
      name: 'resetIconCacheDesc',
      desc: '',
      args: [],
    );
  }

  /// `No Data`
  String get noData {
    return Intl.message('No Data', name: 'noData', desc: '', args: []);
  }

  /// `Admin Auto-Launch`
  String get adminAutoLaunch {
    return Intl.message(
      'Admin Auto-Launch',
      name: 'adminAutoLaunch',
      desc: '',
      args: [],
    );
  }

  /// `Auto-start with admin privileges`
  String get adminAutoLaunchDesc {
    return Intl.message(
      'Auto-start with admin privileges',
      name: 'adminAutoLaunchDesc',
      desc: '',
      args: [],
    );
  }

  /// `Font`
  String get fontFamily {
    return Intl.message('Font', name: 'fontFamily', desc: '', args: []);
  }

  /// `System Font`
  String get systemFont {
    return Intl.message('System Font', name: 'systemFont', desc: '', args: []);
  }

  /// `Toggle`
  String get toggle {
    return Intl.message('Toggle', name: 'toggle', desc: '', args: []);
  }

  /// `System`
  String get system {
    return Intl.message('System', name: 'system', desc: '', args: []);
  }

  /// `Bypass Private Network`
  String get bypassPrivateRoute {
    return Intl.message(
      'Bypass Private Network',
      name: 'bypassPrivateRoute',
      desc: '',
      args: [],
    );
  }

  /// `Automatically bypass private network IP addresses`
  String get bypassPrivateRouteDesc {
    return Intl.message(
      'Automatically bypass private network IP addresses',
      name: 'bypassPrivateRouteDesc',
      desc: '',
      args: [],
    );
  }

  /// `Profile Switching`
  String get profileSwitchMode {
    return Intl.message(
      'Profile Switching',
      name: 'profileSwitchMode',
      desc: '',
      args: [],
    );
  }

  /// `Hot Reload`
  String get hotReload {
    return Intl.message('Hot Reload', name: 'hotReload', desc: '', args: []);
  }

  /// `Keeps the core running for faster profile switching`
  String get hotReloadDesc {
    return Intl.message(
      'Keeps the core running for faster profile switching',
      name: 'hotReloadDesc',
      desc: '',
      args: [],
    );
  }

  /// `Cold Restart`
  String get fullRestart {
    return Intl.message(
      'Cold Restart',
      name: 'fullRestart',
      desc: '',
      args: [],
    );
  }

  /// `Fully restarts the core for more thorough memory release`
  String get fullRestartDesc {
    return Intl.message(
      'Fully restarts the core for more thorough memory release',
      name: 'fullRestartDesc',
      desc: '',
      args: [],
    );
  }

  /// `Please enter the admin password`
  String get pleaseInputAdminPassword {
    return Intl.message(
      'Please enter the admin password',
      name: 'pleaseInputAdminPassword',
      desc: '',
      args: [],
    );
  }

  /// `Copy Environment Variable`
  String get copyEnvVar {
    return Intl.message(
      'Copy Environment Variable',
      name: 'copyEnvVar',
      desc: '',
      args: [],
    );
  }

  /// `Memory`
  String get memoryInfo {
    return Intl.message('Memory', name: 'memoryInfo', desc: '', args: []);
  }

  /// `The current memory information value displayed is the dynamic stack memory usage of the core during runtime, not the complete APP memory statistics, for reference only.`
  String get memoryInfoDesc {
    return Intl.message(
      'The current memory information value displayed is the dynamic stack memory usage of the core during runtime, not the complete APP memory statistics, for reference only.',
      name: 'memoryInfoDesc',
      desc: '',
      args: [],
    );
  }

  /// `Cancel`
  String get cancel {
    return Intl.message('Cancel', name: 'cancel', desc: '', args: []);
  }

  /// `File modified. Save changes?`
  String get fileIsUpdate {
    return Intl.message(
      'File modified. Save changes?',
      name: 'fileIsUpdate',
      desc: '',
      args: [],
    );
  }

  /// `Profile modified. Disable auto-update?`
  String get profileHasUpdate {
    return Intl.message(
      'Profile modified. Disable auto-update?',
      name: 'profileHasUpdate',
      desc: '',
      args: [],
    );
  }

  /// `Cache modifications?`
  String get hasCacheChange {
    return Intl.message(
      'Cache modifications?',
      name: 'hasCacheChange',
      desc: '',
      args: [],
    );
  }

  /// `Connections`
  String get navConnections {
    return Intl.message(
      'Connections',
      name: 'navConnections',
      desc: '',
      args: [],
    );
  }

  /// `More`
  String get navTools {
    return Intl.message('More', name: 'navTools', desc: '', args: []);
  }

  /// `Copy Successful`
  String get copySuccess {
    return Intl.message(
      'Copy Successful',
      name: 'copySuccess',
      desc: '',
      args: [],
    );
  }

  /// `Success`
  String get success {
    return Intl.message('Success', name: 'success', desc: '', args: []);
  }

  /// `Copy Link`
  String get copyLink {
    return Intl.message('Copy Link', name: 'copyLink', desc: '', args: []);
  }

  /// `Export File`
  String get exportFile {
    return Intl.message('Export File', name: 'exportFile', desc: '', args: []);
  }

  /// `Cache corrupted. Clear it?`
  String get cacheCorrupt {
    return Intl.message(
      'Cache corrupted. Clear it?',
      name: 'cacheCorrupt',
      desc: '',
      args: [],
    );
  }

  /// `Third-party API result (for reference only)`
  String get detectionTip {
    return Intl.message(
      'Third-party API result (for reference only)',
      name: 'detectionTip',
      desc: '',
      args: [],
    );
  }

  /// `Toggle Display`
  String get ipClickBehavior {
    return Intl.message(
      'Toggle Display',
      name: 'ipClickBehavior',
      desc: '',
      args: [],
    );
  }

  /// `Protect IP Display`
  String get ipPrivacyProtection {
    return Intl.message(
      'Protect IP Display',
      name: 'ipPrivacyProtection',
      desc: '',
      args: [],
    );
  }

  /// `Refresh IP`
  String get manualRefreshIp {
    return Intl.message(
      'Refresh IP',
      name: 'manualRefreshIp',
      desc: '',
      args: [],
    );
  }

  /// `Please try manual refresh`
  String get tryManualRefresh {
    return Intl.message(
      'Please try manual refresh',
      name: 'tryManualRefresh',
      desc: '',
      args: [],
    );
  }

  /// `Refresh App List`
  String get refreshAppList {
    return Intl.message(
      'Refresh App List',
      name: 'refreshAppList',
      desc: '',
      args: [],
    );
  }

  /// `Refresh the app list?`
  String get refreshAppListConfirm {
    return Intl.message(
      'Refresh the app list?',
      name: 'refreshAppListConfirm',
      desc: '',
      args: [],
    );
  }

  /// `IP Risk Alert`
  String get ipRiskAlert {
    return Intl.message(
      'IP Risk Alert',
      name: 'ipRiskAlert',
      desc: '',
      args: [],
    );
  }

  /// `Undo`
  String get undo {
    return Intl.message('Undo', name: 'undo', desc: '', args: []);
  }

  /// `Redo`
  String get redo {
    return Intl.message('Redo', name: 'redo', desc: '', args: []);
  }

  /// `None`
  String get none {
    return Intl.message('None', name: 'none', desc: '', args: []);
  }

  /// `Core Configuration`
  String get basicConfig {
    return Intl.message(
      'Core Configuration',
      name: 'basicConfig',
      desc: '',
      args: [],
    );
  }

  /// `Global core settings`
  String get basicConfigDesc {
    return Intl.message(
      'Global core settings',
      name: 'basicConfigDesc',
      desc: '',
      args: [],
    );
  }

  /// `{count} items selected`
  String selectedCountTitle(Object count) {
    return Intl.message(
      '$count items selected',
      name: 'selectedCountTitle',
      desc: '',
      args: [count],
    );
  }

  /// `Add Rule`
  String get addRule {
    return Intl.message('Add Rule', name: 'addRule', desc: '', args: []);
  }

  /// `Content`
  String get content {
    return Intl.message('Content', name: 'content', desc: '', args: []);
  }

  /// `Sub Rule`
  String get subRule {
    return Intl.message('Sub Rule', name: 'subRule', desc: '', args: []);
  }

  /// `Rule Target`
  String get ruleTarget {
    return Intl.message('Rule Target', name: 'ruleTarget', desc: '', args: []);
  }

  /// `Source IP`
  String get sourceIp {
    return Intl.message('Source IP', name: 'sourceIp', desc: '', args: []);
  }

  /// `No Resolve`
  String get noResolve {
    return Intl.message('No Resolve', name: 'noResolve', desc: '', args: []);
  }

  /// `Append to Original Rules`
  String get addedOriginRules {
    return Intl.message(
      'Append to Original Rules',
      name: 'addedOriginRules',
      desc: '',
      args: [],
    );
  }

  /// `Enable Override`
  String get enableOverride {
    return Intl.message(
      'Enable Override',
      name: 'enableOverride',
      desc: '',
      args: [],
    );
  }

  /// `Save changes?`
  String get saveChanges {
    return Intl.message(
      'Save changes?',
      name: 'saveChanges',
      desc: '',
      args: [],
    );
  }

  /// `Modify global settings`
  String get generalDesc {
    return Intl.message(
      'Modify global settings',
      name: 'generalDesc',
      desc: '',
      args: [],
    );
  }

  /// `Enable process matching`
  String get findProcessModeDesc {
    return Intl.message(
      'Enable process matching',
      name: 'findProcessModeDesc',
      desc: '',
      args: [],
    );
  }

  /// `Motion Feedback`
  String get navBarHapticFeedback {
    return Intl.message(
      'Motion Feedback',
      name: 'navBarHapticFeedback',
      desc: '',
      args: [],
    );
  }

  /// `Enable more animations and haptic feedback`
  String get navBarHapticFeedbackDesc {
    return Intl.message(
      'Enable more animations and haptic feedback',
      name: 'navBarHapticFeedbackDesc',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure you want to save?`
  String get saveTip {
    return Intl.message(
      'Are you sure you want to save?',
      name: 'saveTip',
      desc: '',
      args: [],
    );
  }

  /// `Color Schemes`
  String get colorSchemes {
    return Intl.message(
      'Color Schemes',
      name: 'colorSchemes',
      desc: '',
      args: [],
    );
  }

  /// `Palette`
  String get palette {
    return Intl.message('Palette', name: 'palette', desc: '', args: []);
  }

  /// `Tonal Spot`
  String get tonalSpotScheme {
    return Intl.message(
      'Tonal Spot',
      name: 'tonalSpotScheme',
      desc: '',
      args: [],
    );
  }

  /// `Fidelity`
  String get fidelityScheme {
    return Intl.message('Fidelity', name: 'fidelityScheme', desc: '', args: []);
  }

  /// `Monochrome`
  String get monochromeScheme {
    return Intl.message(
      'Monochrome',
      name: 'monochromeScheme',
      desc: '',
      args: [],
    );
  }

  /// `Neutral`
  String get neutralScheme {
    return Intl.message('Neutral', name: 'neutralScheme', desc: '', args: []);
  }

  /// `Vibrant`
  String get vibrantScheme {
    return Intl.message('Vibrant', name: 'vibrantScheme', desc: '', args: []);
  }

  /// `Expressive`
  String get expressiveScheme {
    return Intl.message(
      'Expressive',
      name: 'expressiveScheme',
      desc: '',
      args: [],
    );
  }

  /// `Content`
  String get contentScheme {
    return Intl.message('Content', name: 'contentScheme', desc: '', args: []);
  }

  /// `Rainbow`
  String get rainbowScheme {
    return Intl.message('Rainbow', name: 'rainbowScheme', desc: '', args: []);
  }

  /// `Fruit Salad`
  String get fruitSaladScheme {
    return Intl.message(
      'Fruit Salad',
      name: 'fruitSaladScheme',
      desc: '',
      args: [],
    );
  }

  /// `Developer Mode`
  String get developerMode {
    return Intl.message(
      'Developer Mode',
      name: 'developerMode',
      desc: '',
      args: [],
    );
  }

  /// `Developer mode is enabled.`
  String get developerModeEnableTip {
    return Intl.message(
      'Developer mode is enabled.',
      name: 'developerModeEnableTip',
      desc: '',
      args: [],
    );
  }

  /// `Message Test`
  String get messageTest {
    return Intl.message(
      'Message Test',
      name: 'messageTest',
      desc: '',
      args: [],
    );
  }

  /// `This is a message.`
  String get messageTestTip {
    return Intl.message(
      'This is a message.',
      name: 'messageTestTip',
      desc: '',
      args: [],
    );
  }

  /// `Crash Test`
  String get crashTest {
    return Intl.message('Crash Test', name: 'crashTest', desc: '', args: []);
  }

  /// `Clear Data`
  String get clearData {
    return Intl.message('Clear Data', name: 'clearData', desc: '', args: []);
  }

  /// `Dangerous Operation`
  String get clearDataTipTitle {
    return Intl.message(
      'Dangerous Operation',
      name: 'clearDataTipTitle',
      desc: '',
      args: [],
    );
  }

  /// `This operation will reset the application. Please make backups. Are you sure you want to continue?`
  String get clearDataTipDesc {
    return Intl.message(
      'This operation will reset the application. Please make backups. Are you sure you want to continue?',
      name: 'clearDataTipDesc',
      desc: '',
      args: [],
    );
  }

  /// `Text Scaling`
  String get textScale {
    return Intl.message('Text Scaling', name: 'textScale', desc: '', args: []);
  }

  /// `Invert Tray Icon`
  String get trayIconInvert {
    return Intl.message(
      'Invert Tray Icon',
      name: 'trayIconInvert',
      desc: '',
      args: [],
    );
  }

  /// `Invert the current tray icon color`
  String get trayIconInvertDesc {
    return Intl.message(
      'Invert the current tray icon color',
      name: 'trayIconInvertDesc',
      desc: '',
      args: [],
    );
  }

  /// `Font Fix`
  String get harmonyFont {
    return Intl.message('Font Fix', name: 'harmonyFont', desc: '', args: []);
  }

  /// `Use built-in font to fix display issues`
  String get harmonyFontDesc {
    return Intl.message(
      'Use built-in font to fix display issues',
      name: 'harmonyFontDesc',
      desc: '',
      args: [],
    );
  }

  /// `Phosphor Icons`
  String get phosphorIcons {
    return Intl.message(
      'Phosphor Icons',
      name: 'phosphorIcons',
      desc: '',
      args: [],
    );
  }

  /// `Use modern, minimalist Phosphor icons`
  String get phosphorIconsDesc {
    return Intl.message(
      'Use modern, minimalist Phosphor icons',
      name: 'phosphorIconsDesc',
      desc: '',
      args: [],
    );
  }

  /// `Internet`
  String get internet {
    return Intl.message('Internet', name: 'internet', desc: '', args: []);
  }

  /// `System App`
  String get systemApp {
    return Intl.message('System App', name: 'systemApp', desc: '', args: []);
  }

  /// `No Network App`
  String get noNetworkApp {
    return Intl.message(
      'No Network App',
      name: 'noNetworkApp',
      desc: '',
      args: [],
    );
  }

  /// `Contact Me`
  String get contactMe {
    return Intl.message('Contact Me', name: 'contactMe', desc: '', args: []);
  }

  /// `Recovery Strategy`
  String get recoveryStrategy {
    return Intl.message(
      'Recovery Strategy',
      name: 'recoveryStrategy',
      desc: '',
      args: [],
    );
  }

  /// `Override`
  String get recoveryStrategy_override {
    return Intl.message(
      'Override',
      name: 'recoveryStrategy_override',
      desc: '',
      args: [],
    );
  }

  /// `Compatible`
  String get recoveryStrategy_compatible {
    return Intl.message(
      'Compatible',
      name: 'recoveryStrategy_compatible',
      desc: '',
      args: [],
    );
  }

  /// `Keep local items, merge backup by ID`
  String get recoveryStrategyDesc_compatible {
    return Intl.message(
      'Keep local items, merge backup by ID',
      name: 'recoveryStrategyDesc_compatible',
      desc: '',
      args: [],
    );
  }

  /// `Clear local items and replace with backup`
  String get recoveryStrategyDesc_override {
    return Intl.message(
      'Clear local items and replace with backup',
      name: 'recoveryStrategyDesc_override',
      desc: '',
      args: [],
    );
  }

  /// `Logs Test`
  String get logsTest {
    return Intl.message('Logs Test', name: 'logsTest', desc: '', args: []);
  }

  /// `{label} cannot be empty`
  String emptyTip(Object label) {
    return Intl.message(
      '$label cannot be empty',
      name: 'emptyTip',
      desc: '',
      args: [label],
    );
  }

  /// `{label} must be a URL`
  String urlTip(Object label) {
    return Intl.message(
      '$label must be a URL',
      name: 'urlTip',
      desc: '',
      args: [label],
    );
  }

  /// `{label} must be a number`
  String numberTip(Object label) {
    return Intl.message(
      '$label must be a number',
      name: 'numberTip',
      desc: '',
      args: [label],
    );
  }

  /// `Interval`
  String get interval {
    return Intl.message('Interval', name: 'interval', desc: '', args: []);
  }

  /// `{label} already exists`
  String existsTip(Object label) {
    return Intl.message(
      '$label already exists',
      name: 'existsTip',
      desc: '',
      args: [label],
    );
  }

  /// `Delete current {label}?`
  String deleteTip(Object label) {
    return Intl.message(
      'Delete current $label?',
      name: 'deleteTip',
      desc: '',
      args: [label],
    );
  }

  /// `Delete selected {label}?`
  String deleteMultipTip(Object label) {
    return Intl.message(
      'Delete selected $label?',
      name: 'deleteMultipTip',
      desc: '',
      args: [label],
    );
  }

  /// `No {label}`
  String nullTip(Object label) {
    return Intl.message('No $label', name: 'nullTip', desc: '', args: [label]);
  }

  /// `No UDP connections`
  String get nullUdpConnections {
    return Intl.message(
      'No UDP connections',
      name: 'nullUdpConnections',
      desc: '',
      args: [],
    );
  }

  /// `Override Script`
  String get script {
    return Intl.message('Override Script', name: 'script', desc: '', args: []);
  }

  /// `Color`
  String get color {
    return Intl.message('Color', name: 'color', desc: '', args: []);
  }

  /// `Rename`
  String get rename {
    return Intl.message('Rename', name: 'rename', desc: '', args: []);
  }

  /// `Unnamed`
  String get unnamed {
    return Intl.message('Unnamed', name: 'unnamed', desc: '', args: []);
  }

  /// `Please enter a script name`
  String get pleaseEnterScriptName {
    return Intl.message(
      'Please enter a script name',
      name: 'pleaseEnterScriptName',
      desc: '',
      args: [],
    );
  }

  /// `Mixed Port`
  String get mixedPort {
    return Intl.message('Mixed Port', name: 'mixedPort', desc: '', args: []);
  }

  /// `Socks Port`
  String get socksPort {
    return Intl.message('Socks Port', name: 'socksPort', desc: '', args: []);
  }

  /// `Redir Port`
  String get redirPort {
    return Intl.message('Redir Port', name: 'redirPort', desc: '', args: []);
  }

  /// `Tproxy Port`
  String get tproxyPort {
    return Intl.message('Tproxy Port', name: 'tproxyPort', desc: '', args: []);
  }

  /// `{label} must be between 1024 and 49151, 0 to disable`
  String portTip(Object label) {
    return Intl.message(
      '$label must be between 1024 and 49151, 0 to disable',
      name: 'portTip',
      desc: '',
      args: [label],
    );
  }

  /// `Please enter a different port`
  String get portConflictTip {
    return Intl.message(
      'Please enter a different port',
      name: 'portConflictTip',
      desc: '',
      args: [],
    );
  }

  /// `Import`
  String get import {
    return Intl.message('Import', name: 'import', desc: '', args: []);
  }

  /// `Import from Code`
  String get importFromCode {
    return Intl.message(
      'Import from Code',
      name: 'importFromCode',
      desc: '',
      args: [],
    );
  }

  /// `Import failed`
  String get importFailed {
    return Intl.message(
      'Import failed',
      name: 'importFailed',
      desc: '',
      args: [],
    );
  }

  /// `Import from File`
  String get importFile {
    return Intl.message(
      'Import from File',
      name: 'importFile',
      desc: '',
      args: [],
    );
  }

  /// `Import from URL`
  String get importUrl {
    return Intl.message(
      'Import from URL',
      name: 'importUrl',
      desc: '',
      args: [],
    );
  }

  /// `Details`
  String get details {
    return Intl.message('Details', name: 'details', desc: '', args: []);
  }

  /// `Creation Time`
  String get creationTime {
    return Intl.message(
      'Creation Time',
      name: 'creationTime',
      desc: '',
      args: [],
    );
  }

  /// `Progress`
  String get progress {
    return Intl.message('Progress', name: 'progress', desc: '', args: []);
  }

  /// `Host`
  String get host {
    return Intl.message('Host', name: 'host', desc: '', args: []);
  }

  /// `Destination`
  String get destination {
    return Intl.message('Destination', name: 'destination', desc: '', args: []);
  }

  /// `Destination GeoIP`
  String get destinationGeoIP {
    return Intl.message(
      'Destination GeoIP',
      name: 'destinationGeoIP',
      desc: '',
      args: [],
    );
  }

  /// `Destination IP ASN`
  String get destinationIPASN {
    return Intl.message(
      'Destination IP ASN',
      name: 'destinationIPASN',
      desc: '',
      args: [],
    );
  }

  /// `Special Proxy`
  String get specialProxy {
    return Intl.message(
      'Special Proxy',
      name: 'specialProxy',
      desc: '',
      args: [],
    );
  }

  /// `Special Rules`
  String get specialRules {
    return Intl.message(
      'Special Rules',
      name: 'specialRules',
      desc: '',
      args: [],
    );
  }

  /// `Remote Destination`
  String get remoteDestination {
    return Intl.message(
      'Remote Destination',
      name: 'remoteDestination',
      desc: '',
      args: [],
    );
  }

  /// `Inbound`
  String get inbound {
    return Intl.message('Inbound', name: 'inbound', desc: '', args: []);
  }

  /// `{inbound} (user {user})`
  String inboundWithUser(Object inbound, Object user) {
    return Intl.message(
      '$inbound (user $user)',
      name: 'inboundWithUser',
      desc: '',
      args: [inbound, user],
    );
  }

  /// `Internal traffic`
  String get internalTraffic {
    return Intl.message(
      'Internal traffic',
      name: 'internalTraffic',
      desc: '',
      args: [],
    );
  }

  /// `Sniffed Host`
  String get sniffHost {
    return Intl.message('Sniffed Host', name: 'sniffHost', desc: '', args: []);
  }

  /// `Process Path`
  String get processPath {
    return Intl.message(
      'Process Path',
      name: 'processPath',
      desc: '',
      args: [],
    );
  }

  /// `Network Type`
  String get networkType {
    return Intl.message(
      'Network Type',
      name: 'networkType',
      desc: '',
      args: [],
    );
  }

  /// `Proxy Chains`
  String get proxyChains {
    return Intl.message(
      'Proxy Chains',
      name: 'proxyChains',
      desc: '',
      args: [],
    );
  }

  /// `Log`
  String get log {
    return Intl.message('Log', name: 'log', desc: '', args: []);
  }

  /// `Active`
  String get connection {
    return Intl.message('Active', name: 'connection', desc: '', args: []);
  }

  /// `Request`
  String get request {
    return Intl.message('Request', name: 'request', desc: '', args: []);
  }

  /// `Switch`
  String get switchLabel {
    return Intl.message('Switch', name: 'switchLabel', desc: '', args: []);
  }

  /// `No Status`
  String get noStatusAvailable {
    return Intl.message(
      'No Status',
      name: 'noStatusAvailable',
      desc: '',
      args: [],
    );
  }

  /// `Online Panel`
  String get onlinePanel {
    return Intl.message(
      'Online Panel',
      name: 'onlinePanel',
      desc: '',
      args: [],
    );
  }

  /// `Open Zashboard`
  String get openDashboard {
    return Intl.message(
      'Open Zashboard',
      name: 'openDashboard',
      desc: '',
      args: [],
    );
  }

  /// `Custom`
  String get custom {
    return Intl.message('Custom', name: 'custom', desc: '', args: []);
  }

  /// `Custom Rule Switch`
  String get customScriptOptions {
    return Intl.message(
      'Custom Rule Switch',
      name: 'customScriptOptions',
      desc: '',
      args: [],
    );
  }

  /// `Other Settings`
  String get scriptOtherOptions {
    return Intl.message(
      'Other Settings',
      name: 'scriptOtherOptions',
      desc: '',
      args: [],
    );
  }

  /// `Wakelock`
  String get wakelock {
    return Intl.message('Wakelock', name: 'wakelock', desc: '', args: []);
  }

  /// `Keeps the screen on and app active in the background without requiring special CPU wakelock permissions.`
  String get wakelockDescription {
    return Intl.message(
      'Keeps the screen on and app active in the background without requiring special CPU wakelock permissions.',
      name: 'wakelockDescription',
      desc: '',
      args: [],
    );
  }

  /// `Enabling the TUN virtual network adapter requires Administrator or ROOT privileges.`
  String get tunEnableRequireAdmin {
    return Intl.message(
      'Enabling the TUN virtual network adapter requires Administrator or ROOT privileges.',
      name: 'tunEnableRequireAdmin',
      desc: '',
      args: [],
    );
  }

  /// `Restart TUN for changes to take effect`
  String get restartTip {
    return Intl.message(
      'Restart TUN for changes to take effect',
      name: 'restartTip',
      desc: '',
      args: [],
    );
  }

  /// `Restart`
  String get restart {
    return Intl.message('Restart', name: 'restart', desc: '', args: []);
  }

  /// `Restart Core`
  String get restartCoreTitle {
    return Intl.message(
      'Restart Core',
      name: 'restartCoreTitle',
      desc: '',
      args: [],
    );
  }

  /// `Manually restart the core?`
  String get restartCoreDesc {
    return Intl.message(
      'Manually restart the core?',
      name: 'restartCoreDesc',
      desc: '',
      args: [],
    );
  }

  /// `Script per Profile`
  String get useGlobalScriptOverride {
    return Intl.message(
      'Script per Profile',
      name: 'useGlobalScriptOverride',
      desc: '',
      args: [],
    );
  }

  /// `Failed to import profile. Please check your network status or try resetting the subscription link ( HTTP error code: {statusCode} )`
  String profileImportFailed(Object statusCode) {
    return Intl.message(
      'Failed to import profile. Please check your network status or try resetting the subscription link ( HTTP error code: $statusCode )',
      name: 'profileImportFailed',
      desc: '',
      args: [statusCode],
    );
  }

  /// `Authorized`
  String get authorized {
    return Intl.message('Authorized', name: 'authorized', desc: '', args: []);
  }

  /// `Unauthorized`
  String get unauthorized {
    return Intl.message(
      'Unauthorized',
      name: 'unauthorized',
      desc: '',
      args: [],
    );
  }

  /// `Age Secret Key (Optional)`
  String get ageSecretKeyOptional {
    return Intl.message(
      'Age Secret Key (Optional)',
      name: 'ageSecretKeyOptional',
      desc: '',
      args: [],
    );
  }

  /// `Please enter a valid Age secret key (must start with AGE-SECRET-KEY-)`
  String get ageSecretKeyInvalidValidationDesc {
    return Intl.message(
      'Please enter a valid Age secret key (must start with AGE-SECRET-KEY-)',
      name: 'ageSecretKeyInvalidValidationDesc',
      desc: '',
      args: [],
    );
  }

  /// `Age Key Tool`
  String get ageKeyGenerateTitle {
    return Intl.message(
      'Age Key Tool',
      name: 'ageKeyGenerateTitle',
      desc: '',
      args: [],
    );
  }

  /// `Skip certificate verification`
  String get skipCertVerify {
    return Intl.message(
      'Skip certificate verification',
      name: 'skipCertVerify',
      desc: '',
      args: [],
    );
  }

  /// `Update via direct connection`
  String get directUpdate {
    return Intl.message(
      'Update via direct connection',
      name: 'directUpdate',
      desc: '',
      args: [],
    );
  }

  /// `Use specified UA`
  String get useCustomUa {
    return Intl.message(
      'Use specified UA',
      name: 'useCustomUa',
      desc: '',
      args: [],
    );
  }

  /// `Age Private Key`
  String get agePrivateKeyLabel {
    return Intl.message(
      'Age Private Key',
      name: 'agePrivateKeyLabel',
      desc: '',
      args: [],
    );
  }

  /// `Age Public Key`
  String get agePublicKeyLabel {
    return Intl.message(
      'Age Public Key',
      name: 'agePublicKeyLabel',
      desc: '',
      args: [],
    );
  }

  /// `Generate from private key`
  String get generateFromPrivateKey {
    return Intl.message(
      'Generate from private key',
      name: 'generateFromPrivateKey',
      desc: '',
      args: [],
    );
  }

  /// `X25519 Key pair generated, please keep it safe`
  String get ageKeyPairGeneratedSuccess {
    return Intl.message(
      'X25519 Key pair generated, please keep it safe',
      name: 'ageKeyPairGeneratedSuccess',
      desc: '',
      args: [],
    );
  }

  /// `Please enter a correct Age private key first`
  String get agePrivateKeyRequired {
    return Intl.message(
      'Please enter a correct Age private key first',
      name: 'agePrivateKeyRequired',
      desc: '',
      args: [],
    );
  }

  /// `Wrap Lines`
  String get lineWrap {
    return Intl.message('Wrap Lines', name: 'lineWrap', desc: '', args: []);
  }

  /// `Pin Expanded`
  String get autoStickyHeader {
    return Intl.message(
      'Pin Expanded',
      name: 'autoStickyHeader',
      desc: '',
      args: [],
    );
  }

  /// `Show Hidden Groups`
  String get showHiddenItems {
    return Intl.message(
      'Show Hidden Groups',
      name: 'showHiddenItems',
      desc: '',
      args: [],
    );
  }

  /// `Hide Unavailable Proxies`
  String get hideTimeoutProxies {
    return Intl.message(
      'Hide Unavailable Proxies',
      name: 'hideTimeoutProxies',
      desc: '',
      args: [],
    );
  }

  /// `Comment`
  String get blockComment {
    return Intl.message('Comment', name: 'blockComment', desc: '', args: []);
  }

  /// `Locate`
  String get locate {
    return Intl.message('Locate', name: 'locate', desc: '', args: []);
  }

  /// `Minimize`
  String get minimize {
    return Intl.message('Minimize', name: 'minimize', desc: '', args: []);
  }

  /// `Maximize`
  String get maximize {
    return Intl.message('Maximize', name: 'maximize', desc: '', args: []);
  }

  /// `Restore`
  String get restore {
    return Intl.message('Restore', name: 'restore', desc: '', args: []);
  }

  /// `Pin`
  String get pin {
    return Intl.message('Pin', name: 'pin', desc: '', args: []);
  }

  /// `Unpin`
  String get unpin {
    return Intl.message('Unpin', name: 'unpin', desc: '', args: []);
  }

  /// `Close`
  String get close {
    return Intl.message('Close', name: 'close', desc: '', args: []);
  }

  /// `Auto Scroll`
  String get autoScroll {
    return Intl.message('Auto Scroll', name: 'autoScroll', desc: '', args: []);
  }

  /// `Export`
  String get export {
    return Intl.message('Export', name: 'export', desc: '', args: []);
  }

  /// `Clear`
  String get clear {
    return Intl.message('Clear', name: 'clear', desc: '', args: []);
  }

  /// `Back`
  String get back {
    return Intl.message('Back', name: 'back', desc: '', args: []);
  }

  /// `Close All`
  String get closeAll {
    return Intl.message('Close All', name: 'closeAll', desc: '', args: []);
  }

  /// `More IP Information`
  String get moreIpInfo {
    return Intl.message(
      'More IP Information',
      name: 'moreIpInfo',
      desc: '',
      args: [],
    );
  }

  /// `View Detailed IP Data`
  String get viewDetailedIpData {
    return Intl.message(
      'View Detailed IP Data',
      name: 'viewDetailedIpData',
      desc: '',
      args: [],
    );
  }

  /// `IP Address`
  String get ipAddress {
    return Intl.message('IP Address', name: 'ipAddress', desc: '', args: []);
  }

  /// `Country / Region`
  String get countryOrRegion {
    return Intl.message(
      'Country / Region',
      name: 'countryOrRegion',
      desc: '',
      args: [],
    );
  }

  /// `Province / City`
  String get provinceAndCity {
    return Intl.message(
      'Province / City',
      name: 'provinceAndCity',
      desc: '',
      args: [],
    );
  }

  /// `Organization / ASN`
  String get operatorOrAsn {
    return Intl.message(
      'Organization / ASN',
      name: 'operatorOrAsn',
      desc: '',
      args: [],
    );
  }

  /// `Continent`
  String get continent {
    return Intl.message('Continent', name: 'continent', desc: '', args: []);
  }

  /// `Organization / Domain`
  String get organizationDomain {
    return Intl.message(
      'Organization / Domain',
      name: 'organizationDomain',
      desc: '',
      args: [],
    );
  }

  /// `Copied to clipboard`
  String get copiedToClipboard {
    return Intl.message(
      'Copied to clipboard',
      name: 'copiedToClipboard',
      desc: '',
      args: [],
    );
  }

  /// `Private / LAN IP Address`
  String get privateIp {
    return Intl.message(
      'Private / LAN IP Address',
      name: 'privateIp',
      desc: '',
      args: [],
    );
  }

  /// `ISP`
  String get isp {
    return Intl.message('ISP', name: 'isp', desc: '', args: []);
  }

  /// `Network error, please try again later`
  String get networkErrorRetryLater {
    return Intl.message(
      'Network error, please try again later',
      name: 'networkErrorRetryLater',
      desc: '',
      args: [],
    );
  }

  /// `TUN Virtual Network Adapter`
  String get tunVirtualAddress {
    return Intl.message(
      'TUN Virtual Network Adapter',
      name: 'tunVirtualAddress',
      desc: '',
      args: [],
    );
  }

  /// `Install Time`
  String get installTime {
    return Intl.message(
      'Install Time',
      name: 'installTime',
      desc: '',
      args: [],
    );
  }

  /// `Update Time`
  String get updateTime {
    return Intl.message('Update Time', name: 'updateTime', desc: '', args: []);
  }

  /// `Core Status`
  String get coreStatus {
    return Intl.message('Core Status', name: 'coreStatus', desc: '', args: []);
  }

  /// `Memory & Runtime`
  String get memoryAndRuntime {
    return Intl.message(
      'Memory & Runtime',
      name: 'memoryAndRuntime',
      desc: '',
      args: [],
    );
  }

  /// `Allocated`
  String get allocatedMemory {
    return Intl.message(
      'Allocated',
      name: 'allocatedMemory',
      desc: '',
      args: [],
    );
  }

  /// `Reclaimable`
  String get reclaimableMemory {
    return Intl.message(
      'Reclaimable',
      name: 'reclaimableMemory',
      desc: '',
      args: [],
    );
  }

  /// `Goroutines`
  String get activeGoroutines {
    return Intl.message(
      'Goroutines',
      name: 'activeGoroutines',
      desc: '',
      args: [],
    );
  }

  /// `Heap Objects`
  String get heapObjects {
    return Intl.message(
      'Heap Objects',
      name: 'heapObjects',
      desc: '',
      args: [],
    );
  }

  /// `Freed {size}`
  String memoryFreed(Object size) {
    return Intl.message(
      'Freed $size',
      name: 'memoryFreed',
      desc: '',
      args: [size],
    );
  }

  /// `Memory already optimal`
  String get memoryAlreadyOptimal {
    return Intl.message(
      'Memory already optimal',
      name: 'memoryAlreadyOptimal',
      desc: '',
      args: [],
    );
  }

  /// `Profile & Rules`
  String get profileAndRules {
    return Intl.message(
      'Profile & Rules',
      name: 'profileAndRules',
      desc: '',
      args: [],
    );
  }

  /// `Rules`
  String get rulesCount {
    return Intl.message('Rules', name: 'rulesCount', desc: '', args: []);
  }

  /// `Proxies`
  String get proxiesCount {
    return Intl.message('Proxies', name: 'proxiesCount', desc: '', args: []);
  }

  /// `Proxy Groups`
  String get proxyGroupsCount {
    return Intl.message(
      'Proxy Groups',
      name: 'proxyGroupsCount',
      desc: '',
      args: [],
    );
  }

  /// `Rule Providers`
  String get ruleProvidersCount {
    return Intl.message(
      'Rule Providers',
      name: 'ruleProvidersCount',
      desc: '',
      args: [],
    );
  }

  /// `Proxy Providers`
  String get proxyProvidersCount {
    return Intl.message(
      'Proxy Providers',
      name: 'proxyProvidersCount',
      desc: '',
      args: [],
    );
  }

  /// `GEO Load`
  String get geodataUse {
    return Intl.message('GEO Load', name: 'geodataUse', desc: '', args: []);
  }

  /// `{count}`
  String itemsCount(Object count) {
    return Intl.message('$count', name: 'itemsCount', desc: '', args: [count]);
  }

  /// `Connectivity Test`
  String get mediaUnlock {
    return Intl.message(
      'Connectivity Test',
      name: 'mediaUnlock',
      desc: '',
      args: [],
    );
  }

  /// `Connectivity Test Details`
  String get mediaUnlockDetails {
    return Intl.message(
      'Connectivity Test Details',
      name: 'mediaUnlockDetails',
      desc: '',
      args: [],
    );
  }

  /// `Display Settings`
  String get mediaUnlockDisplaySettings {
    return Intl.message(
      'Display Settings',
      name: 'mediaUnlockDisplaySettings',
      desc: '',
      args: [],
    );
  }

  /// `Misc Settings`
  String get mediaUnlockMiscSettings {
    return Intl.message(
      'Misc Settings',
      name: 'mediaUnlockMiscSettings',
      desc: '',
      args: [],
    );
  }

  /// `More Streaming Unlock Items`
  String get mediaUnlockMoreStreamingPlatforms {
    return Intl.message(
      'More Streaming Unlock Items',
      name: 'mediaUnlockMoreStreamingPlatforms',
      desc: '',
      args: [],
    );
  }

  /// `Show more IP details`
  String get mediaUnlockExtraDetails {
    return Intl.message(
      'Show more IP details',
      name: 'mediaUnlockExtraDetails',
      desc: '',
      args: [],
    );
  }

  /// `Auto refresh on node change`
  String get mediaUnlockRefreshOnNodeChange {
    return Intl.message(
      'Auto refresh on node change',
      name: 'mediaUnlockRefreshOnNodeChange',
      desc: '',
      args: [],
    );
  }

  /// `Show colored icons by default`
  String get mediaUnlockColorfulIcons {
    return Intl.message(
      'Show colored icons by default',
      name: 'mediaUnlockColorfulIcons',
      desc: '',
      args: [],
    );
  }

  /// `Partially refresh based on current category`
  String get mediaUnlockRefreshByCategory {
    return Intl.message(
      'Partially refresh based on current category',
      name: 'mediaUnlockRefreshByCategory',
      desc: '',
      args: [],
    );
  }

  /// `Pin up to 3 items on widget`
  String get mediaUnlockPinnedSettingsDesc {
    return Intl.message(
      'Pin up to 3 items on widget',
      name: 'mediaUnlockPinnedSettingsDesc',
      desc: '',
      args: [],
    );
  }

  /// `You can select up to 3 items`
  String get mediaUnlockSelectLimit {
    return Intl.message(
      'You can select up to 3 items',
      name: 'mediaUnlockSelectLimit',
      desc: '',
      args: [],
    );
  }

  /// `All`
  String get categoryAll {
    return Intl.message('All', name: 'categoryAll', desc: '', args: []);
  }

  /// `AI`
  String get categoryAi {
    return Intl.message('AI', name: 'categoryAi', desc: '', args: []);
  }

  /// `Streaming`
  String get categoryStreaming {
    return Intl.message(
      'Streaming',
      name: 'categoryStreaming',
      desc: '',
      args: [],
    );
  }

  /// `China Direct`
  String get categoryChina {
    return Intl.message(
      'China Direct',
      name: 'categoryChina',
      desc: '',
      args: [],
    );
  }

  /// `Social Platforms`
  String get categorySocial {
    return Intl.message(
      'Social Platforms',
      name: 'categorySocial',
      desc: '',
      args: [],
    );
  }

  /// `Developer`
  String get categoryDeveloper {
    return Intl.message(
      'Developer',
      name: 'categoryDeveloper',
      desc: '',
      args: [],
    );
  }

  /// `Gaming Center`
  String get categoryGaming {
    return Intl.message(
      'Gaming Center',
      name: 'categoryGaming',
      desc: '',
      args: [],
    );
  }

  /// `Crypto`
  String get categoryCrypto {
    return Intl.message('Crypto', name: 'categoryCrypto', desc: '', args: []);
  }

  /// `Completed`
  String get unlocked {
    return Intl.message('Completed', name: 'unlocked', desc: '', args: []);
  }

  /// `Unlocked`
  String get mediaUnlocked {
    return Intl.message('Unlocked', name: 'mediaUnlocked', desc: '', args: []);
  }

  /// `Originals Only`
  String get limitedUnlock {
    return Intl.message(
      'Originals Only',
      name: 'limitedUnlock',
      desc: '',
      args: [],
    );
  }

  /// `Not Unlocked`
  String get notUnlocked {
    return Intl.message(
      'Not Unlocked',
      name: 'notUnlocked',
      desc: '',
      args: [],
    );
  }

  /// `Timeout`
  String get checkFailed {
    return Intl.message('Timeout', name: 'checkFailed', desc: '', args: []);
  }

  /// `Testing`
  String get testing {
    return Intl.message('Testing', name: 'testing', desc: '', args: []);
  }

  /// `Flagged`
  String get flagged {
    return Intl.message('Flagged', name: 'flagged', desc: '', args: []);
  }

  /// `Scan / LAN Import`
  String get tvScanImport {
    return Intl.message(
      'Scan / LAN Import',
      name: 'tvScanImport',
      desc: '',
      args: [],
    );
  }

  /// `Scan QR or push profile to TV via LAN`
  String get tvScanImportDesc {
    return Intl.message(
      'Scan QR or push profile to TV via LAN',
      name: 'tvScanImportDesc',
      desc: '',
      args: [],
    );
  }

  /// `Ensure phone and TV are on the same Wi-Fi network`
  String get tvScanStep1 {
    return Intl.message(
      'Ensure phone and TV are on the same Wi-Fi network',
      name: 'tvScanStep1',
      desc: '',
      args: [],
    );
  }

  /// `Scan the QR code with a supported camera or browser`
  String get tvScanStep2 {
    return Intl.message(
      'Scan the QR code with a supported camera or browser',
      name: 'tvScanStep2',
      desc: '',
      args: [],
    );
  }

  /// `Paste subscription URL or upload profile on the webpage and push`
  String get tvScanStep3 {
    return Intl.message(
      'Paste subscription URL or upload profile on the webpage and push',
      name: 'tvScanStep3',
      desc: '',
      args: [],
    );
  }

  /// `Or enter directly in phone browser:`
  String get tvScanManualUrl {
    return Intl.message(
      'Or enter directly in phone browser:',
      name: 'tvScanManualUrl',
      desc: '',
      args: [],
    );
  }

  /// `Waiting for profile from phone...`
  String get tvScanWaiting {
    return Intl.message(
      'Waiting for profile from phone...',
      name: 'tvScanWaiting',
      desc: '',
      args: [],
    );
  }

  /// `Profile received, importing...`
  String get tvScanSuccess {
    return Intl.message(
      'Profile received, importing...',
      name: 'tvScanSuccess',
      desc: '',
      args: [],
    );
  }

  /// `No available LAN detected, please check Wi-Fi`
  String get tvScanNoNetwork {
    return Intl.message(
      'No available LAN detected, please check Wi-Fi',
      name: 'tvScanNoNetwork',
      desc: '',
      args: [],
    );
  }

  /// `User Authentication`
  String get userAuth {
    return Intl.message(
      'User Authentication',
      name: 'userAuth',
      desc: '',
      args: [],
    );
  }

  /// `Skip Local Authentication`
  String get skipLocalAuth {
    return Intl.message(
      'Skip Local Authentication',
      name: 'skipLocalAuth',
      desc: '',
      args: [],
    );
  }

  /// `Allow local access without credentials`
  String get skipLocalAuthDesc {
    return Intl.message(
      'Allow local access without credentials',
      name: 'skipLocalAuthDesc',
      desc: '',
      args: [],
    );
  }

  /// `Username`
  String get username {
    return Intl.message('Username', name: 'username', desc: '', args: []);
  }

  /// `Add User`
  String get addUser {
    return Intl.message('Add User', name: 'addUser', desc: '', args: []);
  }

  /// `Edit User`
  String get editUser {
    return Intl.message('Edit User', name: 'editUser', desc: '', args: []);
  }

  /// `No authentication configured, LAN connections do not require credentials`
  String get userAuthEmpty {
    return Intl.message(
      'No authentication configured, LAN connections do not require credentials',
      name: 'userAuthEmpty',
      desc: '',
      args: [],
    );
  }

  /// `Username cannot contain colons`
  String get usernameCannotContainColon {
    return Intl.message(
      'Username cannot contain colons',
      name: 'usernameCannotContainColon',
      desc: '',
      args: [],
    );
  }

  /// `LAN & Gateway`
  String get intranetAndGateway {
    return Intl.message(
      'LAN & Gateway',
      name: 'intranetAndGateway',
      desc: '',
      args: [],
    );
  }

  /// `Gateway`
  String get defaultGateway {
    return Intl.message('Gateway', name: 'defaultGateway', desc: '', args: []);
  }

  /// `LAN Sharing`
  String get lanSharing {
    return Intl.message('LAN Sharing', name: 'lanSharing', desc: '', args: []);
  }

  /// `Shared Address`
  String get sharedAddress {
    return Intl.message(
      'Shared Address',
      name: 'sharedAddress',
      desc: '',
      args: [],
    );
  }

  /// `DNS Resolution`
  String get dnsResolution {
    return Intl.message(
      'DNS Resolution',
      name: 'dnsResolution',
      desc: '',
      args: [],
    );
  }

  /// `DNS`
  String get systemDns {
    return Intl.message('DNS', name: 'systemDns', desc: '', args: []);
  }

  /// `Enabled`
  String get enabled {
    return Intl.message('Enabled', name: 'enabled', desc: '', args: []);
  }

  /// `Disabled`
  String get disabled {
    return Intl.message('Disabled', name: 'disabled', desc: '', args: []);
  }

  /// `Open Gateway`
  String get openRouterAdmin {
    return Intl.message(
      'Open Gateway',
      name: 'openRouterAdmin',
      desc: '',
      args: [],
    );
  }

  /// `{count} new logs`
  String newLogsCount(Object count) {
    return Intl.message(
      '$count new logs',
      name: 'newLogsCount',
      desc: '',
      args: [count],
    );
  }

  /// `No matching logs`
  String get noMatchedLogs {
    return Intl.message(
      'No matching logs',
      name: 'noMatchedLogs',
      desc: '',
      args: [],
    );
  }

  /// `Clear filters`
  String get clearFilter {
    return Intl.message(
      'Clear filters',
      name: 'clearFilter',
      desc: '',
      args: [],
    );
  }

  /// `Only {label}`
  String onlyShow(Object label) {
    return Intl.message(
      'Only $label',
      name: 'onlyShow',
      desc: '',
      args: [label],
    );
  }

  /// `{level} mode is for network debugging; turn it off for daily use`
  String logLevelDebugHint(Object level) {
    return Intl.message(
      '$level mode is for network debugging; turn it off for daily use',
      name: 'logLevelDebugHint',
      desc: '',
      args: [level],
    );
  }

  /// `Collapse`
  String get collapse {
    return Intl.message('Collapse', name: 'collapse', desc: '', args: []);
  }

  /// `Analyze FastLin (Mihomo) log: {log}`
  String analyzeLogPrompt(Object log) {
    return Intl.message(
      'Analyze FastLin (Mihomo) log: $log',
      name: 'analyzeLogPrompt',
      desc: '',
      args: [log],
    );
  }

  /// `GEO Built-in Resources`
  String get geoBuiltInResources {
    return Intl.message(
      'GEO Built-in Resources',
      name: 'geoBuiltInResources',
      desc: '',
      args: [],
    );
  }

  /// `setcap is not installed, falling back to setuid`
  String get setcapNotInstalledFallback {
    return Intl.message(
      'setcap is not installed, falling back to setuid',
      name: 'setcapNotInstalledFallback',
      desc: '',
      args: [],
    );
  }

  /// `The filesystem does not support file capabilities, falling back to setuid`
  String get xattrUnsupportedFallback {
    return Intl.message(
      'The filesystem does not support file capabilities, falling back to setuid',
      name: 'xattrUnsupportedFallback',
      desc: '',
      args: [],
    );
  }

  /// `Could not grant file capabilities, falling back to setuid`
  String get setcapFailedFallback {
    return Intl.message(
      'Could not grant file capabilities, falling back to setuid',
      name: 'setcapFailedFallback',
      desc: '',
      args: [],
    );
  }

  /// `The core is on a filesystem mounted with nosuid, so file capabilities and setuid cannot take effect`
  String get coreMountNosuid {
    return Intl.message(
      'The core is on a filesystem mounted with nosuid, so file capabilities and setuid cannot take effect',
      name: 'coreMountNosuid',
      desc: '',
      args: [],
    );
  }

  /// `Core authorization did not take effect: the running core lacks CAP_NET_ADMIN, TUN may fail`
  String get coreCapabilityNotEffective {
    return Intl.message(
      'Core authorization did not take effect: the running core lacks CAP_NET_ADMIN, TUN may fail',
      name: 'coreCapabilityNotEffective',
      desc: '',
      args: [],
    );
  }

  /// `Speed Test`
  String get speedTest {
    return Intl.message('Speed Test', name: 'speedTest', desc: '', args: []);
  }

  /// `Start Test`
  String get speedTestStart {
    return Intl.message(
      'Start Test',
      name: 'speedTestStart',
      desc: '',
      args: [],
    );
  }

  /// `Test Again`
  String get speedTestAgain {
    return Intl.message(
      'Test Again',
      name: 'speedTestAgain',
      desc: '',
      args: [],
    );
  }

  /// `Test History`
  String get speedTestHistory {
    return Intl.message(
      'Test History',
      name: 'speedTestHistory',
      desc: '',
      args: [],
    );
  }

  /// `No test history yet`
  String get speedTestHistoryEmpty {
    return Intl.message(
      'No test history yet',
      name: 'speedTestHistoryEmpty',
      desc: '',
      args: [],
    );
  }

  /// `Kept for 14 days`
  String get speedTestHistoryRetention {
    return Intl.message(
      'Kept for 14 days',
      name: 'speedTestHistoryRetention',
      desc: '',
      args: [],
    );
  }

  /// `Clear all speed test history?`
  String get speedTestClearHistoryTip {
    return Intl.message(
      'Clear all speed test history?',
      name: 'speedTestClearHistoryTip',
      desc: '',
      args: [],
    );
  }

  /// `Follow Rules`
  String get speedTestFollowRules {
    return Intl.message(
      'Follow Rules',
      name: 'speedTestFollowRules',
      desc: '',
      args: [],
    );
  }

  /// `Outbound`
  String get speedTestOutbound {
    return Intl.message(
      'Outbound',
      name: 'speedTestOutbound',
      desc: '',
      args: [],
    );
  }

  /// `Not started · Direct test`
  String get speedTestCoreStopped {
    return Intl.message(
      'Not started · Direct test',
      name: 'speedTestCoreStopped',
      desc: '',
      args: [],
    );
  }

  /// `Ready`
  String get speedTestReady {
    return Intl.message('Ready', name: 'speedTestReady', desc: '', args: []);
  }

  /// `Connecting`
  String get speedTestConnecting {
    return Intl.message(
      'Connecting',
      name: 'speedTestConnecting',
      desc: '',
      args: [],
    );
  }

  /// `Packet Loss`
  String get speedTestPacketLoss {
    return Intl.message(
      'Packet Loss',
      name: 'speedTestPacketLoss',
      desc: '',
      args: [],
    );
  }

  /// `Jitter`
  String get speedTestJitter {
    return Intl.message('Jitter', name: 'speedTestJitter', desc: '', args: []);
  }

  /// `Loaded Latency`
  String get speedTestLoadedLatency {
    return Intl.message(
      'Loaded Latency',
      name: 'speedTestLoadedLatency',
      desc: '',
      args: [],
    );
  }

  /// `Responsiveness`
  String get speedTestResponsiveness {
    return Intl.message(
      'Responsiveness',
      name: 'speedTestResponsiveness',
      desc: '',
      args: [],
    );
  }

  /// `Data Used`
  String get speedTestDataUsed {
    return Intl.message(
      'Data Used',
      name: 'speedTestDataUsed',
      desc: '',
      args: [],
    );
  }

  /// `Test Server`
  String get speedTestServer {
    return Intl.message(
      'Test Server',
      name: 'speedTestServer',
      desc: '',
      args: [],
    );
  }

  /// `Automatically select Speedtest server`
  String get speedTestServerAutoDesc {
    return Intl.message(
      'Automatically select Speedtest server',
      name: 'speedTestServerAutoDesc',
      desc: '',
      args: [],
    );
  }

  /// `Protocol`
  String get speedTestProtocol {
    return Intl.message(
      'Protocol',
      name: 'speedTestProtocol',
      desc: '',
      args: [],
    );
  }

  /// `You are on mobile data. One test may use hundreds of MB. Continue?`
  String get speedTestMobileDataTip {
    return Intl.message(
      'You are on mobile data. One test may use hundreds of MB. Continue?',
      name: 'speedTestMobileDataTip',
      desc: '',
      args: [],
    );
  }

  /// `Blocked by rules`
  String get speedTestErrorRejected {
    return Intl.message(
      'Blocked by rules',
      name: 'speedTestErrorRejected',
      desc: '',
      args: [],
    );
  }

  /// `The current rules route the test domain to REJECT. Choose another outbound and retry.`
  String get speedTestErrorRejectedDesc {
    return Intl.message(
      'The current rules route the test domain to REJECT. Choose another outbound and retry.',
      name: 'speedTestErrorRejectedDesc',
      desc: '',
      args: [],
    );
  }

  /// `Speed test unavailable`
  String get speedTestErrorBlocked {
    return Intl.message(
      'Speed test unavailable',
      name: 'speedTestErrorBlocked',
      desc: '',
      args: [],
    );
  }

  /// `The outbound may be blocking {provider} speed tests. Switch the test source or the outbound.`
  String speedTestErrorBlockedDesc(Object provider) {
    return Intl.message(
      'The outbound may be blocking $provider speed tests. Switch the test source or the outbound.',
      name: 'speedTestErrorBlockedDesc',
      desc: '',
      args: [provider],
    );
  }

  /// `Cannot reach the speed test service`
  String get speedTestErrorUnavailable {
    return Intl.message(
      'Cannot reach the speed test service',
      name: 'speedTestErrorUnavailable',
      desc: '',
      args: [],
    );
  }

  /// `Speed test timed out`
  String get speedTestErrorTimeout {
    return Intl.message(
      'Speed test timed out',
      name: 'speedTestErrorTimeout',
      desc: '',
      args: [],
    );
  }

  /// `Check whether the outbound is available, then retry.`
  String get speedTestErrorNetworkDesc {
    return Intl.message(
      'Check whether the outbound is available, then retry.',
      name: 'speedTestErrorNetworkDesc',
      desc: '',
      args: [],
    );
  }

  /// `Switch to {provider}`
  String speedTestSwitchProvider(Object provider) {
    return Intl.message(
      'Switch to $provider',
      name: 'speedTestSwitchProvider',
      desc: '',
      args: [provider],
    );
  }

  /// `Change Outbound`
  String get speedTestChangeOutbound {
    return Intl.message(
      'Change Outbound',
      name: 'speedTestChangeOutbound',
      desc: '',
      args: [],
    );
  }

  /// `Speed Test Settings`
  String get speedTestSettings {
    return Intl.message(
      'Speed Test Settings',
      name: 'speedTestSettings',
      desc: '',
      args: [],
    );
  }

  /// `Test Duration`
  String get speedTestDuration {
    return Intl.message(
      'Test Duration',
      name: 'speedTestDuration',
      desc: '',
      args: [],
    );
  }

  /// `Connections`
  String get speedTestConnections {
    return Intl.message(
      'Connections',
      name: 'speedTestConnections',
      desc: '',
      args: [],
    );
  }

  /// `Single`
  String get speedTestSingleThread {
    return Intl.message(
      'Single',
      name: 'speedTestSingleThread',
      desc: '',
      args: [],
    );
  }

  /// `Multi`
  String get speedTestMultiThread {
    return Intl.message(
      'Multi',
      name: 'speedTestMultiThread',
      desc: '',
      args: [],
    );
  }

  /// `Multi uses {count} parallel connections to saturate bandwidth`
  String speedTestConnectionsDesc(Object count) {
    return Intl.message(
      'Multi uses $count parallel connections to saturate bandwidth',
      name: 'speedTestConnectionsDesc',
      desc: '',
      args: [count],
    );
  }

  /// `HTTP/3 runs over QUIC (UDP); if unavailable it falls back to HTTP/2, and to HTTP/1.1 if HTTP/2 is unavailable too`
  String get speedTestProtocolDesc {
    return Intl.message(
      'HTTP/3 runs over QUIC (UDP); if unavailable it falls back to HTTP/2, and to HTTP/1.1 if HTTP/2 is unavailable too',
      name: 'speedTestProtocolDesc',
      desc: '',
      args: [],
    );
  }

  /// `{protocol} unavailable, fell back to {fallback}`
  String speedTestProtocolFallback(Object protocol, Object fallback) {
    return Intl.message(
      '$protocol unavailable, fell back to $fallback',
      name: 'speedTestProtocolFallback',
      desc: '',
      args: [protocol, fallback],
    );
  }

  /// `Detecting outbound…`
  String get speedTestProbing {
    return Intl.message(
      'Detecting outbound…',
      name: 'speedTestProbing',
      desc: '',
      args: [],
    );
  }

  /// `Realtime Throughput`
  String get speedTestRealtime {
    return Intl.message(
      'Realtime Throughput',
      name: 'speedTestRealtime',
      desc: '',
      args: [],
    );
  }

  /// `Network Quality`
  String get speedTestQuality {
    return Intl.message(
      'Network Quality',
      name: 'speedTestQuality',
      desc: '',
      args: [],
    );
  }

  /// `{count} connections`
  String speedTestStreams(Object count) {
    return Intl.message(
      '$count connections',
      name: 'speedTestStreams',
      desc: '',
      args: [count],
    );
  }

  /// `Manual`
  String get speedTestManual {
    return Intl.message('Manual', name: 'speedTestManual', desc: '', args: []);
  }

  /// `Exit Node`
  String get speedTestExitNode {
    return Intl.message(
      'Exit Node',
      name: 'speedTestExitNode',
      desc: '',
      args: [],
    );
  }

  /// `Route Rule`
  String get speedTestRoute {
    return Intl.message(
      'Route Rule',
      name: 'speedTestRoute',
      desc: '',
      args: [],
    );
  }

  /// `Resolve with System DNS`
  String get speedTestUseSystemDns {
    return Intl.message(
      'Resolve with System DNS',
      name: 'speedTestUseSystemDns',
      desc: '',
      args: [],
    );
  }

  /// `When enabled, the selected speed test server is always resolved with system DNS, which can help in some cases`
  String get speedTestUseSystemDnsDesc {
    return Intl.message(
      'When enabled, the selected speed test server is always resolved with system DNS, which can help in some cases',
      name: 'speedTestUseSystemDnsDesc',
      desc: '',
      args: [],
    );
  }

  /// `Speed test servers are provided by public third parties. Special thanks to Apple, Cloudflare and Speedtest by Ookla.`
  String get speedTestCredit {
    return Intl.message(
      'Speed test servers are provided by public third parties. Special thanks to Apple, Cloudflare and Speedtest by Ookla.',
      name: 'speedTestCredit',
      desc: '',
      args: [],
    );
  }

  /// `Toolbox`
  String get toolbox {
    return Intl.message('Toolbox', name: 'toolbox', desc: '', args: []);
  }

  /// `Network diagnostics, debugging and utilities`
  String get toolboxDesc {
    return Intl.message(
      'Network diagnostics, debugging and utilities',
      name: 'toolboxDesc',
      desc: '',
      args: [],
    );
  }

  /// `NAT Detection`
  String get natTest {
    return Intl.message('NAT Detection', name: 'natTest', desc: '', args: []);
  }

  /// `Check NAT type, external address and UDP connectivity`
  String get natTestDesc {
    return Intl.message(
      'Check NAT type, external address and UDP connectivity',
      name: 'natTestDesc',
      desc: '',
      args: [],
    );
  }

  /// `Start Detection`
  String get natStart {
    return Intl.message(
      'Start Detection',
      name: 'natStart',
      desc: '',
      args: [],
    );
  }

  /// `Detect Again`
  String get natRetest {
    return Intl.message('Detect Again', name: 'natRetest', desc: '', args: []);
  }

  /// `Result`
  String get natResult {
    return Intl.message('Result', name: 'natResult', desc: '', args: []);
  }

  /// `STUN Server`
  String get natServer {
    return Intl.message('STUN Server', name: 'natServer', desc: '', args: []);
  }

  /// `Custom Server`
  String get natServerCustom {
    return Intl.message(
      'Custom Server',
      name: 'natServerCustom',
      desc: '',
      args: [],
    );
  }

  /// `host:port, e.g. stun.example.com:3478`
  String get natServerHint {
    return Intl.message(
      'host:port, e.g. stun.example.com:3478',
      name: 'natServerHint',
      desc: '',
      args: [],
    );
  }

  /// `Enter a valid host:port`
  String get natServerInvalid {
    return Intl.message(
      'Enter a valid host:port',
      name: 'natServerInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Tap the button below to start`
  String get natReady {
    return Intl.message(
      'Tap the button below to start',
      name: 'natReady',
      desc: '',
      args: [],
    );
  }

  /// `Binding`
  String get natPhaseBinding {
    return Intl.message('Binding', name: 'natPhaseBinding', desc: '', args: []);
  }

  /// `Filtering`
  String get natPhaseFiltering {
    return Intl.message(
      'Filtering',
      name: 'natPhaseFiltering',
      desc: '',
      args: [],
    );
  }

  /// `Mapping`
  String get natPhaseMapping {
    return Intl.message('Mapping', name: 'natPhaseMapping', desc: '', args: []);
  }

  /// `Open Internet`
  String get natTypeOpen {
    return Intl.message(
      'Open Internet',
      name: 'natTypeOpen',
      desc: '',
      args: [],
    );
  }

  /// `Full Cone NAT`
  String get natTypeFullCone {
    return Intl.message(
      'Full Cone NAT',
      name: 'natTypeFullCone',
      desc: '',
      args: [],
    );
  }

  /// `Restricted Cone NAT`
  String get natTypeRestricted {
    return Intl.message(
      'Restricted Cone NAT',
      name: 'natTypeRestricted',
      desc: '',
      args: [],
    );
  }

  /// `Port Restricted Cone NAT`
  String get natTypePortRestricted {
    return Intl.message(
      'Port Restricted Cone NAT',
      name: 'natTypePortRestricted',
      desc: '',
      args: [],
    );
  }

  /// `Symmetric NAT`
  String get natTypeSymmetric {
    return Intl.message(
      'Symmetric NAT',
      name: 'natTypeSymmetric',
      desc: '',
      args: [],
    );
  }

  /// `Cone NAT`
  String get natTypeCone {
    return Intl.message('Cone NAT', name: 'natTypeCone', desc: '', args: []);
  }

  /// `UDP Blocked`
  String get natTypeBlocked {
    return Intl.message(
      'UDP Blocked',
      name: 'natTypeBlocked',
      desc: '',
      args: [],
    );
  }

  /// `Unknown`
  String get natTypeUnknown {
    return Intl.message('Unknown', name: 'natTypeUnknown', desc: '', args: []);
  }

  /// `No NAT in between. Peers can reach you directly, which is ideal for P2P and gaming.`
  String get natDescOpen {
    return Intl.message(
      'No NAT in between. Peers can reach you directly, which is ideal for P2P and gaming.',
      name: 'natDescOpen',
      desc: '',
      args: [],
    );
  }

  /// `NAT1: any external host can reach you. Best for P2P, gaming and voice calls.`
  String get natDescFullCone {
    return Intl.message(
      'NAT1: any external host can reach you. Best for P2P, gaming and voice calls.',
      name: 'natDescFullCone',
      desc: '',
      args: [],
    );
  }

  /// `NAT2: only addresses you contacted can reply. Most P2P and games work well.`
  String get natDescRestricted {
    return Intl.message(
      'NAT2: only addresses you contacted can reply. Most P2P and games work well.',
      name: 'natDescRestricted',
      desc: '',
      args: [],
    );
  }

  /// `NAT3: only the exact address and port you contacted can reply. Some P2P or gaming may need a relay.`
  String get natDescPortRestricted {
    return Intl.message(
      'NAT3: only the exact address and port you contacted can reply. Some P2P or gaming may need a relay.',
      name: 'natDescPortRestricted',
      desc: '',
      args: [],
    );
  }

  /// `NAT4: every destination gets a different mapped port. P2P is hard and usually needs a relay.`
  String get natDescSymmetric {
    return Intl.message(
      'NAT4: every destination gets a different mapped port. P2P is hard and usually needs a relay.',
      name: 'natDescSymmetric',
      desc: '',
      args: [],
    );
  }

  /// `Most P2P and online games work fine. This server can't tell exactly which of NAT1–3 you have; try another server for a precise result.`
  String get natDescCone {
    return Intl.message(
      'Most P2P and online games work fine. This server can\'t tell exactly which of NAT1–3 you have; try another server for a precise result.',
      name: 'natDescCone',
      desc: '',
      args: [],
    );
  }

  /// `No STUN reply. UDP may be blocked by a firewall, your ISP or the outbound node.`
  String get natDescBlocked {
    return Intl.message(
      'No STUN reply. UDP may be blocked by a firewall, your ISP or the outbound node.',
      name: 'natDescBlocked',
      desc: '',
      args: [],
    );
  }

  /// `Unable to determine the NAT type.`
  String get natDescUnknown {
    return Intl.message(
      'Unable to determine the NAT type.',
      name: 'natDescUnknown',
      desc: '',
      args: [],
    );
  }

  /// `External IP`
  String get natExternalIp {
    return Intl.message(
      'External IP',
      name: 'natExternalIp',
      desc: '',
      args: [],
    );
  }

  /// `External Port`
  String get natExternalPort {
    return Intl.message(
      'External Port',
      name: 'natExternalPort',
      desc: '',
      args: [],
    );
  }

  /// `Local IP`
  String get natLocalIp {
    return Intl.message('Local IP', name: 'natLocalIp', desc: '', args: []);
  }

  /// `Mapping`
  String get natMapping {
    return Intl.message('Mapping', name: 'natMapping', desc: '', args: []);
  }

  /// `Filtering`
  String get natFiltering {
    return Intl.message('Filtering', name: 'natFiltering', desc: '', args: []);
  }

  /// `Port Preservation`
  String get natPortPreserve {
    return Intl.message(
      'Port Preservation',
      name: 'natPortPreserve',
      desc: '',
      args: [],
    );
  }

  /// `Endpoint-independent`
  String get natMappingIndependent {
    return Intl.message(
      'Endpoint-independent',
      name: 'natMappingIndependent',
      desc: '',
      args: [],
    );
  }

  /// `Address-dependent`
  String get natMappingAddress {
    return Intl.message(
      'Address-dependent',
      name: 'natMappingAddress',
      desc: '',
      args: [],
    );
  }

  /// `Address and port-dependent`
  String get natMappingAddressPort {
    return Intl.message(
      'Address and port-dependent',
      name: 'natMappingAddressPort',
      desc: '',
      args: [],
    );
  }

  /// `Destination-dependent`
  String get natMappingDependent {
    return Intl.message(
      'Destination-dependent',
      name: 'natMappingDependent',
      desc: '',
      args: [],
    );
  }

  /// `Preserved`
  String get natPreserved {
    return Intl.message('Preserved', name: 'natPreserved', desc: '', args: []);
  }

  /// `Randomized`
  String get natRandomized {
    return Intl.message(
      'Randomized',
      name: 'natRandomized',
      desc: '',
      args: [],
    );
  }

  /// `Through a proxy, the result reflects the outbound node side NAT, not your local network.`
  String get natProxyTip {
    return Intl.message(
      'Through a proxy, the result reflects the outbound node side NAT, not your local network.',
      name: 'natProxyTip',
      desc: '',
      args: [],
    );
  }

  /// `The selected outbound does not support UDP`
  String get natErrorUnsupported {
    return Intl.message(
      'The selected outbound does not support UDP',
      name: 'natErrorUnsupported',
      desc: '',
      args: [],
    );
  }

  /// `Unable to reach the STUN server`
  String get natErrorUnavailable {
    return Intl.message(
      'Unable to reach the STUN server',
      name: 'natErrorUnavailable',
      desc: '',
      args: [],
    );
  }

  /// `Copy Result`
  String get natCopyResult {
    return Intl.message(
      'Copy Result',
      name: 'natCopyResult',
      desc: '',
      args: [],
    );
  }

  /// `NAT Type`
  String get natType {
    return Intl.message('NAT Type', name: 'natType', desc: '', args: []);
  }

  /// `Measure download, upload and latency`
  String get toolSpeedTestDesc {
    return Intl.message(
      'Measure download, upload and latency',
      name: 'toolSpeedTestDesc',
      desc: '',
      args: [],
    );
  }

  /// `Check common services, with per-node batch testing`
  String get toolConnectivityDesc {
    return Intl.message(
      'Check common services, with per-node batch testing',
      name: 'toolConnectivityDesc',
      desc: '',
      args: [],
    );
  }

  /// `Route Trace`
  String get routeTrace {
    return Intl.message('Route Trace', name: 'routeTrace', desc: '', args: []);
  }

  /// `See how the core resolves and matches a domain or IP`
  String get routeTraceDesc {
    return Intl.message(
      'See how the core resolves and matches a domain or IP',
      name: 'routeTraceDesc',
      desc: '',
      args: [],
    );
  }

  /// `Domain, IP or URL`
  String get routeTraceHint {
    return Intl.message(
      'Domain, IP or URL',
      name: 'routeTraceHint',
      desc: '',
      args: [],
    );
  }

  /// `Proxy is not running, route trace is unavailable`
  String get routeTraceStopped {
    return Intl.message(
      'Proxy is not running, route trace is unavailable',
      name: 'routeTraceStopped',
      desc: '',
      args: [],
    );
  }

  /// `Target`
  String get routeTraceInput {
    return Intl.message('Target', name: 'routeTraceInput', desc: '', args: []);
  }

  /// `DNS Resolution`
  String get routeTraceDns {
    return Intl.message(
      'DNS Resolution',
      name: 'routeTraceDns',
      desc: '',
      args: [],
    );
  }

  /// `Hosts hit: {ips}`
  String routeTraceHostsHit(Object ips) {
    return Intl.message(
      'Hosts hit: $ips',
      name: 'routeTraceHostsHit',
      desc: '',
      args: [ips],
    );
  }

  /// `Resolved by rule #{index} · {time} ms`
  String routeTraceDnsBy(Object index, Object time) {
    return Intl.message(
      'Resolved by rule #$index · $time ms',
      name: 'routeTraceDnsBy',
      desc: '',
      args: [index, time],
    );
  }

  /// `No IP resolution was needed while matching`
  String get routeTraceDnsSkipped {
    return Intl.message(
      'No IP resolution was needed while matching',
      name: 'routeTraceDnsSkipped',
      desc: '',
      args: [],
    );
  }

  /// `The target is an IP, no resolution needed`
  String get routeTraceDnsIp {
    return Intl.message(
      'The target is an IP, no resolution needed',
      name: 'routeTraceDnsIp',
      desc: '',
      args: [],
    );
  }

  /// `Rule Matching`
  String get routeTraceRules {
    return Intl.message(
      'Rule Matching',
      name: 'routeTraceRules',
      desc: '',
      args: [],
    );
  }

  /// `{total} rules, matched #{index}`
  String routeTraceRulesSummary(Object total, Object index) {
    return Intl.message(
      '$total rules, matched #$index',
      name: 'routeTraceRulesSummary',
      desc: '',
      args: [total, index],
    );
  }

  /// `{total} rules`
  String routeTraceRulesTotal(Object total) {
    return Intl.message(
      '$total rules',
      name: 'routeTraceRulesTotal',
      desc: '',
      args: [total],
    );
  }

  /// `No rule matched, using DIRECT`
  String get routeTraceNoMatch {
    return Intl.message(
      'No rule matched, using DIRECT',
      name: 'routeTraceNoMatch',
      desc: '',
      args: [],
    );
  }

  /// `Global mode: all traffic uses GLOBAL`
  String get routeTraceModeGlobal {
    return Intl.message(
      'Global mode: all traffic uses GLOBAL',
      name: 'routeTraceModeGlobal',
      desc: '',
      args: [],
    );
  }

  /// `Direct mode: all traffic goes direct`
  String get routeTraceModeDirect {
    return Intl.message(
      'Direct mode: all traffic goes direct',
      name: 'routeTraceModeDirect',
      desc: '',
      args: [],
    );
  }

  /// `Proxy Chain`
  String get routeTraceChain {
    return Intl.message(
      'Proxy Chain',
      name: 'routeTraceChain',
      desc: '',
      args: [],
    );
  }

  /// `Final Outbound`
  String get routeTraceFinal {
    return Intl.message(
      'Final Outbound',
      name: 'routeTraceFinal',
      desc: '',
      args: [],
    );
  }

  /// `View checked rules`
  String get routeTraceViewRules {
    return Intl.message(
      'View checked rules',
      name: 'routeTraceViewRules',
      desc: '',
      args: [],
    );
  }

  /// `Checked Rules`
  String get routeTraceCheckedRules {
    return Intl.message(
      'Checked Rules',
      name: 'routeTraceCheckedRules',
      desc: '',
      args: [],
    );
  }

  /// `Skipped by PASS`
  String get routeTraceSkipPass {
    return Intl.message(
      'Skipped by PASS',
      name: 'routeTraceSkipPass',
      desc: '',
      args: [],
    );
  }

  /// `Skipped, no UDP support`
  String get routeTraceSkipUdp {
    return Intl.message(
      'Skipped, no UDP support',
      name: 'routeTraceSkipUdp',
      desc: '',
      args: [],
    );
  }

  /// `Skipped, target not found`
  String get routeTraceSkipMissing {
    return Intl.message(
      'Skipped, target not found',
      name: 'routeTraceSkipMissing',
      desc: '',
      args: [],
    );
  }

  /// `Triggered DNS`
  String get routeTraceTrigger {
    return Intl.message(
      'Triggered DNS',
      name: 'routeTraceTrigger',
      desc: '',
      args: [],
    );
  }

  /// `This outbound does not support UDP`
  String get routeTraceUdpUnsupported {
    return Intl.message(
      'This outbound does not support UDP',
      name: 'routeTraceUdpUnsupported',
      desc: '',
      args: [],
    );
  }

  /// `Only the first 3000 rules are shown`
  String get routeTraceTruncated {
    return Intl.message(
      'Only the first 3000 rules are shown',
      name: 'routeTraceTruncated',
      desc: '',
      args: [],
    );
  }

  /// `IP Lookup`
  String get ipLookup {
    return Intl.message('IP Lookup', name: 'ipLookup', desc: '', args: []);
  }

  /// `Your exit IPs, or look up any IP or domain`
  String get ipLookupDesc {
    return Intl.message(
      'Your exit IPs, or look up any IP or domain',
      name: 'ipLookupDesc',
      desc: '',
      args: [],
    );
  }

  /// `IP or domain`
  String get ipLookupHint {
    return Intl.message(
      'IP or domain',
      name: 'ipLookupHint',
      desc: '',
      args: [],
    );
  }

  /// `Enter a valid IP or domain`
  String get ipLookupInvalid {
    return Intl.message(
      'Enter a valid IP or domain',
      name: 'ipLookupInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Unable to resolve this domain`
  String get ipLookupResolveFailed {
    return Intl.message(
      'Unable to resolve this domain',
      name: 'ipLookupResolveFailed',
      desc: '',
      args: [],
    );
  }

  /// `My IP`
  String get ipLookupMine {
    return Intl.message('My IP', name: 'ipLookupMine', desc: '', args: []);
  }

  /// `Default Node IP`
  String get ipLookupProxyExit {
    return Intl.message(
      'Default Node IP',
      name: 'ipLookupProxyExit',
      desc: '',
      args: [],
    );
  }

  /// `Domestic Local IP`
  String get ipLookupDomesticExit {
    return Intl.message(
      'Domestic Local IP',
      name: 'ipLookupDomesticExit',
      desc: '',
      args: [],
    );
  }

  /// `Local Network`
  String get ipLookupLocal {
    return Intl.message(
      'Local Network',
      name: 'ipLookupLocal',
      desc: '',
      args: [],
    );
  }

  /// `Results`
  String get ipLookupResult {
    return Intl.message('Results', name: 'ipLookupResult', desc: '', args: []);
  }

  /// `MRS Lookup`
  String get mrsLookup {
    return Intl.message('MRS Lookup', name: 'mrsLookup', desc: '', args: []);
  }

  /// `Find the GEO / RULE-SET rule sets for a domain or IP`
  String get mrsLookupDesc {
    return Intl.message(
      'Find the GEO / RULE-SET rule sets for a domain or IP',
      name: 'mrsLookupDesc',
      desc: '',
      args: [],
    );
  }

  /// `Domain or IP`
  String get mrsLookupHint {
    return Intl.message(
      'Domain or IP',
      name: 'mrsLookupHint',
      desc: '',
      args: [],
    );
  }

  /// `Failed to load rule sets`
  String get mrsPrepareFailed {
    return Intl.message(
      'Failed to load rule sets',
      name: 'mrsPrepareFailed',
      desc: '',
      args: [],
    );
  }

  /// `Bundled BundleMRS not found`
  String get mrsMissing {
    return Intl.message(
      'Bundled BundleMRS not found',
      name: 'mrsMissing',
      desc: '',
      args: [],
    );
  }

  /// `No rule set matched`
  String get mrsNoMatch {
    return Intl.message(
      'No rule set matched',
      name: 'mrsNoMatch',
      desc: '',
      args: [],
    );
  }

  /// `In use`
  String get mrsReferenced {
    return Intl.message('In use', name: 'mrsReferenced', desc: '', args: []);
  }

  /// `{count} entries`
  String mrsRules(Object count) {
    return Intl.message(
      '$count entries',
      name: 'mrsRules',
      desc: '',
      args: [count],
    );
  }

  /// `via {ip}`
  String mrsVia(Object ip) {
    return Intl.message('via $ip', name: 'mrsVia', desc: '', args: [ip]);
  }

  /// `Tap action`
  String get mrsTapAction {
    return Intl.message('Tap action', name: 'mrsTapAction', desc: '', args: []);
  }

  /// `View rules`
  String get mrsViewRules {
    return Intl.message('View rules', name: 'mrsViewRules', desc: '', args: []);
  }

  /// `Copy URL`
  String get mrsCopyUrl {
    return Intl.message('Copy URL', name: 'mrsCopyUrl', desc: '', args: []);
  }

  /// `Resolve domains with DNS rules`
  String get mrsResolveDns {
    return Intl.message(
      'Resolve domains with DNS rules',
      name: 'mrsResolveDns',
      desc: '',
      args: [],
    );
  }

  /// `When on, domains are resolved to IPs with the current DNS config and the IPs are matched too`
  String get mrsResolveDnsDesc {
    return Intl.message(
      'When on, domains are resolved to IPs with the current DNS config and the IPs are matched too',
      name: 'mrsResolveDnsDesc',
      desc: '',
      args: [],
    );
  }

  /// `DNS Lookup`
  String get dnsQuery {
    return Intl.message('DNS Lookup', name: 'dnsQuery', desc: '', args: []);
  }

  /// `Resolve with rules, system or a chosen server`
  String get dnsQueryDesc {
    return Intl.message(
      'Resolve with rules, system or a chosen server',
      name: 'dnsQueryDesc',
      desc: '',
      args: [],
    );
  }

  /// `Domain`
  String get dnsQueryHint {
    return Intl.message('Domain', name: 'dnsQueryHint', desc: '', args: []);
  }

  /// `System DNS`
  String get dnsQuerySystem {
    return Intl.message(
      'System DNS',
      name: 'dnsQuerySystem',
      desc: '',
      args: [],
    );
  }

  /// `DNS Server`
  String get dnsQueryServer {
    return Intl.message(
      'DNS Server',
      name: 'dnsQueryServer',
      desc: '',
      args: [],
    );
  }

  /// `e.g. 1.1.1.1, https://cloudflare-dns.com/dns-query`
  String get dnsQueryServerHint {
    return Intl.message(
      'e.g. 1.1.1.1, https://cloudflare-dns.com/dns-query',
      name: 'dnsQueryServerHint',
      desc: '',
      args: [],
    );
  }

  /// `Invalid DNS server`
  String get dnsQueryServerInvalid {
    return Intl.message(
      'Invalid DNS server',
      name: 'dnsQueryServerInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Compare`
  String get dnsQueryCompare {
    return Intl.message('Compare', name: 'dnsQueryCompare', desc: '', args: []);
  }

  /// `Resolve with rules, system DNS and the chosen server side by side to spot pollution or routing differences`
  String get dnsQueryCompareDesc {
    return Intl.message(
      'Resolve with rules, system DNS and the chosen server side by side to spot pollution or routing differences',
      name: 'dnsQueryCompareDesc',
      desc: '',
      args: [],
    );
  }

  /// `Proxy is not running, "Follow Rules" is unavailable`
  String get dnsQueryStopped {
    return Intl.message(
      'Proxy is not running, "Follow Rules" is unavailable',
      name: 'dnsQueryStopped',
      desc: '',
      args: [],
    );
  }

  /// `No records`
  String get dnsQueryNoRecords {
    return Intl.message(
      'No records',
      name: 'dnsQueryNoRecords',
      desc: '',
      args: [],
    );
  }

  /// `Fake-IP · {reason}: will return a virtual address from {range}`
  String dnsQueryFakeIpOn(Object reason, Object range) {
    return Intl.message(
      'Fake-IP · $reason: will return a virtual address from $range',
      name: 'dnsQueryFakeIpOn',
      desc: '',
      args: [reason, range],
    );
  }

  /// `Fake-IP · {reason}: will return the real IP`
  String dnsQueryFakeIpOff(Object reason) {
    return Intl.message(
      'Fake-IP · $reason: will return the real IP',
      name: 'dnsQueryFakeIpOff',
      desc: '',
      args: [reason],
    );
  }

  /// `not in blacklist`
  String get dnsQueryFilterBlackMiss {
    return Intl.message(
      'not in blacklist',
      name: 'dnsQueryFilterBlackMiss',
      desc: '',
      args: [],
    );
  }

  /// `in blacklist`
  String get dnsQueryFilterBlackHit {
    return Intl.message(
      'in blacklist',
      name: 'dnsQueryFilterBlackHit',
      desc: '',
      args: [],
    );
  }

  /// `in whitelist`
  String get dnsQueryFilterWhiteHit {
    return Intl.message(
      'in whitelist',
      name: 'dnsQueryFilterWhiteHit',
      desc: '',
      args: [],
    );
  }

  /// `not in whitelist`
  String get dnsQueryFilterWhiteMiss {
    return Intl.message(
      'not in whitelist',
      name: 'dnsQueryFilterWhiteMiss',
      desc: '',
      args: [],
    );
  }

  /// `rule says fake-ip`
  String get dnsQueryFilterRuleFake {
    return Intl.message(
      'rule says fake-ip',
      name: 'dnsQueryFilterRuleFake',
      desc: '',
      args: [],
    );
  }

  /// `rule says real-ip`
  String get dnsQueryFilterRuleReal {
    return Intl.message(
      'rule says real-ip',
      name: 'dnsQueryFilterRuleReal',
      desc: '',
      args: [],
    );
  }

  /// `Redir-Host: will return the real IP, domain restored on connect`
  String get dnsQueryRedirHost {
    return Intl.message(
      'Redir-Host: will return the real IP, domain restored on connect',
      name: 'dnsQueryRedirHost',
      desc: '',
      args: [],
    );
  }

  /// `Normal: will return the real IP, rules match by IP`
  String get dnsQueryNormalMode {
    return Intl.message(
      'Normal: will return the real IP, rules match by IP',
      name: 'dnsQueryNormalMode',
      desc: '',
      args: [],
    );
  }

  /// `Matched Hosts: will return {ips}`
  String dnsQueryHostsHit(Object ips) {
    return Intl.message(
      'Matched Hosts: will return $ips',
      name: 'dnsQueryHostsHit',
      desc: '',
      args: [ips],
    );
  }

  /// `Final outbound "{outbound}", the node resolves the domain`
  String dnsQueryViaProxy(Object outbound) {
    return Intl.message(
      'Final outbound "$outbound", the node resolves the domain',
      name: 'dnsQueryViaProxy',
      desc: '',
      args: [outbound],
    );
  }

  /// `Final outbound "{outbound}", the node resolves the domain; Hosts not applied`
  String dnsQueryViaProxyHosts(Object outbound) {
    return Intl.message(
      'Final outbound "$outbound", the node resolves the domain; Hosts not applied',
      name: 'dnsQueryViaProxyHosts',
      desc: '',
      args: [outbound],
    );
  }

  /// `Final outbound DIRECT, resolved locally by the core and connected directly`
  String get dnsQueryViaDirect {
    return Intl.message(
      'Final outbound DIRECT, resolved locally by the core and connected directly',
      name: 'dnsQueryViaDirect',
      desc: '',
      args: [],
    );
  }

  /// `Final outbound DIRECT, connects to the Hosts address`
  String get dnsQueryViaDirectHosts {
    return Intl.message(
      'Final outbound DIRECT, connects to the Hosts address',
      name: 'dnsQueryViaDirectHosts',
      desc: '',
      args: [],
    );
  }

  /// `Rejected by rules`
  String get dnsQueryViaReject {
    return Intl.message(
      'Rejected by rules',
      name: 'dnsQueryViaReject',
      desc: '',
      args: [],
    );
  }

  /// `Age Encrypt / Decrypt`
  String get ageTool {
    return Intl.message(
      'Age Encrypt / Decrypt',
      name: 'ageTool',
      desc: '',
      args: [],
    );
  }

  /// `Generate keys, encrypt or decrypt text and configs`
  String get ageToolDesc {
    return Intl.message(
      'Generate keys, encrypt or decrypt text and configs',
      name: 'ageToolDesc',
      desc: '',
      args: [],
    );
  }

  /// `Keys`
  String get ageTabKeys {
    return Intl.message('Keys', name: 'ageTabKeys', desc: '', args: []);
  }

  /// `Key type`
  String get ageKeyType {
    return Intl.message('Key type', name: 'ageKeyType', desc: '', args: []);
  }

  /// `Post-quantum hybrid key. Stronger, but the public key is much longer and requires age v1.3 or later.`
  String get ageKeyHybridTip {
    return Intl.message(
      'Post-quantum hybrid key. Stronger, but the public key is much longer and requires age v1.3 or later.',
      name: 'ageKeyHybridTip',
      desc: '',
      args: [],
    );
  }

  /// `Encrypt`
  String get ageTabEncrypt {
    return Intl.message('Encrypt', name: 'ageTabEncrypt', desc: '', args: []);
  }

  /// `Decrypt`
  String get ageTabDecrypt {
    return Intl.message('Decrypt', name: 'ageTabDecrypt', desc: '', args: []);
  }

  /// `New Key Pair`
  String get ageGenerateKeyPair {
    return Intl.message(
      'New Key Pair',
      name: 'ageGenerateKeyPair',
      desc: '',
      args: [],
    );
  }

  /// `Use to Encrypt`
  String get ageUseForEncrypt {
    return Intl.message(
      'Use to Encrypt',
      name: 'ageUseForEncrypt',
      desc: '',
      args: [],
    );
  }

  /// `Plain Text`
  String get agePlainText {
    return Intl.message('Plain Text', name: 'agePlainText', desc: '', args: []);
  }

  /// `Cipher Text (-----BEGIN AGE ENCRYPTED FILE-----)`
  String get ageCipherText {
    return Intl.message(
      'Cipher Text (-----BEGIN AGE ENCRYPTED FILE-----)',
      name: 'ageCipherText',
      desc: '',
      args: [],
    );
  }

  /// `Recipient Public Keys`
  String get ageRecipients {
    return Intl.message(
      'Recipient Public Keys',
      name: 'ageRecipients',
      desc: '',
      args: [],
    );
  }

  /// `One age1… key per line, multiple allowed`
  String get ageRecipientsHint {
    return Intl.message(
      'One age1… key per line, multiple allowed',
      name: 'ageRecipientsHint',
      desc: '',
      args: [],
    );
  }

  /// `Add at least one recipient public key`
  String get ageRecipientRequired {
    return Intl.message(
      'Add at least one recipient public key',
      name: 'ageRecipientRequired',
      desc: '',
      args: [],
    );
  }

  /// `Enter content or choose a file`
  String get ageInputRequired {
    return Intl.message(
      'Enter content or choose a file',
      name: 'ageInputRequired',
      desc: '',
      args: [],
    );
  }

  /// `Result`
  String get ageOutput {
    return Intl.message('Result', name: 'ageOutput', desc: '', args: []);
  }

  /// `Encryption failed`
  String get ageEncryptFailed {
    return Intl.message(
      'Encryption failed',
      name: 'ageEncryptFailed',
      desc: '',
      args: [],
    );
  }

  /// `Decryption failed`
  String get ageDecryptFailed {
    return Intl.message(
      'Decryption failed',
      name: 'ageDecryptFailed',
      desc: '',
      args: [],
    );
  }

  /// `Content is not Age encrypted`
  String get ageNotEncrypted {
    return Intl.message(
      'Content is not Age encrypted',
      name: 'ageNotEncrypted',
      desc: '',
      args: [],
    );
  }

  /// `File too large (8 MB max)`
  String get ageFileTooLarge {
    return Intl.message(
      'File too large (8 MB max)',
      name: 'ageFileTooLarge',
      desc: '',
      args: [],
    );
  }

  /// `Use Current Profile Key`
  String get ageUseProfileKey {
    return Intl.message(
      'Use Current Profile Key',
      name: 'ageUseProfileKey',
      desc: '',
      args: [],
    );
  }

  /// `Everything runs locally. Private keys are never stored or uploaded.`
  String get ageToolTip {
    return Intl.message(
      'Everything runs locally. Private keys are never stored or uploaded.',
      name: 'ageToolTip',
      desc: '',
      args: [],
    );
  }

  /// `Batch Node Test`
  String get mediaBatchTest {
    return Intl.message(
      'Batch Node Test',
      name: 'mediaBatchTest',
      desc: '',
      args: [],
    );
  }

  /// `{done}/{total} tested · {unlocked} available`
  String mediaBatchSummary(Object done, Object total, Object unlocked) {
    return Intl.message(
      '$done/$total tested · $unlocked available',
      name: 'mediaBatchSummary',
      desc: '',
      args: [done, total, unlocked],
    );
  }

  /// `No nodes to test`
  String get mediaBatchNoNodes {
    return Intl.message(
      'No nodes to test',
      name: 'mediaBatchNoNodes',
      desc: '',
      args: [],
    );
  }

  /// `Clear history`
  String get toolHistoryClear {
    return Intl.message(
      'Clear history',
      name: 'toolHistoryClear',
      desc: '',
      args: [],
    );
  }

  /// `Choose what to test`
  String get mediaBatchScope {
    return Intl.message(
      'Choose what to test',
      name: 'mediaBatchScope',
      desc: '',
      args: [],
    );
  }

  /// `All nodes`
  String get mediaBatchAll {
    return Intl.message('All nodes', name: 'mediaBatchAll', desc: '', args: []);
  }

  /// `Every node, excluding DIRECT`
  String get mediaBatchAllDesc {
    return Intl.message(
      'Every node, excluding DIRECT',
      name: 'mediaBatchAllDesc',
      desc: '',
      args: [],
    );
  }

  /// `Test`
  String get mediaBatchGroup {
    return Intl.message('Test', name: 'mediaBatchGroup', desc: '', args: []);
  }

  /// `Tap a card to change its size, long-press and drag to rearrange`
  String get toolboxEditTip {
    return Intl.message(
      'Tap a card to change its size, long-press and drag to rearrange',
      name: 'toolboxEditTip',
      desc: '',
      args: [],
    );
  }

  /// `Click a card to change its size, drag to rearrange`
  String get toolboxEditTipDesktop {
    return Intl.message(
      'Click a card to change its size, drag to rearrange',
      name: 'toolboxEditTipDesktop',
      desc: '',
      args: [],
    );
  }

  /// `Select a card and press OK to change its size`
  String get toolboxEditTipTv {
    return Intl.message(
      'Select a card and press OK to change its size',
      name: 'toolboxEditTipTv',
      desc: '',
      args: [],
    );
  }

  /// `Total`
  String get dashboardTotal {
    return Intl.message('Total', name: 'dashboardTotal', desc: '', args: []);
  }

  /// `Avg {value}`
  String dashboardAverage(Object value) {
    return Intl.message(
      'Avg $value',
      name: 'dashboardAverage',
      desc: '',
      args: [value],
    );
  }

  /// `iPerf3 Tool`
  String get iperfTest {
    return Intl.message('iPerf3 Tool', name: 'iperfTest', desc: '', args: []);
  }

  /// `Measure bandwidth between devices on your LAN, compatible with iperf3`
  String get iperfTestDesc {
    return Intl.message(
      'Measure bandwidth between devices on your LAN, compatible with iperf3',
      name: 'iperfTestDesc',
      desc: '',
      args: [],
    );
  }

  /// `Server`
  String get iperfServer {
    return Intl.message('Server', name: 'iperfServer', desc: '', args: []);
  }

  /// `Client`
  String get iperfClient {
    return Intl.message('Client', name: 'iperfClient', desc: '', args: []);
  }

  /// `Start server`
  String get iperfServerStart {
    return Intl.message(
      'Start server',
      name: 'iperfServerStart',
      desc: '',
      args: [],
    );
  }

  /// `Stop server`
  String get iperfServerStop {
    return Intl.message(
      'Stop server',
      name: 'iperfServerStop',
      desc: '',
      args: [],
    );
  }

  /// `Server is not running`
  String get iperfServerOff {
    return Intl.message(
      'Server is not running',
      name: 'iperfServerOff',
      desc: '',
      args: [],
    );
  }

  /// `Listening on port {port}`
  String iperfServerListening(Object port) {
    return Intl.message(
      'Listening on port $port',
      name: 'iperfServerListening',
      desc: '',
      args: [port],
    );
  }

  /// `Once started, other devices can scan the QR code or enter this device's address to connect`
  String get iperfServerOffHint {
    return Intl.message(
      'Once started, other devices can scan the QR code or enter this device\'s address to connect',
      name: 'iperfServerOffHint',
      desc: '',
      args: [],
    );
  }

  /// `Scan with FastLin on another device to connect in one tap`
  String get iperfScanHint {
    return Intl.message(
      'Scan with FastLin on another device to connect in one tap',
      name: 'iperfScanHint',
      desc: '',
      args: [],
    );
  }

  /// `This device`
  String get iperfAddresses {
    return Intl.message(
      'This device',
      name: 'iperfAddresses',
      desc: '',
      args: [],
    );
  }

  /// `iperf3 commands`
  String get iperfCommands {
    return Intl.message(
      'iperf3 commands',
      name: 'iperfCommands',
      desc: '',
      args: [],
    );
  }

  /// `No LAN address found. Make sure Wi-Fi or Ethernet is connected`
  String get iperfNoAddress {
    return Intl.message(
      'No LAN address found. Make sure Wi-Fi or Ethernet is connected',
      name: 'iperfNoAddress',
      desc: '',
      args: [],
    );
  }

  /// `Port`
  String get iperfPort {
    return Intl.message('Port', name: 'iperfPort', desc: '', args: []);
  }

  /// `Enter a port between 1 and 65535`
  String get iperfPortInvalid {
    return Intl.message(
      'Enter a port between 1 and 65535',
      name: 'iperfPortInvalid',
      desc: '',
      args: [],
    );
  }

  /// `The server only runs while this page is open and stops when you leave. The screen stays on while it runs.`
  String get iperfServerTip {
    return Intl.message(
      'The server only runs while this page is open and stops when you leave. The screen stays on while it runs.',
      name: 'iperfServerTip',
      desc: '',
      args: [],
    );
  }

  /// `If other devices can't connect, allow incoming connections for the FastLin core in your system firewall.`
  String get iperfFirewallTip {
    return Intl.message(
      'If other devices can\'t connect, allow incoming connections for the FastLin core in your system firewall.',
      name: 'iperfFirewallTip',
      desc: '',
      args: [],
    );
  }

  /// `The UDP port is in use, so only TCP tests are available.`
  String get iperfUdpUnavailable {
    return Intl.message(
      'The UDP port is in use, so only TCP tests are available.',
      name: 'iperfUdpUnavailable',
      desc: '',
      args: [],
    );
  }

  /// `Server address, e.g. 192.168.1.5`
  String get iperfAddressHint {
    return Intl.message(
      'Server address, e.g. 192.168.1.5',
      name: 'iperfAddressHint',
      desc: '',
      args: [],
    );
  }

  /// `Scan to connect`
  String get iperfScan {
    return Intl.message(
      'Scan to connect',
      name: 'iperfScan',
      desc: '',
      args: [],
    );
  }

  /// `Scanned: {name}`
  String iperfScanned(Object name) {
    return Intl.message(
      'Scanned: $name',
      name: 'iperfScanned',
      desc: '',
      args: [name],
    );
  }

  /// `This isn't an iPerf3 connection QR code`
  String get iperfScanInvalid {
    return Intl.message(
      'This isn\'t an iPerf3 connection QR code',
      name: 'iperfScanInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Enter a server address`
  String get iperfAddressRequired {
    return Intl.message(
      'Enter a server address',
      name: 'iperfAddressRequired',
      desc: '',
      args: [],
    );
  }

  /// `Protocol`
  String get iperfProtocol {
    return Intl.message('Protocol', name: 'iperfProtocol', desc: '', args: []);
  }

  /// `Direction`
  String get iperfDirection {
    return Intl.message(
      'Direction',
      name: 'iperfDirection',
      desc: '',
      args: [],
    );
  }

  /// `Streams`
  String get iperfParallel {
    return Intl.message('Streams', name: 'iperfParallel', desc: '', args: []);
  }

  /// `Duration`
  String get iperfDuration {
    return Intl.message('Duration', name: 'iperfDuration', desc: '', args: []);
  }

  /// `Send rate`
  String get iperfBandwidth {
    return Intl.message(
      'Send rate',
      name: 'iperfBandwidth',
      desc: '',
      args: [],
    );
  }

  /// `Both`
  String get iperfBidir {
    return Intl.message('Both', name: 'iperfBidir', desc: '', args: []);
  }

  /// `Receive`
  String get iperfReceive {
    return Intl.message('Receive', name: 'iperfReceive', desc: '', args: []);
  }

  /// `Send`
  String get iperfSend {
    return Intl.message('Send', name: 'iperfSend', desc: '', args: []);
  }

  /// `Start test`
  String get iperfStart {
    return Intl.message('Start test', name: 'iperfStart', desc: '', args: []);
  }

  /// `Test again`
  String get iperfRetest {
    return Intl.message('Test again', name: 'iperfRetest', desc: '', args: []);
  }

  /// `Enter a server address or scan a QR code to start`
  String get iperfReady {
    return Intl.message(
      'Enter a server address or scan a QR code to start',
      name: 'iperfReady',
      desc: '',
      args: [],
    );
  }

  /// `Connecting…`
  String get iperfConnecting {
    return Intl.message(
      'Connecting…',
      name: 'iperfConnecting',
      desc: '',
      args: [],
    );
  }

  /// `Testing`
  String get iperfRunning {
    return Intl.message('Testing', name: 'iperfRunning', desc: '', args: []);
  }

  /// `Test complete`
  String get iperfDone {
    return Intl.message('Test complete', name: 'iperfDone', desc: '', args: []);
  }

  /// `Waiting for a client`
  String get iperfWaiting {
    return Intl.message(
      'Waiting for a client',
      name: 'iperfWaiting',
      desc: '',
      args: [],
    );
  }

  /// `Throughput`
  String get iperfThroughput {
    return Intl.message(
      'Throughput',
      name: 'iperfThroughput',
      desc: '',
      args: [],
    );
  }

  /// `Retransmits`
  String get iperfRetransmits {
    return Intl.message(
      'Retransmits',
      name: 'iperfRetransmits',
      desc: '',
      args: [],
    );
  }

  /// `RTT`
  String get iperfRtt {
    return Intl.message('RTT', name: 'iperfRtt', desc: '', args: []);
  }

  /// `Enter a whole number from {min} to {max}`
  String numberRangeInvalid(Object min, Object max) {
    return Intl.message(
      'Enter a whole number from $min to $max',
      name: 'numberRangeInvalid',
      desc: '',
      args: [min, max],
    );
  }

  /// `Local Ping`
  String get localPing {
    return Intl.message('Local Ping', name: 'localPing', desc: '', args: []);
  }

  /// `Direct ICMP, TCP and UDP latency and loss test`
  String get localPingDesc {
    return Intl.message(
      'Direct ICMP, TCP and UDP latency and loss test',
      name: 'localPingDesc',
      desc: '',
      args: [],
    );
  }

  /// `Domain or IP address`
  String get localPingTargetHint {
    return Intl.message(
      'Domain or IP address',
      name: 'localPingTargetHint',
      desc: '',
      args: [],
    );
  }

  /// `Gateway`
  String get localPingGateway {
    return Intl.message(
      'Gateway',
      name: 'localPingGateway',
      desc: '',
      args: [],
    );
  }

  /// `Count`
  String get localPingCount {
    return Intl.message('Count', name: 'localPingCount', desc: '', args: []);
  }

  /// `Packet size`
  String get localPingSize {
    return Intl.message(
      'Packet size',
      name: 'localPingSize',
      desc: '',
      args: [],
    );
  }

  /// `Choose a target to start`
  String get localPingReady {
    return Intl.message(
      'Choose a target to start',
      name: 'localPingReady',
      desc: '',
      args: [],
    );
  }

  /// `Resolving`
  String get localPingResolving {
    return Intl.message(
      'Resolving',
      name: 'localPingResolving',
      desc: '',
      args: [],
    );
  }

  /// `Pinging`
  String get localPingRunning {
    return Intl.message(
      'Pinging',
      name: 'localPingRunning',
      desc: '',
      args: [],
    );
  }

  /// `Ping finished`
  String get localPingDone {
    return Intl.message(
      'Ping finished',
      name: 'localPingDone',
      desc: '',
      args: [],
    );
  }

  /// `Ping result`
  String get localPingResult {
    return Intl.message(
      'Ping result',
      name: 'localPingResult',
      desc: '',
      args: [],
    );
  }

  /// `Start ping`
  String get localPingStart {
    return Intl.message(
      'Start ping',
      name: 'localPingStart',
      desc: '',
      args: [],
    );
  }

  /// `Sent`
  String get localPingSent {
    return Intl.message('Sent', name: 'localPingSent', desc: '', args: []);
  }

  /// `Received`
  String get localPingReceived {
    return Intl.message(
      'Received',
      name: 'localPingReceived',
      desc: '',
      args: [],
    );
  }

  /// `Average`
  String get localPingAverage {
    return Intl.message(
      'Average',
      name: 'localPingAverage',
      desc: '',
      args: [],
    );
  }

  /// `Min`
  String get localPingMin {
    return Intl.message('Min', name: 'localPingMin', desc: '', args: []);
  }

  /// `Max`
  String get localPingMax {
    return Intl.message('Max', name: 'localPingMax', desc: '', args: []);
  }

  /// `From {address}`
  String localPingFrom(Object address) {
    return Intl.message(
      'From $address',
      name: 'localPingFrom',
      desc: '',
      args: [address],
    );
  }

  /// `{count} bytes`
  String localPingBytes(Object count) {
    return Intl.message(
      '$count bytes',
      name: 'localPingBytes',
      desc: '',
      args: [count],
    );
  }

  /// `Request timed out`
  String get localPingTimeout {
    return Intl.message(
      'Request timed out',
      name: 'localPingTimeout',
      desc: '',
      args: [],
    );
  }

  /// `Port closed`
  String get localPingClosed {
    return Intl.message(
      'Port closed',
      name: 'localPingClosed',
      desc: '',
      args: [],
    );
  }

  /// `Destination unreachable`
  String get localPingUnreachable {
    return Intl.message(
      'Destination unreachable',
      name: 'localPingUnreachable',
      desc: '',
      args: [],
    );
  }

  /// `Send failed`
  String get localPingFailed {
    return Intl.message(
      'Send failed',
      name: 'localPingFailed',
      desc: '',
      args: [],
    );
  }

  /// `Could not resolve the domain`
  String get localPingErrorResolve {
    return Intl.message(
      'Could not resolve the domain',
      name: 'localPingErrorResolve',
      desc: '',
      args: [],
    );
  }

  /// `ICMP is not permitted on this system. Try TCP or UDP ping`
  String get localPingErrorDenied {
    return Intl.message(
      'ICMP is not permitted on this system. Try TCP or UDP ping',
      name: 'localPingErrorDenied',
      desc: '',
      args: [],
    );
  }

  /// `Unable to send ping packets`
  String get localPingErrorNetwork {
    return Intl.message(
      'Unable to send ping packets',
      name: 'localPingErrorNetwork',
      desc: '',
      args: [],
    );
  }

  /// `TCP ping measures connection setup time. A refused connection also means the host is reachable`
  String get localPingTcpTip {
    return Intl.message(
      'TCP ping measures connection setup time. A refused connection also means the host is reachable',
      name: 'localPingTcpTip',
      desc: '',
      args: [],
    );
  }

  /// `Port 53 sends a DNS query and waits for the answer. Most other ports never reply, so a timeout does not mean the host is down`
  String get localPingUdpTip {
    return Intl.message(
      'Port 53 sends a DNS query and waits for the answer. Most other ports never reply, so a timeout does not mean the host is down',
      name: 'localPingUdpTip',
      desc: '',
      args: [],
    );
  }

  /// `Showing the latest {count}. Copy the result to see all`
  String localPingListLimit(Object count) {
    return Intl.message(
      'Showing the latest $count. Copy the result to see all',
      name: 'localPingListLimit',
      desc: '',
      args: [count],
    );
  }

  /// `Sent {sent}, received {received}, lost {lost} ({loss}% loss)`
  String localPingSummary(
    Object sent,
    Object received,
    Object lost,
    Object loss,
  ) {
    return Intl.message(
      'Sent $sent, received $received, lost $lost ($loss% loss)',
      name: 'localPingSummary',
      desc: '',
      args: [sent, received, lost, loss],
    );
  }

  /// `Round trip: min {min} / avg {avg} / max {max} / jitter {jitter} ms`
  String localPingRttSummary(
    Object min,
    Object avg,
    Object max,
    Object jitter,
  ) {
    return Intl.message(
      'Round trip: min $min / avg $avg / max $max / jitter $jitter ms',
      name: 'localPingRttSummary',
      desc: '',
      args: [min, avg, max, jitter],
    );
  }

  /// `Ping statistics for {target}`
  String localPingStats(Object target) {
    return Intl.message(
      'Ping statistics for $target',
      name: 'localPingStats',
      desc: '',
      args: [target],
    );
  }

  /// `Data`
  String get iperfTransferred {
    return Intl.message('Data', name: 'iperfTransferred', desc: '', args: []);
  }

  /// `Peer`
  String get iperfPeer {
    return Intl.message('Peer', name: 'iperfPeer', desc: '', args: []);
  }

  /// `{count} streams`
  String iperfStreams(Object count) {
    return Intl.message(
      '$count streams',
      name: 'iperfStreams',
      desc: '',
      args: [count],
    );
  }

  /// `{value} s`
  String iperfSeconds(Object value) {
    return Intl.message(
      '$value s',
      name: 'iperfSeconds',
      desc: '',
      args: [value],
    );
  }

  /// `{lost}/{total} packets`
  String iperfLostPackets(Object lost, Object total) {
    return Intl.message(
      '$lost/$total packets',
      name: 'iperfLostPackets',
      desc: '',
      args: [lost, total],
    );
  }

  /// `The server is busy with another test. Try again later`
  String get iperfErrorBusy {
    return Intl.message(
      'The server is busy with another test. Try again later',
      name: 'iperfErrorBusy',
      desc: '',
      args: [],
    );
  }

  /// `Connection refused. Make sure the iPerf3 server is running`
  String get iperfErrorRefused {
    return Intl.message(
      'Connection refused. Make sure the iPerf3 server is running',
      name: 'iperfErrorRefused',
      desc: '',
      args: [],
    );
  }

  /// `Connection timed out. Check the address and network`
  String get iperfErrorTimeout {
    return Intl.message(
      'Connection timed out. Check the address and network',
      name: 'iperfErrorTimeout',
      desc: '',
      args: [],
    );
  }

  /// `Can't reach the server`
  String get iperfErrorUnreachable {
    return Intl.message(
      'Can\'t reach the server',
      name: 'iperfErrorUnreachable',
      desc: '',
      args: [],
    );
  }

  /// `UDP handshake failed. It may be blocked by a firewall`
  String get iperfErrorUdp {
    return Intl.message(
      'UDP handshake failed. It may be blocked by a firewall',
      name: 'iperfErrorUdp',
      desc: '',
      args: [],
    );
  }

  /// `Unexpected response. The other side may not be an iPerf3 server`
  String get iperfErrorProtocol {
    return Intl.message(
      'Unexpected response. The other side may not be an iPerf3 server',
      name: 'iperfErrorProtocol',
      desc: '',
      args: [],
    );
  }

  /// `The test was interrupted`
  String get iperfErrorInterrupted {
    return Intl.message(
      'The test was interrupted',
      name: 'iperfErrorInterrupted',
      desc: '',
      args: [],
    );
  }

  /// `The server rejected the test (error {code})`
  String iperfErrorServer(Object code) {
    return Intl.message(
      'The server rejected the test (error $code)',
      name: 'iperfErrorServer',
      desc: '',
      args: [code],
    );
  }

  /// `Port {port} is already in use. Try another port`
  String iperfErrorPortInUse(Object port) {
    return Intl.message(
      'Port $port is already in use. Try another port',
      name: 'iperfErrorPortInUse',
      desc: '',
      args: [port],
    );
  }

  /// `Couldn't start the server`
  String get iperfErrorListen {
    return Intl.message(
      'Couldn\'t start the server',
      name: 'iperfErrorListen',
      desc: '',
      args: [],
    );
  }

  /// `Result`
  String get iperfResult {
    return Intl.message('Result', name: 'iperfResult', desc: '', args: []);
  }

  /// `See exactly where your traffic goes by day, week and month`
  String get trafficStatsDesc {
    return Intl.message(
      'See exactly where your traffic goes by day, week and month',
      name: 'trafficStatsDesc',
      desc: '',
      args: [],
    );
  }

  /// `Today`
  String get today {
    return Intl.message('Today', name: 'today', desc: '', args: []);
  }

  /// `This Week`
  String get thisWeek {
    return Intl.message('This Week', name: 'thisWeek', desc: '', args: []);
  }

  /// `This Month`
  String get thisMonth {
    return Intl.message('This Month', name: 'thisMonth', desc: '', args: []);
  }

  /// `Trend`
  String get trafficTrend {
    return Intl.message('Trend', name: 'trafficTrend', desc: '', args: []);
  }

  /// `Ranking`
  String get trafficRanking {
    return Intl.message('Ranking', name: 'trafficRanking', desc: '', args: []);
  }

  /// `Rule hits`
  String get ruleHits {
    return Intl.message('Rule hits', name: 'ruleHits', desc: '', args: []);
  }

  /// `{count, plural, one{{count} hit} other{{count} hits}}`
  String hitCount(num count) {
    return Intl.plural(
      count,
      one: '$count hit',
      other: '$count hits',
      name: 'hitCount',
      desc: '',
      args: [count],
    );
  }

  /// `Process`
  String get process {
    return Intl.message('Process', name: 'process', desc: '', args: []);
  }

  /// `Node`
  String get node {
    return Intl.message('Node', name: 'node', desc: '', args: []);
  }

  /// `Traffic statistics`
  String get trafficStatsEnable {
    return Intl.message(
      'Traffic statistics',
      name: 'trafficStatsEnable',
      desc: '',
      args: [],
    );
  }

  /// `Record details`
  String get trafficStatsDetail {
    return Intl.message(
      'Record details',
      name: 'trafficStatsDetail',
      desc: '',
      args: [],
    );
  }

  /// `Record domains, processes, nodes and rules. When off, only totals are kept`
  String get trafficStatsDetailDesc {
    return Intl.message(
      'Record domains, processes, nodes and rules. When off, only totals are kept',
      name: 'trafficStatsDetailDesc',
      desc: '',
      args: [],
    );
  }

  /// `Show site icons`
  String get trafficStatsSiteIcon {
    return Intl.message(
      'Show site icons',
      name: 'trafficStatsSiteIcon',
      desc: '',
      args: [],
    );
  }

  /// `Fetch icons from the sites first, use Google's icon service when a site has no sharp icon, and cache them locally`
  String get trafficStatsSiteIconDesc {
    return Intl.message(
      'Fetch icons from the sites first, use Google\'s icon service when a site has no sharp icon, and cache them locally',
      name: 'trafficStatsSiteIconDesc',
      desc: '',
      args: [],
    );
  }

  /// `Data retention`
  String get trafficStatsRetention {
    return Intl.message(
      'Data retention',
      name: 'trafficStatsRetention',
      desc: '',
      args: [],
    );
  }

  /// `Clear all traffic statistics?`
  String get trafficStatsClearTip {
    return Intl.message(
      'Clear all traffic statistics?',
      name: 'trafficStatsClearTip',
      desc: '',
      args: [],
    );
  }

  /// `Off by default. Once on, traffic is recorded on this device only`
  String get trafficStatsDisabledTip {
    return Intl.message(
      'Off by default. Once on, traffic is recorded on this device only',
      name: 'trafficStatsDisabledTip',
      desc: '',
      args: [],
    );
  }

  /// `Subdomains`
  String get subdomains {
    return Intl.message('Subdomains', name: 'subdomains', desc: '', args: []);
  }

  /// `Check IP purity`
  String get ipRiskCheck {
    return Intl.message(
      'Check IP purity',
      name: 'ipRiskCheck',
      desc: '',
      args: [],
    );
  }

  /// `Config info`
  String get configInfo {
    return Intl.message('Config info', name: 'configInfo', desc: '', args: []);
  }

  /// `Generate QR code`
  String get generateQrCode {
    return Intl.message(
      'Generate QR code',
      name: 'generateQrCode',
      desc: '',
      args: [],
    );
  }

  /// `Share node (URI)`
  String get nodeShareUri {
    return Intl.message(
      'Share node (URI)',
      name: 'nodeShareUri',
      desc: '',
      args: [],
    );
  }

  /// `View config (edit)`
  String get configViewEdit {
    return Intl.message(
      'View config (edit)',
      name: 'configViewEdit',
      desc: '',
      args: [],
    );
  }

  /// `View config (read-only)`
  String get configViewReadOnly {
    return Intl.message(
      'View config (read-only)',
      name: 'configViewReadOnly',
      desc: '',
      args: [],
    );
  }

  /// `Share config (YAML)`
  String get configShareYaml {
    return Intl.message(
      'Share config (YAML)',
      name: 'configShareYaml',
      desc: '',
      args: [],
    );
  }

  /// `This node can't be shared as a URI`
  String get uriShareUnsupported {
    return Intl.message(
      'This node can\'t be shared as a URI',
      name: 'uriShareUnsupported',
      desc: '',
      args: [],
    );
  }

  /// `Fraud score`
  String get ipRiskScore {
    return Intl.message('Fraud score', name: 'ipRiskScore', desc: '', args: []);
  }

  /// `Low risk`
  String get ipRiskLow {
    return Intl.message('Low risk', name: 'ipRiskLow', desc: '', args: []);
  }

  /// `Medium risk`
  String get ipRiskMedium {
    return Intl.message(
      'Medium risk',
      name: 'ipRiskMedium',
      desc: '',
      args: [],
    );
  }

  /// `High risk`
  String get ipRiskHigh {
    return Intl.message('High risk', name: 'ipRiskHigh', desc: '', args: []);
  }

  /// `Very high risk`
  String get ipRiskVeryHigh {
    return Intl.message(
      'Very high risk',
      name: 'ipRiskVeryHigh',
      desc: '',
      args: [],
    );
  }

  /// `Hosting or proxy`
  String get ipRiskHostingOrProxy {
    return Intl.message(
      'Hosting or proxy',
      name: 'ipRiskHostingOrProxy',
      desc: '',
      args: [],
    );
  }

  /// `Datacenter`
  String get ipRiskDatacenter {
    return Intl.message(
      'Datacenter',
      name: 'ipRiskDatacenter',
      desc: '',
      args: [],
    );
  }

  /// `Residential proxy`
  String get ipRiskResidentialProxy {
    return Intl.message(
      'Residential proxy',
      name: 'ipRiskResidentialProxy',
      desc: '',
      args: [],
    );
  }

  /// `Blacklist flags`
  String get ipRiskBlacklist {
    return Intl.message(
      'Blacklist flags',
      name: 'ipRiskBlacklist',
      desc: '',
      args: [],
    );
  }

  /// `Proxy type`
  String get ipRiskProxyType {
    return Intl.message(
      'Proxy type',
      name: 'ipRiskProxyType',
      desc: '',
      args: [],
    );
  }

  /// `Anonymizing VPN`
  String get ipRiskAnonymousVpn {
    return Intl.message(
      'Anonymizing VPN',
      name: 'ipRiskAnonymousVpn',
      desc: '',
      args: [],
    );
  }

  /// `Tor exit node`
  String get ipRiskTorExit {
    return Intl.message(
      'Tor exit node',
      name: 'ipRiskTorExit',
      desc: '',
      args: [],
    );
  }

  /// `Server`
  String get ipRiskServer {
    return Intl.message('Server', name: 'ipRiskServer', desc: '', args: []);
  }

  /// `Public proxy`
  String get ipRiskPublicProxy {
    return Intl.message(
      'Public proxy',
      name: 'ipRiskPublicProxy',
      desc: '',
      args: [],
    );
  }

  /// `Web proxy`
  String get ipRiskWebProxy {
    return Intl.message(
      'Web proxy',
      name: 'ipRiskWebProxy',
      desc: '',
      args: [],
    );
  }

  /// `Search engine robot`
  String get ipRiskSearchRobot {
    return Intl.message(
      'Search engine robot',
      name: 'ipRiskSearchRobot',
      desc: '',
      args: [],
    );
  }

  /// `Hostname`
  String get ipRiskHostname {
    return Intl.message('Hostname', name: 'ipRiskHostname', desc: '', args: []);
  }

  /// `Enter an IP to check`
  String get ipRiskHint {
    return Intl.message(
      'Enter an IP to check',
      name: 'ipRiskHint',
      desc: '',
      args: [],
    );
  }

  /// `Enter a valid public IP`
  String get ipRiskInvalid {
    return Intl.message(
      'Enter a valid public IP',
      name: 'ipRiskInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Source`
  String get ipRiskSource {
    return Intl.message('Source', name: 'ipRiskSource', desc: '', args: []);
  }

  /// `Premium Residential IP`
  String get ipRiskHomeBroadband {
    return Intl.message(
      'Premium Residential IP',
      name: 'ipRiskHomeBroadband',
      desc: '',
      args: [],
    );
  }

  /// `About the fraud score`
  String get ipRiskNoteTitle {
    return Intl.message(
      'About the fraud score',
      name: 'ipRiskNoteTitle',
      desc: '',
      args: [],
    );
  }

  /// `Scamalytics can see web traffic from this IP directly. The score of {score} reflects the share of that traffic suspected to be fraudulent.`
  String ipRiskNoteDirect(Object score) {
    return Intl.message(
      'Scamalytics can see web traffic from this IP directly. The score of $score reflects the share of that traffic suspected to be fraudulent.',
      name: 'ipRiskNoteDirect',
      desc: '',
      args: [score],
    );
  }

  /// `Scamalytics can't see web traffic from this IP directly. The score of {score} is estimated from the overall risk of IPs operated by {isp}.`
  String ipRiskNoteIndirect(Object score, Object isp) {
    return Intl.message(
      'Scamalytics can\'t see web traffic from this IP directly. The score of $score is estimated from the overall risk of IPs operated by $isp.',
      name: 'ipRiskNoteIndirect',
      desc: '',
      args: [score, isp],
    );
  }

  /// `The fraud score (0–100) reflects the share of web traffic from this IP that Scamalytics suspects to be fraudulent.`
  String get ipRiskNoteGeneric {
    return Intl.message(
      'The fraud score (0–100) reflects the share of web traffic from this IP that Scamalytics suspects to be fraudulent.',
      name: 'ipRiskNoteGeneric',
      desc: '',
      args: [],
    );
  }

  /// `Observed traffic`
  String get ipRiskNoteAmount {
    return Intl.message(
      'Observed traffic',
      name: 'ipRiskNoteAmount',
      desc: '',
      args: [],
    );
  }

  /// `Operator traffic`
  String get ipRiskNoteAmountIsp {
    return Intl.message(
      'Operator traffic',
      name: 'ipRiskNoteAmountIsp',
      desc: '',
      args: [],
    );
  }

  /// `Suspected fraud`
  String get ipRiskNoteShare {
    return Intl.message(
      'Suspected fraud',
      name: 'ipRiskNoteShare',
      desc: '',
      args: [],
    );
  }

  /// `Low`
  String get ipRiskAmountLow {
    return Intl.message('Low', name: 'ipRiskAmountLow', desc: '', args: []);
  }

  /// `Medium`
  String get ipRiskAmountMedium {
    return Intl.message(
      'Medium',
      name: 'ipRiskAmountMedium',
      desc: '',
      args: [],
    );
  }

  /// `High`
  String get ipRiskAmountHigh {
    return Intl.message('High', name: 'ipRiskAmountHigh', desc: '', args: []);
  }

  /// `Very little`
  String get ipRiskShareLittle {
    return Intl.message(
      'Very little',
      name: 'ipRiskShareLittle',
      desc: '',
      args: [],
    );
  }

  /// `Some`
  String get ipRiskShareSome {
    return Intl.message('Some', name: 'ipRiskShareSome', desc: '', args: []);
  }

  /// `Almost all`
  String get ipRiskShareAlmostAll {
    return Intl.message(
      'Almost all',
      name: 'ipRiskShareAlmostAll',
      desc: '',
      args: [],
    );
  }

  /// `Owner`
  String get ipRiskNoteOwner {
    return Intl.message('Owner', name: 'ipRiskNoteOwner', desc: '', args: []);
  }

  /// `Connection`
  String get ipRiskNoteConnection {
    return Intl.message(
      'Connection',
      name: 'ipRiskNoteConnection',
      desc: '',
      args: [],
    );
  }

  /// `Commercial server`
  String get ipRiskCommercialServer {
    return Intl.message(
      'Commercial server',
      name: 'ipRiskCommercialServer',
      desc: '',
      args: [],
    );
  }

  /// `May be relaying traffic from elsewhere; the actual user could be anywhere`
  String get ipRiskNoteProxying {
    return Intl.message(
      'May be relaying traffic from elsewhere; the actual user could be anywhere',
      name: 'ipRiskNoteProxying',
      desc: '',
      args: [],
    );
  }

  /// `Web traffic from this IP is likely to come from fraudsters.`
  String get ipRiskNoteWarningHigh {
    return Intl.message(
      'Web traffic from this IP is likely to come from fraudsters.',
      name: 'ipRiskNoteWarningHigh',
      desc: '',
      args: [],
    );
  }

  /// `Web traffic from this IP is very likely to come from fraudsters.`
  String get ipRiskNoteWarningVeryHigh {
    return Intl.message(
      'Web traffic from this IP is very likely to come from fraudsters.',
      name: 'ipRiskNoteWarningVeryHigh',
      desc: '',
      args: [],
    );
  }

  /// `This assessment covers web traffic only; other traffic may carry a different risk.`
  String get ipRiskNoteFootnote {
    return Intl.message(
      'This assessment covers web traffic only; other traffic may carry a different risk.',
      name: 'ipRiskNoteFootnote',
      desc: '',
      args: [],
    );
  }

  /// `Remaining`
  String get remainingTraffic {
    return Intl.message(
      'Remaining',
      name: 'remainingTraffic',
      desc: '',
      args: [],
    );
  }

  /// `{count, plural, one{{count} provider} other{{count} providers}}`
  String providersCount(num count) {
    return Intl.plural(
      count,
      one: '$count provider',
      other: '$count providers',
      name: 'providersCount',
      desc: '',
      args: [count],
    );
  }

  /// `Usage Style`
  String get usageStyle {
    return Intl.message('Usage Style', name: 'usageStyle', desc: '', args: []);
  }

  /// `Bars`
  String get usageStyleBar {
    return Intl.message('Bars', name: 'usageStyleBar', desc: '', args: []);
  }

  /// `Rings`
  String get usageStyleRing {
    return Intl.message('Rings', name: 'usageStyleRing', desc: '', args: []);
  }

  /// `Concentric Rings`
  String get usageStyleConcentric {
    return Intl.message(
      'Concentric Rings',
      name: 'usageStyleConcentric',
      desc: '',
      args: [],
    );
  }

  /// `Subscription merge`
  String get mergeProfile {
    return Intl.message(
      'Subscription merge',
      name: 'mergeProfile',
      desc: '',
      args: [],
    );
  }

  /// `Merge multiple subscriptions and manage routing in one place`
  String get mergeProfileDesc {
    return Intl.message(
      'Merge multiple subscriptions and manage routing in one place',
      name: 'mergeProfileDesc',
      desc: '',
      args: [],
    );
  }

  /// `At least two profiles are needed to merge`
  String get mergeProfileUnavailable {
    return Intl.message(
      'At least two profiles are needed to merge',
      name: 'mergeProfileUnavailable',
      desc: '',
      args: [],
    );
  }

  /// `Members`
  String get bundleMembers {
    return Intl.message('Members', name: 'bundleMembers', desc: '', args: []);
  }

  /// `Tap to change the node prefix, drag to reorder`
  String get bundleMembersDesc {
    return Intl.message(
      'Tap to change the node prefix, drag to reorder',
      name: 'bundleMembersDesc',
      desc: '',
      args: [],
    );
  }

  /// `Identical nodes are kept once, earlier members first`
  String get bundleDedupTip {
    return Intl.message(
      'Identical nodes are kept once, earlier members first',
      name: 'bundleDedupTip',
      desc: '',
      args: [],
    );
  }

  /// `Add members`
  String get addBundleMember {
    return Intl.message(
      'Add members',
      name: 'addBundleMember',
      desc: '',
      args: [],
    );
  }

  /// `Node prefix`
  String get nodePrefix {
    return Intl.message('Node prefix', name: 'nodePrefix', desc: '', args: []);
  }

  /// `Node prefix: {prefix}`
  String nodePrefixValue(Object prefix) {
    return Intl.message(
      'Node prefix: $prefix',
      name: 'nodePrefixValue',
      desc: '',
      args: [prefix],
    );
  }

  /// `No prefix`
  String get noNodePrefix {
    return Intl.message('No prefix', name: 'noNodePrefix', desc: '', args: []);
  }

  /// `Last generation failed: {message}`
  String bundleMemberFailed(Object message) {
    return Intl.message(
      'Last generation failed: $message',
      name: 'bundleMemberFailed',
      desc: '',
      args: [message],
    );
  }

  /// `Managed mode`
  String get managedMode {
    return Intl.message(
      'Managed mode',
      name: 'managedMode',
      desc: '',
      args: [],
    );
  }

  /// `Default options`
  String get managedOptions {
    return Intl.message(
      'Default options',
      name: 'managedOptions',
      desc: '',
      args: [],
    );
  }

  /// `{enabled} of {total} enabled`
  String managedOptionsDesc(Object enabled, Object total) {
    return Intl.message(
      '$enabled of $total enabled',
      name: 'managedOptionsDesc',
      desc: '',
      args: [enabled, total],
    );
  }

  /// `Restore built-in version`
  String get restoreBundled {
    return Intl.message(
      'Restore built-in version',
      name: 'restoreBundled',
      desc: '',
      args: [],
    );
  }

  /// `Last generated`
  String get lastGenerated {
    return Intl.message(
      'Last generated',
      name: 'lastGenerated',
      desc: '',
      args: [],
    );
  }

  /// `{proxies} nodes · {duplicates} duplicates removed · {time}`
  String bundleReportDesc(Object proxies, Object duplicates, Object time) {
    return Intl.message(
      '$proxies nodes · $duplicates duplicates removed · $time',
      name: 'bundleReportDesc',
      desc: '',
      args: [proxies, duplicates, time],
    );
  }

  /// `Regenerate`
  String get regenerate {
    return Intl.message('Regenerate', name: 'regenerate', desc: '', args: []);
  }

  /// `Generate`
  String get generate {
    return Intl.message('Generate', name: 'generate', desc: '', args: []);
  }

  /// `{count} profiles merged`
  String bundleSummary(Object count) {
    return Intl.message(
      '$count profiles merged',
      name: 'bundleSummary',
      desc: '',
      args: [count],
    );
  }

  /// `{count} nodes`
  String bundleProxies(Object count) {
    return Intl.message(
      '$count nodes',
      name: 'bundleProxies',
      desc: '',
      args: [count],
    );
  }

  /// `{count} failed`
  String bundleFailures(Object count) {
    return Intl.message(
      '$count failed',
      name: 'bundleFailures',
      desc: '',
      args: [count],
    );
  }

  /// `Merged`
  String get merged {
    return Intl.message('Merged', name: 'merged', desc: '', args: []);
  }

  /// `This profile is part of "{label}". Deleting it removes it from the merged subscription.`
  String deleteMemberTip(Object label) {
    return Intl.message(
      'This profile is part of "$label". Deleting it removes it from the merged subscription.',
      name: 'deleteMemberTip',
      desc: '',
      args: [label],
    );
  }

  /// `Add at least one member`
  String get bundleNoMembers {
    return Intl.message(
      'Add at least one member',
      name: 'bundleNoMembers',
      desc: '',
      args: [],
    );
  }

  /// `You can merge up to {count} subscriptions`
  String bundleMemberLimit(Object count) {
    return Intl.message(
      'You can merge up to $count subscriptions',
      name: 'bundleMemberLimit',
      desc: '',
      args: [count],
    );
  }

  /// `Merged subscription {index}`
  String mergedSubscriptionName(Object index) {
    return Intl.message(
      'Merged subscription $index',
      name: 'mergedSubscriptionName',
      desc: '',
      args: [index],
    );
  }

  /// `Subscription link`
  String get bundleAddUrl {
    return Intl.message(
      'Subscription link',
      name: 'bundleAddUrl',
      desc: '',
      args: [],
    );
  }

  /// `Import as a new subscription and add it`
  String get bundleAddUrlDesc {
    return Intl.message(
      'Import as a new subscription and add it',
      name: 'bundleAddUrlDesc',
      desc: '',
      args: [],
    );
  }

  /// `Pending import`
  String get bundlePendingImport {
    return Intl.message(
      'Pending import',
      name: 'bundlePendingImport',
      desc: '',
      args: [],
    );
  }

  /// `Collapse members`
  String get bundleCollapse {
    return Intl.message(
      'Collapse members',
      name: 'bundleCollapse',
      desc: '',
      args: [],
    );
  }

  /// `When enabled, only merged subscription info is shown in the list; tap the bottom-right corner of the card to expand or collapse`
  String get bundleCollapseDesc {
    return Intl.message(
      'When enabled, only merged subscription info is shown in the list; tap the bottom-right corner of the card to expand or collapse',
      name: 'bundleCollapseDesc',
      desc: '',
      args: [],
    );
  }

  /// `Expand`
  String get bundleExpand {
    return Intl.message('Expand', name: 'bundleExpand', desc: '', args: []);
  }

  /// `Generate proxy groups and rules with the built-in script`
  String get managedModeDesc {
    return Intl.message(
      'Generate proxy groups and rules with the built-in script',
      name: 'managedModeDesc',
      desc: '',
      args: [],
    );
  }

  /// `Disable QUIC has no effect with scripts enabled`
  String get disableQuicManagedDesc {
    return Intl.message(
      'Disable QUIC has no effect with scripts enabled',
      name: 'disableQuicManagedDesc',
      desc: '',
      args: [],
    );
  }

  /// `Manage routes`
  String get addRoute {
    return Intl.message('Manage routes', name: 'addRoute', desc: '', args: []);
  }

  /// `Edit route`
  String get editRoute {
    return Intl.message('Edit route', name: 'editRoute', desc: '', args: []);
  }

  /// `Rule sets`
  String get ruleSets {
    return Intl.message('Rule sets', name: 'ruleSets', desc: '', args: []);
  }

  /// `Add rule set`
  String get addRuleSet {
    return Intl.message('Add rule set', name: 'addRuleSet', desc: '', args: []);
  }

  /// `Search rule sets`
  String get searchRuleSets {
    return Intl.message(
      'Search rule sets',
      name: 'searchRuleSets',
      desc: '',
      args: [],
    );
  }

  /// `Default target`
  String get routeTarget {
    return Intl.message(
      'Default target',
      name: 'routeTarget',
      desc: '',
      args: [],
    );
  }

  /// `Block`
  String get reject {
    return Intl.message('Block', name: 'reject', desc: '', args: []);
  }

  /// `{count} rules`
  String ruleCount(Object count) {
    return Intl.message(
      '$count rules',
      name: 'ruleCount',
      desc: '',
      args: [count],
    );
  }

  /// `Large rule sets use more memory`
  String get largeRuleSetTip {
    return Intl.message(
      'Large rule sets use more memory',
      name: 'largeRuleSetTip',
      desc: '',
      args: [],
    );
  }

  /// `Select icon`
  String get selectIcon {
    return Intl.message('Select icon', name: 'selectIcon', desc: '', args: []);
  }

  /// `Search icons`
  String get searchIcons {
    return Intl.message(
      'Search icons',
      name: 'searchIcons',
      desc: '',
      args: [],
    );
  }

  /// `Icon URL`
  String get iconUrl {
    return Intl.message('Icon URL', name: 'iconUrl', desc: '', args: []);
  }

  /// `Please check that the URL is correct`
  String get checkUrlTip {
    return Intl.message(
      'Please check that the URL is correct',
      name: 'checkUrlTip',
      desc: '',
      args: [],
    );
  }

  /// `Name cannot contain commas or line breaks`
  String get routeNameInvalid {
    return Intl.message(
      'Name cannot contain commas or line breaks',
      name: 'routeNameInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Drag to reorder display; custom routes match first`
  String get groupOrderTip {
    return Intl.message(
      'Drag to reorder display; custom routes match first',
      name: 'groupOrderTip',
      desc: '',
      args: [],
    );
  }

  /// `Region groups`
  String get regionGroups {
    return Intl.message(
      'Region groups',
      name: 'regionGroups',
      desc: '',
      args: [],
    );
  }

  /// `Regions without matching nodes are skipped; nodes that match no region go to 其他节点 (other nodes)`
  String get regionGroupsTip {
    return Intl.message(
      'Regions without matching nodes are skipped; nodes that match no region go to 其他节点 (other nodes)',
      name: 'regionGroupsTip',
      desc: '',
      args: [],
    );
  }

  /// `Search services`
  String get searchServices {
    return Intl.message(
      'Search services',
      name: 'searchServices',
      desc: '',
      args: [],
    );
  }

  /// `Custom rule set URL`
  String get customRuleSetUrl {
    return Intl.message(
      'Custom rule set URL',
      name: 'customRuleSetUrl',
      desc: '',
      args: [],
    );
  }

  /// `Built-in`
  String get builtIn {
    return Intl.message('Built-in', name: 'builtIn', desc: '', args: []);
  }

  /// `Built-in mode`
  String get builtInManagedMode {
    return Intl.message(
      'Built-in mode',
      name: 'builtInManagedMode',
      desc: '',
      args: [],
    );
  }

  /// `Rule Order`
  String get ruleSort {
    return Intl.message('Rule Order', name: 'ruleSort', desc: '', args: []);
  }

  /// `{count} rules, included in the {group} group`
  String ruleCountIncluded(Object count, Object group) {
    return Intl.message(
      '$count rules, included in the $group group',
      name: 'ruleCountIncluded',
      desc: '',
      args: [count, group],
    );
  }

  /// `AI`
  String get routeCategoryAi {
    return Intl.message('AI', name: 'routeCategoryAi', desc: '', args: []);
  }

  /// `Streaming`
  String get routeCategoryStreaming {
    return Intl.message(
      'Streaming',
      name: 'routeCategoryStreaming',
      desc: '',
      args: [],
    );
  }

  /// `Social`
  String get routeCategorySocial {
    return Intl.message(
      'Social',
      name: 'routeCategorySocial',
      desc: '',
      args: [],
    );
  }

  /// `Gaming`
  String get routeCategoryGaming {
    return Intl.message(
      'Gaming',
      name: 'routeCategoryGaming',
      desc: '',
      args: [],
    );
  }

  /// `Developer`
  String get routeCategoryDeveloper {
    return Intl.message(
      'Developer',
      name: 'routeCategoryDeveloper',
      desc: '',
      args: [],
    );
  }

  /// `Finance`
  String get routeCategoryFinance {
    return Intl.message(
      'Finance',
      name: 'routeCategoryFinance',
      desc: '',
      args: [],
    );
  }

  /// `Tech`
  String get routeCategoryTech {
    return Intl.message('Tech', name: 'routeCategoryTech', desc: '', args: []);
  }

  /// `Current`
  String get inUse {
    return Intl.message('Current', name: 'inUse', desc: '', args: []);
  }

  /// `Add {count}`
  String routeAddCount(Object count) {
    return Intl.message(
      'Add $count',
      name: 'routeAddCount',
      desc: '',
      args: [count],
    );
  }

  /// `Remove {count}`
  String routeRemoveCount(Object count) {
    return Intl.message(
      'Remove $count',
      name: 'routeRemoveCount',
      desc: '',
      args: [count],
    );
  }

  /// `Icon Sets`
  String get iconSets {
    return Intl.message('Icon Sets', name: 'iconSets', desc: '', args: []);
  }

  /// `Not a valid icon set`
  String get invalidIconSet {
    return Intl.message(
      'Not a valid icon set',
      name: 'invalidIconSet',
      desc: '',
      args: [],
    );
  }

  /// `{count} icons`
  String iconCount(Object count) {
    return Intl.message(
      '$count icons',
      name: 'iconCount',
      desc: '',
      args: [count],
    );
  }

  /// `Lock Node`
  String get lockProxy {
    return Intl.message('Lock Node', name: 'lockProxy', desc: '', args: []);
  }

  /// `Unlock`
  String get unlockProxy {
    return Intl.message('Unlock', name: 'unlockProxy', desc: '', args: []);
  }

  /// `Add Region`
  String get addRegion {
    return Intl.message('Add Region', name: 'addRegion', desc: '', args: []);
  }

  /// `Region Name`
  String get regionName {
    return Intl.message('Region Name', name: 'regionName', desc: '', args: []);
  }

  /// `Matching Regex`
  String get regionRegex {
    return Intl.message(
      'Matching Regex',
      name: 'regionRegex',
      desc: '',
      args: [],
    );
  }

  /// `Invalid regular expression`
  String get regexInvalid {
    return Intl.message(
      'Invalid regular expression',
      name: 'regexInvalid',
      desc: '',
      args: [],
    );
  }

  /// `Icon Style`
  String get appIconStyle {
    return Intl.message('Icon Style', name: 'appIconStyle', desc: '', args: []);
  }

  /// `Customize application icon visual style`
  String get appIconStyleDesc {
    return Intl.message(
      'Customize application icon visual style',
      name: 'appIconStyleDesc',
      desc: '',
      args: [],
    );
  }

  /// `Cupertino`
  String get iconStyleCupertino {
    return Intl.message(
      'Cupertino',
      name: 'iconStyleCupertino',
      desc: '',
      args: [],
    );
  }

  /// `Apple iOS / SF Symbols visual style`
  String get iconStyleCupertinoDesc {
    return Intl.message(
      'Apple iOS / SF Symbols visual style',
      name: 'iconStyleCupertinoDesc',
      desc: '',
      args: [],
    );
  }

  /// `Material`
  String get iconStyleMaterial {
    return Intl.message(
      'Material',
      name: 'iconStyleMaterial',
      desc: '',
      args: [],
    );
  }

  /// `Google Material Design visual style`
  String get iconStyleMaterialDesc {
    return Intl.message(
      'Google Material Design visual style',
      name: 'iconStyleMaterialDesc',
      desc: '',
      args: [],
    );
  }

  /// `Phosphor`
  String get iconStylePhosphor {
    return Intl.message(
      'Phosphor',
      name: 'iconStylePhosphor',
      desc: '',
      args: [],
    );
  }

  /// `Modern geometric lightweight visual style`
  String get iconStylePhosphorDesc {
    return Intl.message(
      'Modern geometric lightweight visual style',
      name: 'iconStylePhosphorDesc',
      desc: '',
      args: [],
    );
  }

  /// `Apply to all managed profiles`
  String get applyToAllManaged {
    return Intl.message(
      'Apply to all managed profiles',
      name: 'applyToAllManaged',
      desc: '',
      args: [],
    );
  }

  /// `Add node`
  String get addNode {
    return Intl.message('Add node', name: 'addNode', desc: '', args: []);
  }

  /// `No nodes yet, add one first`
  String get nullNodeDesc {
    return Intl.message(
      'No nodes yet, add one first',
      name: 'nullNodeDesc',
      desc: '',
      args: [],
    );
  }

  /// `Share links, Base64 and YAML snippets are supported`
  String get nodeClipboardDesc {
    return Intl.message(
      'Share links, Base64 and YAML snippets are supported',
      name: 'nodeClipboardDesc',
      desc: '',
      args: [],
    );
  }

  /// `Scan a node share QR code`
  String get nodeQrcodeDesc {
    return Intl.message(
      'Scan a node share QR code',
      name: 'nodeQrcodeDesc',
      desc: '',
      args: [],
    );
  }

  /// `Read nodes from a file`
  String get nodeFileDesc {
    return Intl.message(
      'Read nodes from a file',
      name: 'nodeFileDesc',
      desc: '',
      args: [],
    );
  }

  /// `Manual input`
  String get manualInput {
    return Intl.message(
      'Manual input',
      name: 'manualInput',
      desc: '',
      args: [],
    );
  }

  /// `Share links, Base64 and YAML are supported`
  String get nodeManualDesc {
    return Intl.message(
      'Share links, Base64 and YAML are supported',
      name: 'nodeManualDesc',
      desc: '',
      args: [],
    );
  }

  /// `Register Cloudflare WARP`
  String get registerWarp {
    return Intl.message(
      'Register Cloudflare WARP',
      name: 'registerWarp',
      desc: '',
      args: [],
    );
  }

  /// `Create a WireGuard landing node`
  String get registerWarpDesc {
    return Intl.message(
      'Create a WireGuard landing node',
      name: 'registerWarpDesc',
      desc: '',
      args: [],
    );
  }

  /// `A new WARP device will be registered with Cloudflare. By continuing you agree to {terms}.`
  String registerWarpTip(Object terms) {
    return Intl.message(
      'A new WARP device will be registered with Cloudflare. By continuing you agree to $terms.',
      name: 'registerWarpTip',
      desc: '',
      args: [terms],
    );
  }

  /// `the Cloudflare Terms of Service`
  String get cloudflareTerms {
    return Intl.message(
      'the Cloudflare Terms of Service',
      name: 'cloudflareTerms',
      desc: '',
      args: [],
    );
  }

  /// `WARP registration failed`
  String get registerWarpFailed {
    return Intl.message(
      'WARP registration failed',
      name: 'registerWarpFailed',
      desc: '',
      args: [],
    );
  }

  /// `No valid nodes found`
  String get nodeImportEmpty {
    return Intl.message(
      'No valid nodes found',
      name: 'nodeImportEmpty',
      desc: '',
      args: [],
    );
  }

  /// `Skipped {count} invalid nodes`
  String nodeImportSkipped(Object count) {
    return Intl.message(
      'Skipped $count invalid nodes',
      name: 'nodeImportSkipped',
      desc: '',
      args: [count],
    );
  }

  /// `Add from the clipboard, a QR code, a file or manual input, or register WARP`
  String get addNodeDesc {
    return Intl.message(
      'Add from the clipboard, a QR code, a file or manual input, or register WARP',
      name: 'addNodeDesc',
      desc: '',
      args: [],
    );
  }

  /// `Front proxy`
  String get frontProxy {
    return Intl.message('Front proxy', name: 'frontProxy', desc: '', args: []);
  }

  /// `The current front node does not support UDP. Please check the configuration.`
  String get frontUdpUnsupported {
    return Intl.message(
      'The current front node does not support UDP. Please check the configuration.',
      name: 'frontUdpUnsupported',
      desc: '',
      args: [],
    );
  }

  /// `Front {name} is missing, connecting directly`
  String frontMissing(Object name) {
    return Intl.message(
      'Front $name is missing, connecting directly',
      name: 'frontMissing',
      desc: '',
      args: [name],
    );
  }

  /// `Landing node`
  String get landingNode {
    return Intl.message(
      'Landing node',
      name: 'landingNode',
      desc: '',
      args: [],
    );
  }

  /// `Regular node`
  String get regularNode {
    return Intl.message(
      'Regular node',
      name: 'regularNode',
      desc: '',
      args: [],
    );
  }

  /// `Add to proxy groups`
  String get joinGroups {
    return Intl.message(
      'Add to proxy groups',
      name: 'joinGroups',
      desc: '',
      args: [],
    );
  }

  /// `When the region group does not exist, the node is used as a regular node.`
  String get managedNodeTip {
    return Intl.message(
      'When the region group does not exist, the node is used as a regular node.',
      name: 'managedNodeTip',
      desc: '',
      args: [],
    );
  }

  /// `Inject into this profile`
  String get injectNode {
    return Intl.message(
      'Inject into this profile',
      name: 'injectNode',
      desc: '',
      args: [],
    );
  }

  /// `Only applies to the current profile in non-managed mode`
  String get injectNodeDesc {
    return Intl.message(
      'Only applies to the current profile in non-managed mode',
      name: 'injectNodeDesc',
      desc: '',
      args: [],
    );
  }

  /// `Proxy groups become selectable after the current profile is loaded`
  String get injectNodeEmpty {
    return Intl.message(
      'Proxy groups become selectable after the current profile is loaded',
      name: 'injectNodeEmpty',
      desc: '',
      args: [],
    );
  }

  /// `Node role`
  String get nodeRole {
    return Intl.message('Node role', name: 'nodeRole', desc: '', args: []);
  }

  /// `Connects through the chosen front proxy and joins the selected proxy groups`
  String get landingNodeDesc {
    return Intl.message(
      'Connects through the chosen front proxy and joins the selected proxy groups',
      name: 'landingNodeDesc',
      desc: '',
      args: [],
    );
  }

  /// `Connects directly and joins the selected proxy groups`
  String get regularNodeDesc {
    return Intl.message(
      'Connects directly and joins the selected proxy groups',
      name: 'regularNodeDesc',
      desc: '',
      args: [],
    );
  }

  /// `Apply to managed profiles`
  String get applyManaged {
    return Intl.message(
      'Apply to managed profiles',
      name: 'applyManaged',
      desc: '',
      args: [],
    );
  }

  /// `Applies to all profiles in managed mode at the same time`
  String get applyManagedDesc {
    return Intl.message(
      'Applies to all profiles in managed mode at the same time',
      name: 'applyManagedDesc',
      desc: '',
      args: [],
    );
  }

  /// `Node Sorting`
  String get nodesSort {
    return Intl.message('Node Sorting', name: 'nodesSort', desc: '', args: []);
  }

  /// `Choose a node or group`
  String get chooseFront {
    return Intl.message(
      'Choose a node or group',
      name: 'chooseFront',
      desc: '',
      args: [],
    );
  }

  /// `Connectivity test`
  String get connectivityTest {
    return Intl.message(
      'Connectivity test',
      name: 'connectivityTest',
      desc: '',
      args: [],
    );
  }

  /// `Check whether this node's route is working`
  String get connectivityTestDesc {
    return Intl.message(
      'Check whether this node\'s route is working',
      name: 'connectivityTestDesc',
      desc: '',
      args: [],
    );
  }

  /// `Unreachable`
  String get nodeTestFailed {
    return Intl.message(
      'Unreachable',
      name: 'nodeTestFailed',
      desc: '',
      args: [],
    );
  }

  /// `Select`
  String get pick {
    return Intl.message('Select', name: 'pick', desc: '', args: []);
  }

  /// `Always On`
  String get findProcessAlways {
    return Intl.message(
      'Always On',
      name: 'findProcessAlways',
      desc: '',
      args: [],
    );
  }

  /// `Always on, so connections can show app icons`
  String get findProcessAlwaysDesc {
    return Intl.message(
      'Always on, so connections can show app icons',
      name: 'findProcessAlwaysDesc',
      desc: '',
      args: [],
    );
  }

  /// `On Demand`
  String get findProcessStrict {
    return Intl.message(
      'On Demand',
      name: 'findProcessStrict',
      desc: '',
      args: [],
    );
  }

  /// `Only on when process rules exist, smarter`
  String get findProcessStrictDesc {
    return Intl.message(
      'Only on when process rules exist, smarter',
      name: 'findProcessStrictDesc',
      desc: '',
      args: [],
    );
  }

  /// `Off`
  String get findProcessOff {
    return Intl.message('Off', name: 'findProcessOff', desc: '', args: []);
  }

  /// `Process rules no longer apply, more efficient`
  String get findProcessOffDesc {
    return Intl.message(
      'Process rules no longer apply, more efficient',
      name: 'findProcessOffDesc',
      desc: '',
      args: [],
    );
  }

  /// `External Controller Port`
  String get externalControllerPort {
    return Intl.message(
      'External Controller Port',
      name: 'externalControllerPort',
      desc: '',
      args: [],
    );
  }

  /// `App is not installed`
  String get appNotInstalled {
    return Intl.message(
      'App is not installed',
      name: 'appNotInstalled',
      desc: '',
      args: [],
    );
  }

  /// `File no longer exists`
  String get fileNotFound {
    return Intl.message(
      'File no longer exists',
      name: 'fileNotFound',
      desc: '',
      args: [],
    );
  }

  /// `IP`
  String get ip {
    return Intl.message('IP', name: 'ip', desc: '', args: []);
  }

  /// `{type, select, DOMAIN_SUFFIX {Domain suffix} DOMAIN {Full domain} DOMAIN_KEYWORD {Domain keyword} DOMAIN_WILDCARD {Domain wildcard} DOMAIN_REGEX {Domain regex} GEOSITE {GeoSite} IP_CIDR {IP range} IP_SUFFIX {IP suffix} IP_ASN {IP ASN} GEOIP {GeoIP} SRC_IP_CIDR {Source IP range} SRC_IP_SUFFIX {Source IP suffix} SRC_IP_ASN {Source IP ASN} SRC_GEOIP {Source GeoIP} PROCESS_NAME {Process name} PROCESS_NAME_WILDCARD {Process name wildcard} PROCESS_NAME_REGEX {Process name regex} PROCESS_PATH {Process path} PROCESS_PATH_WILDCARD {Process path wildcard} PROCESS_PATH_REGEX {Process path regex} UID {User ID} DST_PORT {Destination port} SRC_PORT {Source port} NETWORK {Network type} IN_PORT {Inbound port} IN_TYPE {Inbound type} IN_NAME {Inbound name} IN_USER {Inbound user} DSCP {DSCP} RULE_SET {Rule set} AND {Logical AND} OR {Logical OR} NOT {Logical NOT} SUB_RULE {Sub rule} MATCH {Match all} other {{type}}}`
  String ruleTypeName(Object type) {
    return Intl.select(
      type,
      {
        'DOMAIN_SUFFIX': 'Domain suffix',
        'DOMAIN': 'Full domain',
        'DOMAIN_KEYWORD': 'Domain keyword',
        'DOMAIN_WILDCARD': 'Domain wildcard',
        'DOMAIN_REGEX': 'Domain regex',
        'GEOSITE': 'GeoSite',
        'IP_CIDR': 'IP range',
        'IP_SUFFIX': 'IP suffix',
        'IP_ASN': 'IP ASN',
        'GEOIP': 'GeoIP',
        'SRC_IP_CIDR': 'Source IP range',
        'SRC_IP_SUFFIX': 'Source IP suffix',
        'SRC_IP_ASN': 'Source IP ASN',
        'SRC_GEOIP': 'Source GeoIP',
        'PROCESS_NAME': 'Process name',
        'PROCESS_NAME_WILDCARD': 'Process name wildcard',
        'PROCESS_NAME_REGEX': 'Process name regex',
        'PROCESS_PATH': 'Process path',
        'PROCESS_PATH_WILDCARD': 'Process path wildcard',
        'PROCESS_PATH_REGEX': 'Process path regex',
        'UID': 'User ID',
        'DST_PORT': 'Destination port',
        'SRC_PORT': 'Source port',
        'NETWORK': 'Network type',
        'IN_PORT': 'Inbound port',
        'IN_TYPE': 'Inbound type',
        'IN_NAME': 'Inbound name',
        'IN_USER': 'Inbound user',
        'DSCP': 'DSCP',
        'RULE_SET': 'Rule set',
        'AND': 'Logical AND',
        'OR': 'Logical OR',
        'NOT': 'Logical NOT',
        'SUB_RULE': 'Sub rule',
        'MATCH': 'Match all',
        'other': '$type',
      },
      name: 'ruleTypeName',
      desc: '',
      args: [type],
    );
  }

  /// `{type, select, DOMAIN_SUFFIX {Matches the domain and all its subdomains, e.g. google.com also matches www.google.com} DOMAIN {Matches only this exact domain, e.g. google.com does not match www.google.com} DOMAIN_KEYWORD {Matches any domain that contains the keyword, e.g. google} DOMAIN_WILDCARD {Matches domains by wildcard: * for any characters, ? for one character, e.g. *.google.com} DOMAIN_REGEX {Matches domains with a regular expression} GEOSITE {Matches domains in a GeoSite category, e.g. google or cn} IP_CIDR {Matches destination IPs in a range, e.g. 192.168.1.0/24; a single IP uses /32, or /128 for IPv6} IP_SUFFIX {Matches IPs whose last bits are the same, e.g. 8.8.8.8/24 compares the last 24 bits} IP_ASN {Matches the autonomous system number of the destination IP, e.g. 13335} GEOIP {Matches the country or region code of the destination IP, e.g. CN} SRC_IP_CIDR {Matches the source IP of the connection by range, e.g. 192.168.1.0/24} SRC_IP_SUFFIX {Matches source IPs whose last bits are the same} SRC_IP_ASN {Matches the autonomous system number of the source IP} SRC_GEOIP {Matches the country or region code of the source IP} PROCESS_NAME {Matches the process name; on Android this is the app package name} PROCESS_NAME_WILDCARD {Matches process names by wildcard: * for any characters, ? for one character} PROCESS_NAME_REGEX {Matches process names with a regular expression} PROCESS_PATH {Matches the full path of the process executable} PROCESS_PATH_WILDCARD {Matches process paths by wildcard: * for any characters, ? for one character} PROCESS_PATH_REGEX {Matches process paths with a regular expression} UID {Matches the Linux user ID of the process; ranges allowed, e.g. 1000-1999} DST_PORT {Matches the destination port; separate with / and use - for ranges, e.g. 80/443/8000-9000} SRC_PORT {Matches the source port; separate with / and use - for ranges} NETWORK {Matches the transport protocol: tcp or udp} IN_PORT {Matches the local inbound listening port} IN_TYPE {Matches the inbound type, e.g. HTTP, SOCKS5 or TUN; separate multiple with /} IN_NAME {Matches the inbound listener name; separate multiple with /} IN_USER {Matches the username used to sign in to the inbound; separate multiple with /} DSCP {Matches the DSCP mark in the IP header, from 0 to 63} RULE_SET {Matches the content of a rule provider} AND {Matches when every sub-rule matches, e.g. ((DOMAIN,baidu.com),(NETWORK,UDP))} OR {Matches when any sub-rule matches, e.g. ((NETWORK,UDP),(DST-PORT,443))} NOT {Matches when the sub-rule does not match, e.g. ((DOMAIN,baidu.com))} SUB_RULE {When the condition matches, continues with the chosen sub rule set, e.g. (NETWORK,TCP)} MATCH {Matches all traffic; rules after it never take effect} other {{type}}}`
  String ruleTypeDesc(Object type) {
    return Intl.select(
      type,
      {
        'DOMAIN_SUFFIX': 'Matches the domain and all its subdomains, e.g. google.com also matches www.google.com',
        'DOMAIN': 'Matches only this exact domain, e.g. google.com does not match www.google.com',
        'DOMAIN_KEYWORD':
            'Matches any domain that contains the keyword, e.g. google',
        'DOMAIN_WILDCARD': 'Matches domains by wildcard: * for any characters, ? for one character, e.g. *.google.com',
        'DOMAIN_REGEX': 'Matches domains with a regular expression',
        'GEOSITE': 'Matches domains in a GeoSite category, e.g. google or cn',
        'IP_CIDR': 'Matches destination IPs in a range, e.g. 192.168.1.0/24; a single IP uses /32, or /128 for IPv6',
        'IP_SUFFIX': 'Matches IPs whose last bits are the same, e.g. 8.8.8.8/24 compares the last 24 bits',
        'IP_ASN': 'Matches the autonomous system number of the destination IP, e.g. 13335',
        'GEOIP':
            'Matches the country or region code of the destination IP, e.g. CN',
        'SRC_IP_CIDR': 'Matches the source IP of the connection by range, e.g. 192.168.1.0/24',
        'SRC_IP_SUFFIX': 'Matches source IPs whose last bits are the same',
        'SRC_IP_ASN': 'Matches the autonomous system number of the source IP',
        'SRC_GEOIP': 'Matches the country or region code of the source IP',
        'PROCESS_NAME':
            'Matches the process name; on Android this is the app package name',
        'PROCESS_NAME_WILDCARD': 'Matches process names by wildcard: * for any characters, ? for one character',
        'PROCESS_NAME_REGEX': 'Matches process names with a regular expression',
        'PROCESS_PATH': 'Matches the full path of the process executable',
        'PROCESS_PATH_WILDCARD': 'Matches process paths by wildcard: * for any characters, ? for one character',
        'PROCESS_PATH_REGEX': 'Matches process paths with a regular expression',
        'UID': 'Matches the Linux user ID of the process; ranges allowed, e.g. 1000-1999',
        'DST_PORT': 'Matches the destination port; separate with / and use - for ranges, e.g. 80/443/8000-9000',
        'SRC_PORT':
            'Matches the source port; separate with / and use - for ranges',
        'NETWORK': 'Matches the transport protocol: tcp or udp',
        'IN_PORT': 'Matches the local inbound listening port',
        'IN_TYPE': 'Matches the inbound type, e.g. HTTP, SOCKS5 or TUN; separate multiple with /',
        'IN_NAME':
            'Matches the inbound listener name; separate multiple with /',
        'IN_USER': 'Matches the username used to sign in to the inbound; separate multiple with /',
        'DSCP': 'Matches the DSCP mark in the IP header, from 0 to 63',
        'RULE_SET': 'Matches the content of a rule provider',
        'AND': 'Matches when every sub-rule matches, e.g. ((DOMAIN,baidu.com),(NETWORK,UDP))',
        'OR': 'Matches when any sub-rule matches, e.g. ((NETWORK,UDP),(DST-PORT,443))',
        'NOT': 'Matches when the sub-rule does not match, e.g. ((DOMAIN,baidu.com))',
        'SUB_RULE': 'When the condition matches, continues with the chosen sub rule set, e.g. (NETWORK,TCP)',
        'MATCH': 'Matches all traffic; rules after it never take effect',
        'other': '$type',
      },
      name: 'ruleTypeDesc',
      desc: '',
      args: [type],
    );
  }

  /// `Not in managed mode, so this rule only applies to the current profile`
  String get nonManagedRuleTip {
    return Intl.message(
      'Not in managed mode, so this rule only applies to the current profile',
      name: 'nonManagedRuleTip',
      desc: '',
      args: [],
    );
  }

  /// `Rule added`
  String get ruleAdded {
    return Intl.message('Rule added', name: 'ruleAdded', desc: '', args: []);
  }

  /// `When on, the rule applies to all managed profiles. When off, or in non-managed mode, it only applies to the current profile`
  String get applyToAllManagedDesc {
    return Intl.message(
      'When on, the rule applies to all managed profiles. When off, or in non-managed mode, it only applies to the current profile',
      name: 'applyToAllManagedDesc',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<AppLocalizations> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'fa'),
      Locale.fromSubtags(languageCode: 'ja'),
      Locale.fromSubtags(languageCode: 'ko'),
      Locale.fromSubtags(languageCode: 'ru'),
      Locale.fromSubtags(languageCode: 'zh', countryCode: 'CN'),
      Locale.fromSubtags(languageCode: 'zh', countryCode: 'TC'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<AppLocalizations> load(Locale locale) => AppLocalizations.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}

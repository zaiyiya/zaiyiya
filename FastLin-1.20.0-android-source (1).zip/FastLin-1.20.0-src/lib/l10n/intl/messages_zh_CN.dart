// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a zh_CN locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'zh_CN';

  static String m0(log) => "分析FastLin(Mihomo)日志:${log}";

  static String m1(error) => "自动备份失败：${error}";

  static String m2(count) => "${count} 个失败";

  static String m3(message) => "上次生成失败：${message}";

  static String m4(count) => "最多合并 ${count} 个订阅";

  static String m5(count) => "${count} 个节点";

  static String m6(proxies, duplicates, time) =>
      "${proxies} 个节点 · 去重 ${duplicates} 个 · ${time}";

  static String m7(count) => "合并 ${count} 个配置";

  static String m8(value) => "均值 ${value}";

  static String m9(count) => "${Intl.plural(count, other: '天')}";

  static String m10(label) => "该配置已合并到「${label}」，删除后会从合并订阅中移除。";

  static String m11(label) => "确定删除选中的${label}吗？";

  static String m12(label) => "确定删除当前${label}吗？";

  static String m13(reason) => "Fake-IP · ${reason}：将返回真实 IP";

  static String m14(reason, range) => "Fake-IP · ${reason}：将返回 ${range} 段虚拟地址";

  static String m15(ips) => "命中 Hosts：将返回 ${ips}";

  static String m16(outbound) => "最终走「${outbound}」出口，由节点解析域名";

  static String m17(outbound) => "最终走「${outbound}」出口，由节点解析域名，Hosts 不生效";

  static String m18(label) => "${label}不能为空";

  static String m19(label) => "${label}当前已存在";

  static String m20(name) => "前置 ${name} 不存在，已直连";

  static String m21(count) => "${Intl.plural(count, other: '${count} 次')}";

  static String m22(count) => "${Intl.plural(count, other: '小时')}";

  static String m23(count) => "${count} 个图标";

  static String m24(inbound, user) => "${inbound}（用户 ${user}）";

  static String m25(score) =>
      "Scamalytics 能直接观测到该 IP 的网页流量，欺诈值 ${score} 代表其中疑似欺诈流量所占的比例。";

  static String m26(score, isp) =>
      "Scamalytics 无法直接观测该 IP 的网页流量，欺诈值 ${score} 是依据 ${isp} 旗下 IP 的整体风险估算的。";

  static String m27(port) => "端口 ${port} 已被占用，请换一个端口";

  static String m28(code) => "服务器拒绝了本次测试（错误码 ${code}）";

  static String m29(lost, total) => "${lost}/${total} 个包";

  static String m30(name) => "已扫码：${name}";

  static String m31(value) => "${value} 秒";

  static String m32(port) => "正在监听端口 ${port}";

  static String m33(count) => "${count} 条流";

  static String m34(count) => "${count}";

  static String m35(count) => "${count} 字节";

  static String m36(address) => "来自 ${address}";

  static String m37(count) => "仅显示最近 ${count} 条，复制结果可查看全部";

  static String m38(min, avg, max, jitter) =>
      "往返时间：最短 ${min} / 平均 ${avg} / 最长 ${max} / 抖动 ${jitter} ms";

  static String m39(target) => "${target} 的 Ping 统计";

  static String m40(sent, received, lost, loss) =>
      "已发送 ${sent}，已接收 ${received}，丢失 ${lost}（${loss}% 丢失）";

  static String m41(level) => "${level}模式适合网络调试，日常使用建议关闭";

  static String m42(enabled, total) => "已开启 ${enabled} / ${total} 项";

  static String m43(done, total, unlocked) =>
      "已检测 ${done}/${total} · 可用 ${unlocked}";

  static String m44(size) => "已释放 ${size}";

  static String m45(index) => "合并订阅${index}";

  static String m46(count) => "${Intl.plural(count, other: '分钟')}";

  static String m47(count) => "${Intl.plural(count, other: '月')}";

  static String m48(count) => "${count} 条";

  static String m49(ip) => "经 ${ip} 匹配";

  static String m50(count) => "${count} 条新日志";

  static String m51(count) => "已跳过 ${count} 个无效节点";

  static String m52(prefix) => "节点前缀：${prefix}";

  static String m53(label) => "暂无${label}";

  static String m54(min, max) => "请输入 ${min}–${max} 之间的整数";

  static String m55(label) => "${label}必须为数字";

  static String m56(label) => "只看 ${label}";

  static String m57(label) => "${label} 必须在 1024 到 49151 之间，0 为关闭";

  static String m58(statusCode) =>
      "配置导入失败，请检查网络状况或尝试重置订阅链接( HTTP错误代码: ${statusCode} )";

  static String m59(count) => "${count} 个提供者";

  static String m60(terms) => "将向 Cloudflare 注册一个新的 WARP 设备，继续即表示你同意${terms}。";

  static String m61(count) => "添加 ${count} 项";

  static String m62(count) => "移除 ${count} 项";

  static String m63(index, time) => "第 ${index} 条规则触发解析 · ${time} ms";

  static String m64(ips) => "命中 Hosts：${ips}";

  static String m65(total, index) => "共 ${total} 条规则，命中第 ${index} 条";

  static String m66(total) => "共 ${total} 条规则";

  static String m67(count) => "${count} 条规则";

  static String m68(count, group) => "${count} 条规则，已包含在 ${group} 策略组";

  static String m69(type) =>
      "${Intl.select(type, {'DOMAIN_SUFFIX': '匹配该域名及其所有子域名，如 google.com 也匹配 www.google.com', 'DOMAIN': '仅匹配完全相同的域名，如 google.com 不匹配 www.google.com', 'DOMAIN_KEYWORD': '域名中包含该关键字即匹配，如 google', 'DOMAIN_WILDCARD': '用通配符匹配域名，* 匹配任意字符，? 匹配单个字符，如 *.google.com', 'DOMAIN_REGEX': '用正则表达式匹配域名', 'GEOSITE': '匹配 GeoSite 数据库中的域名分类，如 google、cn', 'IP_CIDR': '匹配目标 IP 所在网段，如 192.168.1.0/24；单个 IP 用 /32，IPv6 用 /128', 'IP_SUFFIX': '匹配末尾若干位相同的 IP，如 8.8.8.8/24 比较末尾 24 位', 'IP_ASN': '匹配目标 IP 所属的自治系统编号，如 13335', 'GEOIP': '匹配目标 IP 所属的国家或地区代码，如 CN', 'SRC_IP_CIDR': '匹配连接来源 IP 所在网段，如 192.168.1.0/24', 'SRC_IP_SUFFIX': '匹配末尾若干位相同的来源 IP', 'SRC_IP_ASN': '匹配来源 IP 所属的自治系统编号', 'SRC_GEOIP': '匹配来源 IP 所属的国家或地区代码', 'PROCESS_NAME': '按进程名匹配，Android 上为应用包名', 'PROCESS_NAME_WILDCARD': '用通配符匹配进程名，* 匹配任意字符，? 匹配单个字符', 'PROCESS_NAME_REGEX': '用正则表达式匹配进程名', 'PROCESS_PATH': '按进程可执行文件的完整路径匹配', 'PROCESS_PATH_WILDCARD': '用通配符匹配进程路径，* 匹配任意字符，? 匹配单个字符', 'PROCESS_PATH_REGEX': '用正则表达式匹配进程路径', 'UID': '按进程的 Linux 用户 ID 匹配，可填范围，如 1000-1999', 'DST_PORT': '匹配目标端口，多个用 / 分隔，范围用 -，如 80/443/8000-9000', 'SRC_PORT': '匹配来源端口，多个用 / 分隔，范围用 -', 'NETWORK': '匹配传输协议，填 tcp 或 udp', 'IN_PORT': '匹配本机入站监听端口', 'IN_TYPE': '匹配入站类型，如 HTTP、SOCKS5、TUN，多个用 / 分隔', 'IN_NAME': '匹配入站监听器名称，多个用 / 分隔', 'IN_USER': '匹配入站认证使用的用户名，多个用 / 分隔', 'DSCP': '匹配 IP 包头中的 DSCP 标记，范围 0 到 63', 'RULE_SET': '匹配规则提供者中的内容', 'AND': '所有子规则都满足时匹配，如 ((DOMAIN,baidu.com),(NETWORK,UDP))', 'OR': '任一子规则满足时匹配，如 ((NETWORK,UDP),(DST-PORT,443))', 'NOT': '子规则不满足时匹配，如 ((DOMAIN,baidu.com))', 'SUB_RULE': '条件满足时转入所选子规则继续匹配，如 (NETWORK,TCP)', 'MATCH': '匹配所有流量，其后的规则将不再生效', 'other': '${type}'})}";

  static String m70(type) =>
      "${Intl.select(type, {'DOMAIN_SUFFIX': '域名后缀', 'DOMAIN': '完整域名', 'DOMAIN_KEYWORD': '域名关键字', 'DOMAIN_WILDCARD': '域名通配符', 'DOMAIN_REGEX': '域名正则', 'GEOSITE': 'GeoSite', 'IP_CIDR': 'IP 段', 'IP_SUFFIX': 'IP 后缀', 'IP_ASN': 'IP ASN', 'GEOIP': 'GeoIP', 'SRC_IP_CIDR': '源 IP 段', 'SRC_IP_SUFFIX': '源 IP 后缀', 'SRC_IP_ASN': '源 IP ASN', 'SRC_GEOIP': '源 GeoIP', 'PROCESS_NAME': '进程名', 'PROCESS_NAME_WILDCARD': '进程名通配符', 'PROCESS_NAME_REGEX': '进程名正则', 'PROCESS_PATH': '进程路径', 'PROCESS_PATH_WILDCARD': '进程路径通配符', 'PROCESS_PATH_REGEX': '进程路径正则', 'UID': '用户 ID', 'DST_PORT': '目标端口', 'SRC_PORT': '源端口', 'NETWORK': '网络类型', 'IN_PORT': '入站端口', 'IN_TYPE': '入站类型', 'IN_NAME': '入站名称', 'IN_USER': '入站用户', 'DSCP': 'DSCP', 'RULE_SET': '规则集', 'AND': '逻辑与', 'OR': '逻辑或', 'NOT': '逻辑非', 'SUB_RULE': '子规则', 'MATCH': '全部匹配', 'other': '${type}'})}";

  static String m71(count) => "已选择 ${count} 项";

  static String m72(count) => "多线程会并发 ${count} 条连接以跑满带宽";

  static String m73(provider) => "出站节点可能屏蔽了 ${provider} 测速，可切换测速源或更换出站";

  static String m74(protocol, fallback) => "${protocol} 不可用，已回退到 ${fallback}";

  static String m75(count) => "${count} 条连接";

  static String m76(provider) => "切换到 ${provider}";

  static String m77(appName) =>
      "新版本安装包已下载就绪，为保障服务正常，升级前将会主动关闭正在运行中的 ${appName}，点击确认后开始安装";

  static String m78(label) => "${label}必须为URL";

  static String m79(count) => "${Intl.plural(count, other: '年')}";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "about": MessageLookupByLibrary.simpleMessage("关于"),
    "accessControl": MessageLookupByLibrary.simpleMessage("分应用代理"),
    "accessControlAllowDesc": MessageLookupByLibrary.simpleMessage(
      "只允许选中的应用进入 VPN",
    ),
    "accessControlDesc": MessageLookupByLibrary.simpleMessage("配置应用访问黑白名单"),
    "accessControlNotAllowDesc": MessageLookupByLibrary.simpleMessage(
      "选中的应用将被排除在 VPN 之外",
    ),
    "account": MessageLookupByLibrary.simpleMessage("账号"),
    "action": MessageLookupByLibrary.simpleMessage("操作"),
    "action_mode": MessageLookupByLibrary.simpleMessage("切换模式"),
    "action_proxy": MessageLookupByLibrary.simpleMessage("系统代理"),
    "action_start": MessageLookupByLibrary.simpleMessage("启动/停止"),
    "action_tun": MessageLookupByLibrary.simpleMessage("虚拟网卡"),
    "action_view": MessageLookupByLibrary.simpleMessage("显示/隐藏"),
    "activeGoroutines": MessageLookupByLibrary.simpleMessage("协程数"),
    "add": MessageLookupByLibrary.simpleMessage("添加"),
    "addBundleMember": MessageLookupByLibrary.simpleMessage("添加成员"),
    "addNode": MessageLookupByLibrary.simpleMessage("添加节点"),
    "addNodeDesc": MessageLookupByLibrary.simpleMessage(
      "从剪贴板、二维码、文件或手动输入添加，也可注册 WARP",
    ),
    "addProfile": MessageLookupByLibrary.simpleMessage("添加配置"),
    "addRegion": MessageLookupByLibrary.simpleMessage("添加地区"),
    "addRoute": MessageLookupByLibrary.simpleMessage("分流管理"),
    "addRule": MessageLookupByLibrary.simpleMessage("添加规则"),
    "addRuleSet": MessageLookupByLibrary.simpleMessage("添加规则集"),
    "addTunnel": MessageLookupByLibrary.simpleMessage("添加转发"),
    "addUser": MessageLookupByLibrary.simpleMessage("添加用户"),
    "addedOriginRules": MessageLookupByLibrary.simpleMessage("附加到原始规则"),
    "address": MessageLookupByLibrary.simpleMessage("地址"),
    "addressHelp": MessageLookupByLibrary.simpleMessage("WebDAV 服务器地址"),
    "addressTip": MessageLookupByLibrary.simpleMessage("请输入有效的 WebDAV 地址"),
    "adminAutoLaunch": MessageLookupByLibrary.simpleMessage("管理员自启动"),
    "adminAutoLaunchDesc": MessageLookupByLibrary.simpleMessage("使用管理员模式开机自启动"),
    "advancedSettings": MessageLookupByLibrary.simpleMessage("进阶设置"),
    "ageCipherText": MessageLookupByLibrary.simpleMessage(
      "密文（-----BEGIN AGE ENCRYPTED FILE-----）",
    ),
    "ageDecryptFailed": MessageLookupByLibrary.simpleMessage("解密失败"),
    "ageEncryptFailed": MessageLookupByLibrary.simpleMessage("加密失败"),
    "ageFileTooLarge": MessageLookupByLibrary.simpleMessage("文件过大（上限 8 MB）"),
    "ageGenerateKeyPair": MessageLookupByLibrary.simpleMessage("生成新密钥对"),
    "ageInputRequired": MessageLookupByLibrary.simpleMessage("请输入内容或选择文件"),
    "ageKeyGenerateTitle": MessageLookupByLibrary.simpleMessage("Age Key 工具"),
    "ageKeyHybridTip": MessageLookupByLibrary.simpleMessage(
      "后量子混合密钥，安全性更强，但公钥较长，需要 age v1.3 及以上版本支持。",
    ),
    "ageKeyPairGeneratedSuccess": MessageLookupByLibrary.simpleMessage(
      "已生成 X25519 密钥对，请妥善保存",
    ),
    "ageKeyType": MessageLookupByLibrary.simpleMessage("密钥类型"),
    "ageNotEncrypted": MessageLookupByLibrary.simpleMessage("内容不是 Age 加密格式"),
    "ageOutput": MessageLookupByLibrary.simpleMessage("结果"),
    "agePlainText": MessageLookupByLibrary.simpleMessage("明文"),
    "agePrivateKeyLabel": MessageLookupByLibrary.simpleMessage("Age 私钥"),
    "agePrivateKeyRequired": MessageLookupByLibrary.simpleMessage(
      "请先输入正确的 Age 私钥",
    ),
    "agePublicKeyLabel": MessageLookupByLibrary.simpleMessage("Age 公钥"),
    "ageRecipientRequired": MessageLookupByLibrary.simpleMessage(
      "请至少填写一个接收者公钥",
    ),
    "ageRecipients": MessageLookupByLibrary.simpleMessage("接收者公钥"),
    "ageRecipientsHint": MessageLookupByLibrary.simpleMessage(
      "可填写多个，每行一个 age1… 公钥",
    ),
    "ageSecretKeyInvalidValidationDesc": MessageLookupByLibrary.simpleMessage(
      "请输入有效的 Age 私钥（必须以 AGE-SECRET-KEY- 开头）",
    ),
    "ageSecretKeyOptional": MessageLookupByLibrary.simpleMessage("Age 私钥（可选）"),
    "ageTabDecrypt": MessageLookupByLibrary.simpleMessage("解密"),
    "ageTabEncrypt": MessageLookupByLibrary.simpleMessage("加密"),
    "ageTabKeys": MessageLookupByLibrary.simpleMessage("密钥"),
    "ageTool": MessageLookupByLibrary.simpleMessage("Age 加解密"),
    "ageToolDesc": MessageLookupByLibrary.simpleMessage("生成密钥，加密或解密文本与配置文件"),
    "ageToolTip": MessageLookupByLibrary.simpleMessage(
      "所有操作都在本机完成，私钥不会被保存或上传。",
    ),
    "ageUseForEncrypt": MessageLookupByLibrary.simpleMessage("用于加密"),
    "ageUseProfileKey": MessageLookupByLibrary.simpleMessage("使用当前配置的私钥"),
    "ago": MessageLookupByLibrary.simpleMessage("前"),
    "agree": MessageLookupByLibrary.simpleMessage("同意"),
    "allApps": MessageLookupByLibrary.simpleMessage("所有应用"),
    "allocatedMemory": MessageLookupByLibrary.simpleMessage("已分配"),
    "allowBypass": MessageLookupByLibrary.simpleMessage("允许绕过VPN"),
    "allowBypassDesc": MessageLookupByLibrary.simpleMessage("开启后部分应用可绕过 VPN"),
    "allowLan": MessageLookupByLibrary.simpleMessage("局域网代理"),
    "allowLanDesc": MessageLookupByLibrary.simpleMessage("允许通过局域网访问代理"),
    "alreadyInWhitelist": MessageLookupByLibrary.simpleMessage("当前应用已在白名单内"),
    "alwaysShowTitleBar": MessageLookupByLibrary.simpleMessage("标题按钮"),
    "alwaysShowTitleBarDesc": MessageLookupByLibrary.simpleMessage(
      "始终显示右上角的标题栏按钮",
    ),
    "analyzeLogPrompt": m0,
    "app": MessageLookupByLibrary.simpleMessage("应用"),
    "appAccessControl": MessageLookupByLibrary.simpleMessage("分应用代理"),
    "appDesc": MessageLookupByLibrary.simpleMessage("处理应用相关设置"),
    "appIconStyle": MessageLookupByLibrary.simpleMessage("图标风格"),
    "appIconStyleDesc": MessageLookupByLibrary.simpleMessage("自定义全局应用图标视觉风格"),
    "appNotInstalled": MessageLookupByLibrary.simpleMessage("应用未安装"),
    "application": MessageLookupByLibrary.simpleMessage("应用程序"),
    "applicationDesc": MessageLookupByLibrary.simpleMessage("修改应用程序设置"),
    "applyManaged": MessageLookupByLibrary.simpleMessage("应用到托管配置"),
    "applyManagedDesc": MessageLookupByLibrary.simpleMessage(
      "所有托管模式下的配置将会同时生效",
    ),
    "applyToAllManaged": MessageLookupByLibrary.simpleMessage("应用到全局托管模式"),
    "applyToAllManagedDesc": MessageLookupByLibrary.simpleMessage(
      "开启后，当前规则将可以针对所有托管配置生效，关闭或非托管模式下，则仅对当前配置生效",
    ),
    "authorized": MessageLookupByLibrary.simpleMessage("已授权"),
    "auto": MessageLookupByLibrary.simpleMessage("自动"),
    "autoBackup": MessageLookupByLibrary.simpleMessage("自动备份"),
    "autoBackupDesc": MessageLookupByLibrary.simpleMessage("配置新增或修改后自动备份"),
    "autoBackupFailed": m1,
    "autoBackupSuccess": MessageLookupByLibrary.simpleMessage("已自动备份到 WebDAV"),
    "autoCheckUpdate": MessageLookupByLibrary.simpleMessage("自动检查更新"),
    "autoCheckUpdateDesc": MessageLookupByLibrary.simpleMessage("应用启动时自动检查更新"),
    "autoCloseConnections": MessageLookupByLibrary.simpleMessage("自动关闭连接"),
    "autoCloseConnectionsDesc": MessageLookupByLibrary.simpleMessage(
      "切换节点后自动关闭连接",
    ),
    "autoDownloadUpdate": MessageLookupByLibrary.simpleMessage("自动下载更新"),
    "autoDownloadUpdateDesc": MessageLookupByLibrary.simpleMessage(
      "发现新版本后在后台自动下载",
    ),
    "autoLaunch": MessageLookupByLibrary.simpleMessage("开机启动"),
    "autoLaunchDesc": MessageLookupByLibrary.simpleMessage("跟随系统自启动"),
    "autoRun": MessageLookupByLibrary.simpleMessage("自动连接"),
    "autoRunDesc": MessageLookupByLibrary.simpleMessage("应用打开后自动连接"),
    "autoScroll": MessageLookupByLibrary.simpleMessage("自动滚动"),
    "autoStickyHeader": MessageLookupByLibrary.simpleMessage("展开组吸顶"),
    "autoUpdate": MessageLookupByLibrary.simpleMessage("自动更新"),
    "autoUpdateInterval": MessageLookupByLibrary.simpleMessage("自动更新间隔（分钟）"),
    "back": MessageLookupByLibrary.simpleMessage("返回"),
    "backgroundWatermark": MessageLookupByLibrary.simpleMessage("背景水印"),
    "backup": MessageLookupByLibrary.simpleMessage("备份"),
    "backupAll": MessageLookupByLibrary.simpleMessage("备份所有数据"),
    "backupAndRecovery": MessageLookupByLibrary.simpleMessage("备份与恢复"),
    "backupAndRecoveryDesc": MessageLookupByLibrary.simpleMessage(
      "通过 WebDAV 或本地同步数据",
    ),
    "backupEncryptedTip": MessageLookupByLibrary.simpleMessage(
      "已使用 AES-256 加密备份",
    ),
    "backupPassword": MessageLookupByLibrary.simpleMessage("备份密码"),
    "backupPasswordDesc": MessageLookupByLibrary.simpleMessage(
      "使用 AES-256 加密备份，留空则不加密",
    ),
    "backupPasswordRequired": MessageLookupByLibrary.simpleMessage(
      "该备份已加密，请输入密码",
    ),
    "backupPasswordTip": MessageLookupByLibrary.simpleMessage("仅支持英文字母、数字和符号"),
    "backupPasswordWrong": MessageLookupByLibrary.simpleMessage("备份密码错误"),
    "backupProfiles": MessageLookupByLibrary.simpleMessage("仅备份配置文件"),
    "backupScopeAllDesc": MessageLookupByLibrary.simpleMessage("配置文件及全部应用设置"),
    "backupScopeProfilesDesc": MessageLookupByLibrary.simpleMessage(
      "订阅、覆写脚本、单节点与托管配置",
    ),
    "backupSuccess": MessageLookupByLibrary.simpleMessage("备份成功"),
    "basicConfig": MessageLookupByLibrary.simpleMessage("内核配置"),
    "basicConfigDesc": MessageLookupByLibrary.simpleMessage("全局修改内核配置"),
    "batteryOptimization": MessageLookupByLibrary.simpleMessage("电池优化"),
    "batteryOptimizationDesc": MessageLookupByLibrary.simpleMessage(
      "请求安卓电池优化白名单权限",
    ),
    "bind": MessageLookupByLibrary.simpleMessage("绑定"),
    "blacklistMode": MessageLookupByLibrary.simpleMessage("黑名单模式"),
    "blockComment": MessageLookupByLibrary.simpleMessage("注释"),
    "builtIn": MessageLookupByLibrary.simpleMessage("内置"),
    "builtInManagedMode": MessageLookupByLibrary.simpleMessage("内置托管模式"),
    "bundleAddUrl": MessageLookupByLibrary.simpleMessage("订阅链接"),
    "bundleAddUrlDesc": MessageLookupByLibrary.simpleMessage("导入为新订阅并加入成员"),
    "bundleCollapse": MessageLookupByLibrary.simpleMessage("收起成员订阅"),
    "bundleCollapseDesc": MessageLookupByLibrary.simpleMessage(
      "开启后配置列表中只显示合并后的订阅信息，点按卡片右下角可展开或收起",
    ),
    "bundleDedupTip": MessageLookupByLibrary.simpleMessage(
      "内容相同的节点只保留一份，按成员顺序优先",
    ),
    "bundleExpand": MessageLookupByLibrary.simpleMessage("展开"),
    "bundleFailures": m2,
    "bundleMemberFailed": m3,
    "bundleMemberLimit": m4,
    "bundleMembers": MessageLookupByLibrary.simpleMessage("成员配置"),
    "bundleMembersDesc": MessageLookupByLibrary.simpleMessage(
      "点按修改节点前缀，拖动调整顺序",
    ),
    "bundleNoMembers": MessageLookupByLibrary.simpleMessage("请至少添加一个成员"),
    "bundlePendingImport": MessageLookupByLibrary.simpleMessage("待导入"),
    "bundleProxies": m5,
    "bundleReportDesc": m6,
    "bundleSummary": m7,
    "bypassDomain": MessageLookupByLibrary.simpleMessage("排除域名"),
    "bypassDomainDesc": MessageLookupByLibrary.simpleMessage("仅在系统代理启用时生效"),
    "bypassPrivateRoute": MessageLookupByLibrary.simpleMessage("绕过私有网络"),
    "bypassPrivateRouteDesc": MessageLookupByLibrary.simpleMessage(
      "自动绕过私有网络 IP 地址",
    ),
    "cacheCorrupt": MessageLookupByLibrary.simpleMessage("缓存已损坏，是否清空？"),
    "cameraPermissionDenied": MessageLookupByLibrary.simpleMessage("相机权限被拒绝"),
    "cameraPermissionDesc": MessageLookupByLibrary.simpleMessage(
      "扫描二维码需要相机权限，请在设置中授予相机权限。",
    ),
    "cancel": MessageLookupByLibrary.simpleMessage("取消"),
    "cancelFilterSystemApp": MessageLookupByLibrary.simpleMessage("取消过滤系统应用"),
    "cancelSelectAll": MessageLookupByLibrary.simpleMessage("取消全选"),
    "categoryAi": MessageLookupByLibrary.simpleMessage("AI"),
    "categoryAll": MessageLookupByLibrary.simpleMessage("全部"),
    "categoryChina": MessageLookupByLibrary.simpleMessage("国内直连"),
    "categoryCrypto": MessageLookupByLibrary.simpleMessage("加密货币"),
    "categoryDeveloper": MessageLookupByLibrary.simpleMessage("开发者"),
    "categoryGaming": MessageLookupByLibrary.simpleMessage("游戏中心"),
    "categorySocial": MessageLookupByLibrary.simpleMessage("社区平台"),
    "categoryStreaming": MessageLookupByLibrary.simpleMessage("流媒体"),
    "chasingDots": MessageLookupByLibrary.simpleMessage("双星追逐"),
    "checkError": MessageLookupByLibrary.simpleMessage("检测失败"),
    "checkFailed": MessageLookupByLibrary.simpleMessage("Timeout"),
    "checkOrAddProfile": MessageLookupByLibrary.simpleMessage("请先添加配置"),
    "checkUpdate": MessageLookupByLibrary.simpleMessage("检查更新"),
    "checkUpdateError": MessageLookupByLibrary.simpleMessage("当前应用已经是最新版了"),
    "checkUrlTip": MessageLookupByLibrary.simpleMessage("请检查 URL 是否正确"),
    "checking": MessageLookupByLibrary.simpleMessage("检测中..."),
    "chooseFront": MessageLookupByLibrary.simpleMessage("选择节点或代理组"),
    "circle": MessageLookupByLibrary.simpleMessage("圆环流转"),
    "clear": MessageLookupByLibrary.simpleMessage("清空"),
    "clearCacheTitle": MessageLookupByLibrary.simpleMessage("清理缓存"),
    "clearData": MessageLookupByLibrary.simpleMessage("清除数据"),
    "clearDataTipDesc": MessageLookupByLibrary.simpleMessage(
      "此操作将会重置应用程序, 请注意备份, 确定要继续吗？",
    ),
    "clearDataTipTitle": MessageLookupByLibrary.simpleMessage("危险操作"),
    "clearFilter": MessageLookupByLibrary.simpleMessage("清除筛选"),
    "clipboard": MessageLookupByLibrary.simpleMessage("剪切板"),
    "clipboardDesc": MessageLookupByLibrary.simpleMessage("自动获取剪切板订阅链接"),
    "clipboardExport": MessageLookupByLibrary.simpleMessage("导出剪贴板"),
    "clipboardImport": MessageLookupByLibrary.simpleMessage("剪贴板导入"),
    "close": MessageLookupByLibrary.simpleMessage("关闭"),
    "closeAll": MessageLookupByLibrary.simpleMessage("关闭全部"),
    "cloudflareTerms": MessageLookupByLibrary.simpleMessage("Cloudflare 的服务条款"),
    "collapse": MessageLookupByLibrary.simpleMessage("收起"),
    "color": MessageLookupByLibrary.simpleMessage("颜色"),
    "colorSchemes": MessageLookupByLibrary.simpleMessage("配色方案"),
    "columns": MessageLookupByLibrary.simpleMessage("列数"),
    "compatible": MessageLookupByLibrary.simpleMessage("兼容模式"),
    "compatibleDesc": MessageLookupByLibrary.simpleMessage(
      "开启将失去部分应用能力，获得全量的 Clash 支持",
    ),
    "concurrencyLimit": MessageLookupByLibrary.simpleMessage("并发限制"),
    "concurrencyLimitDesc": MessageLookupByLibrary.simpleMessage("延迟测试的最大并发数量"),
    "configInfo": MessageLookupByLibrary.simpleMessage("配置信息"),
    "configShareYaml": MessageLookupByLibrary.simpleMessage("配置分享(YAML)"),
    "configViewEdit": MessageLookupByLibrary.simpleMessage("配置查看(编辑)"),
    "configViewReadOnly": MessageLookupByLibrary.simpleMessage("配置查看(只读)"),
    "confirm": MessageLookupByLibrary.simpleMessage("确定"),
    "connection": MessageLookupByLibrary.simpleMessage("活跃连接"),
    "connections": MessageLookupByLibrary.simpleMessage("连接"),
    "connectionsActive": MessageLookupByLibrary.simpleMessage("活动"),
    "connectionsClosed": MessageLookupByLibrary.simpleMessage("已关闭"),
    "connectionsDesc": MessageLookupByLibrary.simpleMessage("查看活动和已关闭的连接"),
    "connectionsSort": MessageLookupByLibrary.simpleMessage("连接排序"),
    "connectivity": MessageLookupByLibrary.simpleMessage("连通性："),
    "connectivityTest": MessageLookupByLibrary.simpleMessage("连通检测"),
    "connectivityTestDesc": MessageLookupByLibrary.simpleMessage(
      "检测当前节点线路是否正常",
    ),
    "contactMe": MessageLookupByLibrary.simpleMessage("联系我"),
    "content": MessageLookupByLibrary.simpleMessage("内容"),
    "contentScheme": MessageLookupByLibrary.simpleMessage("内容主题"),
    "continent": MessageLookupByLibrary.simpleMessage("大洲"),
    "controlSecret": MessageLookupByLibrary.simpleMessage("控制密码"),
    "controlSecretDesc": MessageLookupByLibrary.simpleMessage(
      "RESTful API 的访问密码",
    ),
    "copiedToClipboard": MessageLookupByLibrary.simpleMessage("已复制到剪贴板"),
    "copy": MessageLookupByLibrary.simpleMessage("复制"),
    "copyEnvVar": MessageLookupByLibrary.simpleMessage("复制环境变量"),
    "copyLink": MessageLookupByLibrary.simpleMessage("复制链接"),
    "copySuccess": MessageLookupByLibrary.simpleMessage("复制成功"),
    "core": MessageLookupByLibrary.simpleMessage("内核"),
    "coreCapabilityNotEffective": MessageLookupByLibrary.simpleMessage(
      "内核授权未生效：运行中的内核缺少 CAP_NET_ADMIN，TUN 可能无法工作",
    ),
    "coreConnected": MessageLookupByLibrary.simpleMessage("已连接"),
    "coreInfo": MessageLookupByLibrary.simpleMessage("内核信息"),
    "coreMountNosuid": MessageLookupByLibrary.simpleMessage(
      "内核所在文件系统以 nosuid 挂载，文件能力与 setuid 均无法生效",
    ),
    "coreStatus": MessageLookupByLibrary.simpleMessage("内核负载详情"),
    "coreSuspended": MessageLookupByLibrary.simpleMessage("已挂起"),
    "country": MessageLookupByLibrary.simpleMessage("区域"),
    "countryOrRegion": MessageLookupByLibrary.simpleMessage("国家 / 地区"),
    "crashTest": MessageLookupByLibrary.simpleMessage("崩溃测试"),
    "create": MessageLookupByLibrary.simpleMessage("创建"),
    "creationTime": MessageLookupByLibrary.simpleMessage("创建时间"),
    "cubeGrid": MessageLookupByLibrary.simpleMessage("九宫烁影"),
    "currentSelection": MessageLookupByLibrary.simpleMessage("当前选择"),
    "custom": MessageLookupByLibrary.simpleMessage("自定义"),
    "customDashboardTitle": MessageLookupByLibrary.simpleMessage("个性标题"),
    "customRuleSetUrl": MessageLookupByLibrary.simpleMessage("自定义规则集地址"),
    "customScriptOptions": MessageLookupByLibrary.simpleMessage("自定义规则开关"),
    "customUrl": MessageLookupByLibrary.simpleMessage("自定义URL"),
    "cut": MessageLookupByLibrary.simpleMessage("剪切"),
    "dancingSquare": MessageLookupByLibrary.simpleMessage("方块起舞"),
    "dark": MessageLookupByLibrary.simpleMessage("深色"),
    "dashboard": MessageLookupByLibrary.simpleMessage("首页"),
    "dashboardAverage": m8,
    "dashboardTotal": MessageLookupByLibrary.simpleMessage("合计"),
    "days": m9,
    "defaultGateway": MessageLookupByLibrary.simpleMessage("网关"),
    "defaultSort": MessageLookupByLibrary.simpleMessage("按默认排序"),
    "defaultText": MessageLookupByLibrary.simpleMessage("默认"),
    "delay": MessageLookupByLibrary.simpleMessage("延迟"),
    "delayAnimation": MessageLookupByLibrary.simpleMessage("延迟动画"),
    "delayAnimationDesc": MessageLookupByLibrary.simpleMessage("自定义测试过程中的动画显示"),
    "delaySort": MessageLookupByLibrary.simpleMessage("按延迟排序"),
    "delete": MessageLookupByLibrary.simpleMessage("删除"),
    "deleteMemberTip": m10,
    "deleteMultipTip": m11,
    "deleteTip": m12,
    "deleteTunnel": MessageLookupByLibrary.simpleMessage("删除转发"),
    "desc": MessageLookupByLibrary.simpleMessage(
      "FastLin 基于强大灵活的 Mihomo 内核深度打造，致力于更好的客户端体验，我们的愿景: Connecting Open Source and AI，Accelerating Innovation",
    ),
    "destination": MessageLookupByLibrary.simpleMessage("目标地址"),
    "destinationGeoIP": MessageLookupByLibrary.simpleMessage("目标地理定位"),
    "destinationIPASN": MessageLookupByLibrary.simpleMessage("目标 IP ASN"),
    "details": MessageLookupByLibrary.simpleMessage("详情"),
    "detectionTip": MessageLookupByLibrary.simpleMessage("依赖第三方 API，仅供参考"),
    "developerMode": MessageLookupByLibrary.simpleMessage("开发者模式"),
    "developerModeEnableTip": MessageLookupByLibrary.simpleMessage("开发者模式已启用。"),
    "dialerIp4pConvert": MessageLookupByLibrary.simpleMessage("启用拨号 IP4P 地址转换"),
    "dialerIp4pConvertDesc": MessageLookupByLibrary.simpleMessage(
      "启用拨号器的 IP4P 地址转换功能",
    ),
    "direct": MessageLookupByLibrary.simpleMessage("直连"),
    "directModeNoProxy": MessageLookupByLibrary.simpleMessage("直连模式，暂无代理"),
    "directUpdate": MessageLookupByLibrary.simpleMessage("通过直连更新"),
    "disableQuic": MessageLookupByLibrary.simpleMessage("禁用QUIC"),
    "disableQuicDesc": MessageLookupByLibrary.simpleMessage(
      "禁用 QUIC 以缓解特定网络问题",
    ),
    "disableQuicManagedDesc": MessageLookupByLibrary.simpleMessage(
      "启用脚本时禁用 QUIC 功能不生效",
    ),
    "disabled": MessageLookupByLibrary.simpleMessage("已关闭"),
    "disclaimer": MessageLookupByLibrary.simpleMessage("免责声明"),
    "disclaimerDesc": MessageLookupByLibrary.simpleMessage(
      "本软件为开源免费软件，仅供学习交流等非商业性质的个人测试使用，代理服务商的行为均与本软件无关，同意声明代表您已完全知晓并确认了这一点，如不同意，请选择退出！",
    ),
    "discoverNewVersion": MessageLookupByLibrary.simpleMessage("发现新版本"),
    "discovery": MessageLookupByLibrary.simpleMessage("发现新版本"),
    "dnsCacheCleared": MessageLookupByLibrary.simpleMessage(
      "已清理 FakeIP 与 DNS 缓存",
    ),
    "dnsHijack": MessageLookupByLibrary.simpleMessage("DNS 劫持"),
    "dnsHijackDesc": MessageLookupByLibrary.simpleMessage("接管系统 DNS 并导入到内核处理"),
    "dnsMode": MessageLookupByLibrary.simpleMessage("DNS模式"),
    "dnsQuery": MessageLookupByLibrary.simpleMessage("DNS 查询"),
    "dnsQueryCompare": MessageLookupByLibrary.simpleMessage("对比解析"),
    "dnsQueryCompareDesc": MessageLookupByLibrary.simpleMessage(
      "同时用跟随规则、系统 DNS 与指定服务器解析，便于发现污染与分流差异",
    ),
    "dnsQueryDesc": MessageLookupByLibrary.simpleMessage("按规则、系统或指定服务器解析域名"),
    "dnsQueryFakeIpOff": m13,
    "dnsQueryFakeIpOn": m14,
    "dnsQueryFilterBlackHit": MessageLookupByLibrary.simpleMessage("黑名单已命中"),
    "dnsQueryFilterBlackMiss": MessageLookupByLibrary.simpleMessage("黑名单未命中"),
    "dnsQueryFilterRuleFake": MessageLookupByLibrary.simpleMessage(
      "规则判定为 fake-ip",
    ),
    "dnsQueryFilterRuleReal": MessageLookupByLibrary.simpleMessage(
      "规则判定为 real-ip",
    ),
    "dnsQueryFilterWhiteHit": MessageLookupByLibrary.simpleMessage("白名单已命中"),
    "dnsQueryFilterWhiteMiss": MessageLookupByLibrary.simpleMessage("白名单未命中"),
    "dnsQueryHint": MessageLookupByLibrary.simpleMessage("输入域名"),
    "dnsQueryHostsHit": m15,
    "dnsQueryNoRecords": MessageLookupByLibrary.simpleMessage("没有记录"),
    "dnsQueryNormalMode": MessageLookupByLibrary.simpleMessage(
      "Normal：将返回真实 IP，规则按 IP 匹配",
    ),
    "dnsQueryRedirHost": MessageLookupByLibrary.simpleMessage(
      "Redir-Host：将返回真实 IP，连接时还原为域名",
    ),
    "dnsQueryServer": MessageLookupByLibrary.simpleMessage("DNS 服务器"),
    "dnsQueryServerHint": MessageLookupByLibrary.simpleMessage(
      "如 223.5.5.5、https://dns.alidns.com/dns-query",
    ),
    "dnsQueryServerInvalid": MessageLookupByLibrary.simpleMessage(
      "DNS 服务器格式无效",
    ),
    "dnsQueryStopped": MessageLookupByLibrary.simpleMessage("代理未启动，「跟随规则」不可用"),
    "dnsQuerySystem": MessageLookupByLibrary.simpleMessage("系统 DNS"),
    "dnsQueryViaDirect": MessageLookupByLibrary.simpleMessage(
      "最终走 DIRECT 出口，由内核本地解析后直连",
    ),
    "dnsQueryViaDirectHosts": MessageLookupByLibrary.simpleMessage(
      "最终走 DIRECT 出口，直连 Hosts 地址",
    ),
    "dnsQueryViaProxy": m16,
    "dnsQueryViaProxyHosts": m17,
    "dnsQueryViaReject": MessageLookupByLibrary.simpleMessage("被规则拒绝"),
    "dnsResolution": MessageLookupByLibrary.simpleMessage("DNS 解析"),
    "doYouWantToPass": MessageLookupByLibrary.simpleMessage("是否要通过"),
    "domain": MessageLookupByLibrary.simpleMessage("域名"),
    "doubleBounce": MessageLookupByLibrary.simpleMessage("双重弹奏"),
    "download": MessageLookupByLibrary.simpleMessage("下载"),
    "dozeSuspend": MessageLookupByLibrary.simpleMessage("休眠支持"),
    "dozeSuspendDesc": MessageLookupByLibrary.simpleMessage(
      "开启后同步系统 Doze 休眠模式",
    ),
    "dualRing": MessageLookupByLibrary.simpleMessage("双环回旋"),
    "dynamicColor": MessageLookupByLibrary.simpleMessage("莫奈取色"),
    "edit": MessageLookupByLibrary.simpleMessage("编辑"),
    "editRoute": MessageLookupByLibrary.simpleMessage("编辑分流"),
    "editTunnel": MessageLookupByLibrary.simpleMessage("编辑转发"),
    "editUser": MessageLookupByLibrary.simpleMessage("编辑用户"),
    "emptyTip": m18,
    "enableCrashReport": MessageLookupByLibrary.simpleMessage("应用崩溃分析"),
    "enableCrashReportDesc": MessageLookupByLibrary.simpleMessage(
      "必要时上传应用崩溃日志",
    ),
    "enableOverride": MessageLookupByLibrary.simpleMessage("启用覆写"),
    "enableTraySpeed": MessageLookupByLibrary.simpleMessage("网速显示"),
    "enableTraySpeedDesc": MessageLookupByLibrary.simpleMessage(
      "在菜单栏显示上传和下载速率",
    ),
    "enabled": MessageLookupByLibrary.simpleMessage("已开启"),
    "endpointIndependentNat": MessageLookupByLibrary.simpleMessage("NAT增强"),
    "endpointIndependentNatConfirmDesc": MessageLookupByLibrary.simpleMessage(
      "启用 Endpoint-Independent NAT 功能，性能可能会略有下降，此功能仅建议您在必要且熟悉的情况下开启",
    ),
    "endpointIndependentNatDesc": MessageLookupByLibrary.simpleMessage(
      "优化 UDP/P2P 应用体验",
    ),
    "entries": MessageLookupByLibrary.simpleMessage("个条目"),
    "exclude": MessageLookupByLibrary.simpleMessage("后台隐藏"),
    "excludeDesc": MessageLookupByLibrary.simpleMessage("从最近任务中隐藏应用"),
    "existsTip": m19,
    "exit": MessageLookupByLibrary.simpleMessage("退出"),
    "expand": MessageLookupByLibrary.simpleMessage("标准"),
    "experimental": MessageLookupByLibrary.simpleMessage("Experimental"),
    "experimentalDesc": MessageLookupByLibrary.simpleMessage("实验性配置请谨慎使用"),
    "expirationTime": MessageLookupByLibrary.simpleMessage("到期时间"),
    "expired": MessageLookupByLibrary.simpleMessage("已过期"),
    "export": MessageLookupByLibrary.simpleMessage("导出"),
    "exportFile": MessageLookupByLibrary.simpleMessage("导出文件"),
    "exportLogs": MessageLookupByLibrary.simpleMessage("导出日志"),
    "exportSuccess": MessageLookupByLibrary.simpleMessage("导出成功"),
    "expressiveScheme": MessageLookupByLibrary.simpleMessage("表现力"),
    "externalController": MessageLookupByLibrary.simpleMessage("外部控制"),
    "externalControllerDesc": MessageLookupByLibrary.simpleMessage(
      "通过在线端口控制内核",
    ),
    "externalControllerPort": MessageLookupByLibrary.simpleMessage("外部控制端口"),
    "externalLink": MessageLookupByLibrary.simpleMessage("外部链接"),
    "externalResources": MessageLookupByLibrary.simpleMessage("外部资源"),
    "fadingCircle": MessageLookupByLibrary.simpleMessage("环影隐渐"),
    "fadingCube": MessageLookupByLibrary.simpleMessage("方影微漾"),
    "fadingFour": MessageLookupByLibrary.simpleMessage("四方烁动"),
    "fadingGrid": MessageLookupByLibrary.simpleMessage("栅格隐现"),
    "fakeIpFilterModeDesc": MessageLookupByLibrary.simpleMessage(
      "指定 FakeIP 过滤模式",
    ),
    "fast": MessageLookupByLibrary.simpleMessage("快"),
    "fcmAndroidTip": MessageLookupByLibrary.simpleMessage(
      "因系统权限原因，Android 端您可能需要关闭网络中的\"允许绕过 VPN\"选项，以获得更加准确的结果",
    ),
    "fcmOptimization": MessageLookupByLibrary.simpleMessage("FCM优化"),
    "fcmOptimizationDesc": MessageLookupByLibrary.simpleMessage(
      "增强 FCM 直连时的网络稳定性",
    ),
    "fcmTip": MessageLookupByLibrary.simpleMessage(
      "Firebase Cloud Messaging (FCM) 是一种跨平台消息传递解决方案，其连接支持取决于设备和网络本身，显示结果仅供参考。",
    ),
    "fidelityScheme": MessageLookupByLibrary.simpleMessage("高保真"),
    "file": MessageLookupByLibrary.simpleMessage("文件"),
    "fileDesc": MessageLookupByLibrary.simpleMessage("直接上传配置文件"),
    "fileIsUpdate": MessageLookupByLibrary.simpleMessage("文件有修改，是否保存修改"),
    "fileNotFound": MessageLookupByLibrary.simpleMessage("文件已不存在"),
    "filterSystemApp": MessageLookupByLibrary.simpleMessage("过滤系统应用"),
    "findProcessAlways": MessageLookupByLibrary.simpleMessage("始终开启"),
    "findProcessAlwaysDesc": MessageLookupByLibrary.simpleMessage(
      "始终开启，连接列表可显示应用图标",
    ),
    "findProcessMode": MessageLookupByLibrary.simpleMessage("查找进程"),
    "findProcessModeDesc": MessageLookupByLibrary.simpleMessage("开启后可以匹配查找进程"),
    "findProcessOff": MessageLookupByLibrary.simpleMessage("关闭查找"),
    "findProcessOffDesc": MessageLookupByLibrary.simpleMessage(
      "关闭后进程规则不再生效，更加高效",
    ),
    "findProcessStrict": MessageLookupByLibrary.simpleMessage("按需开启"),
    "findProcessStrictDesc": MessageLookupByLibrary.simpleMessage(
      "仅在有相关进程规则时开启，更智能",
    ),
    "flagged": MessageLookupByLibrary.simpleMessage("已标记"),
    "foldingCube": MessageLookupByLibrary.simpleMessage("魔方翻折"),
    "fontFamily": MessageLookupByLibrary.simpleMessage("字体"),
    "forceDnsMapping": MessageLookupByLibrary.simpleMessage("强制 DNS 映射"),
    "forceDnsMappingDesc": MessageLookupByLibrary.simpleMessage(
      "强制将 DNS 查询结果映射到连接",
    ),
    "forceDomain": MessageLookupByLibrary.simpleMessage("强制嗅探域名"),
    "forceGCTitle": MessageLookupByLibrary.simpleMessage("强制垃圾回收"),
    "formatError": MessageLookupByLibrary.simpleMessage("请检查格式是否正确"),
    "fourColumns": MessageLookupByLibrary.simpleMessage("四列"),
    "frontMissing": m20,
    "frontProxy": MessageLookupByLibrary.simpleMessage("前置代理"),
    "frontUdpUnsupported": MessageLookupByLibrary.simpleMessage(
      "当前前置节点不支持UDP，请检查配置",
    ),
    "fruitSaladScheme": MessageLookupByLibrary.simpleMessage("果缤纷"),
    "fullRestart": MessageLookupByLibrary.simpleMessage("冷重启"),
    "fullRestartDesc": MessageLookupByLibrary.simpleMessage("完整重启内核，内存释放更加彻底"),
    "general": MessageLookupByLibrary.simpleMessage("常规"),
    "generalDesc": MessageLookupByLibrary.simpleMessage("修改全局通用设置"),
    "generate": MessageLookupByLibrary.simpleMessage("生成"),
    "generateFromPrivateKey": MessageLookupByLibrary.simpleMessage(
      "从 Age 私钥生成",
    ),
    "generateQrCode": MessageLookupByLibrary.simpleMessage("生成二维码"),
    "generateSecret": MessageLookupByLibrary.simpleMessage("生成"),
    "geoBuiltInResources": MessageLookupByLibrary.simpleMessage("GEO 内置资源"),
    "geoData": MessageLookupByLibrary.simpleMessage("地理数据"),
    "geodataLoader": MessageLookupByLibrary.simpleMessage("GEO 节能"),
    "geodataLoaderDesc": MessageLookupByLibrary.simpleMessage("使用 GEO 低内存加载器"),
    "geodataUse": MessageLookupByLibrary.simpleMessage("GEO加载"),
    "global": MessageLookupByLibrary.simpleMessage("全局"),
    "go": MessageLookupByLibrary.simpleMessage("前往"),
    "goDownload": MessageLookupByLibrary.simpleMessage("前往下载"),
    "groupOrderTip": MessageLookupByLibrary.simpleMessage("拖动调整显示顺序，自定义分流优先匹配"),
    "harmonyFont": MessageLookupByLibrary.simpleMessage("字体修复"),
    "harmonyFontDesc": MessageLookupByLibrary.simpleMessage("使用内置字体解决显示异常问题"),
    "hasCacheChange": MessageLookupByLibrary.simpleMessage("是否缓存修改"),
    "healthCheckTimeout": MessageLookupByLibrary.simpleMessage("超时时间"),
    "healthCheckTimeoutDesc": MessageLookupByLibrary.simpleMessage(
      "节点健康检查超时时间",
    ),
    "heapObjects": MessageLookupByLibrary.simpleMessage("堆对象"),
    "hideTimeoutProxies": MessageLookupByLibrary.simpleMessage("隐藏失效节点"),
    "highPriority": MessageLookupByLibrary.simpleMessage("高优先级"),
    "highPriorityDesc": MessageLookupByLibrary.simpleMessage("提升主程序和内核进程的优先级"),
    "hitCount": m21,
    "host": MessageLookupByLibrary.simpleMessage("主机"),
    "hostsDesc": MessageLookupByLibrary.simpleMessage("追加当前配置 Hosts"),
    "hotReload": MessageLookupByLibrary.simpleMessage("热重载"),
    "hotReloadDesc": MessageLookupByLibrary.simpleMessage("保持内核运行，订阅切换更加快速"),
    "hotkeyConflict": MessageLookupByLibrary.simpleMessage("快捷键冲突"),
    "hotkeyManagement": MessageLookupByLibrary.simpleMessage("快捷键管理"),
    "hotkeyManagementDesc": MessageLookupByLibrary.simpleMessage("使用键盘控制应用程序"),
    "hourGlass": MessageLookupByLibrary.simpleMessage("沙漏翻转"),
    "hours": m22,
    "httpPortSniffer": MessageLookupByLibrary.simpleMessage("HTTP 端口嗅探"),
    "icmpForwarding": MessageLookupByLibrary.simpleMessage("ICMP转发"),
    "icmpForwardingDesc": MessageLookupByLibrary.simpleMessage(
      "开启后将支持 ICMP Ping",
    ),
    "icon": MessageLookupByLibrary.simpleMessage("图标"),
    "iconConfiguration": MessageLookupByLibrary.simpleMessage("图标设置"),
    "iconConfigurationDesc": MessageLookupByLibrary.simpleMessage(
      "自定义代理组 ICON 图标",
    ),
    "iconCount": m23,
    "iconSets": MessageLookupByLibrary.simpleMessage("图标集"),
    "iconStyle": MessageLookupByLibrary.simpleMessage("图标样式"),
    "iconStyleCupertino": MessageLookupByLibrary.simpleMessage("Cupertino"),
    "iconStyleCupertinoDesc": MessageLookupByLibrary.simpleMessage(
      "苹果 iOS / SF Symbols 经典视觉风格",
    ),
    "iconStyleMaterial": MessageLookupByLibrary.simpleMessage("Material"),
    "iconStyleMaterialDesc": MessageLookupByLibrary.simpleMessage(
      "谷歌 Material Design 官方视觉风格",
    ),
    "iconStylePhosphor": MessageLookupByLibrary.simpleMessage("Phosphor"),
    "iconStylePhosphorDesc": MessageLookupByLibrary.simpleMessage("现代几何极简视觉风格"),
    "iconUrl": MessageLookupByLibrary.simpleMessage("图标 URL"),
    "import": MessageLookupByLibrary.simpleMessage("导入"),
    "importFailed": MessageLookupByLibrary.simpleMessage("导入失败"),
    "importFile": MessageLookupByLibrary.simpleMessage("通过文件导入"),
    "importFromCode": MessageLookupByLibrary.simpleMessage("通过代码导入"),
    "importFromURL": MessageLookupByLibrary.simpleMessage("从 URL 导入"),
    "importUrl": MessageLookupByLibrary.simpleMessage("通过 URL 导入"),
    "inUse": MessageLookupByLibrary.simpleMessage("当前使用"),
    "inbound": MessageLookupByLibrary.simpleMessage("入站"),
    "inboundWithUser": m24,
    "infiniteTime": MessageLookupByLibrary.simpleMessage("长期有效"),
    "init": MessageLookupByLibrary.simpleMessage("初始化"),
    "injectNode": MessageLookupByLibrary.simpleMessage("注入到此配置"),
    "injectNodeDesc": MessageLookupByLibrary.simpleMessage("非托管模式下仅对当前配置生效"),
    "injectNodeEmpty": MessageLookupByLibrary.simpleMessage("当前配置加载后可选择代理组"),
    "inputCorrectHotkey": MessageLookupByLibrary.simpleMessage("请输入正确的快捷键"),
    "install": MessageLookupByLibrary.simpleMessage("安装"),
    "installTime": MessageLookupByLibrary.simpleMessage("安装时间"),
    "intelligentSelected": MessageLookupByLibrary.simpleMessage("智能选择"),
    "intelligentSelectedConfirm": MessageLookupByLibrary.simpleMessage(
      "是否使用预置规则自动选择？",
    ),
    "internalTraffic": MessageLookupByLibrary.simpleMessage("内部流量"),
    "internet": MessageLookupByLibrary.simpleMessage("互联网"),
    "interval": MessageLookupByLibrary.simpleMessage("间隔"),
    "intranetAndGateway": MessageLookupByLibrary.simpleMessage("内网与网关"),
    "intranetIP": MessageLookupByLibrary.simpleMessage("内网 IP"),
    "invalidIconSet": MessageLookupByLibrary.simpleMessage("不是有效的图标集"),
    "invalidIpFormat": MessageLookupByLibrary.simpleMessage("无效的 IP 或 CIDR 格式"),
    "ip": MessageLookupByLibrary.simpleMessage("IP"),
    "ipAddress": MessageLookupByLibrary.simpleMessage("IP 地址"),
    "ipClickBehavior": MessageLookupByLibrary.simpleMessage("显示切换"),
    "ipLookup": MessageLookupByLibrary.simpleMessage("IP 全能查"),
    "ipLookupDesc": MessageLookupByLibrary.simpleMessage(
      "查看本机出口 IP，或查询任意 IP 与域名",
    ),
    "ipLookupDomesticExit": MessageLookupByLibrary.simpleMessage("国内本地 IP"),
    "ipLookupHint": MessageLookupByLibrary.simpleMessage("输入 IP 或域名"),
    "ipLookupInvalid": MessageLookupByLibrary.simpleMessage("请输入有效的 IP 或域名"),
    "ipLookupLocal": MessageLookupByLibrary.simpleMessage("本机网络"),
    "ipLookupMine": MessageLookupByLibrary.simpleMessage("我的 IP"),
    "ipLookupProxyExit": MessageLookupByLibrary.simpleMessage("默认节点 IP"),
    "ipLookupResolveFailed": MessageLookupByLibrary.simpleMessage("无法解析该域名"),
    "ipLookupResult": MessageLookupByLibrary.simpleMessage("查询结果"),
    "ipPrivacyProtection": MessageLookupByLibrary.simpleMessage("保护 IP 显示"),
    "ipRiskAlert": MessageLookupByLibrary.simpleMessage("IP 风险提示"),
    "ipRiskAmountHigh": MessageLookupByLibrary.simpleMessage("较多"),
    "ipRiskAmountLow": MessageLookupByLibrary.simpleMessage("较少"),
    "ipRiskAmountMedium": MessageLookupByLibrary.simpleMessage("中等"),
    "ipRiskAnonymousVpn": MessageLookupByLibrary.simpleMessage("匿名 VPN"),
    "ipRiskBlacklist": MessageLookupByLibrary.simpleMessage("黑名单标记"),
    "ipRiskCheck": MessageLookupByLibrary.simpleMessage("纯净度检测"),
    "ipRiskCommercialServer": MessageLookupByLibrary.simpleMessage("商业服务器"),
    "ipRiskDatacenter": MessageLookupByLibrary.simpleMessage("数据中心"),
    "ipRiskHigh": MessageLookupByLibrary.simpleMessage("高风险"),
    "ipRiskHint": MessageLookupByLibrary.simpleMessage("输入要查询的 IP"),
    "ipRiskHomeBroadband": MessageLookupByLibrary.simpleMessage("优质原生 IP"),
    "ipRiskHostingOrProxy": MessageLookupByLibrary.simpleMessage("机房或代理"),
    "ipRiskHostname": MessageLookupByLibrary.simpleMessage("主机名"),
    "ipRiskInvalid": MessageLookupByLibrary.simpleMessage("请输入有效的公网 IP"),
    "ipRiskLow": MessageLookupByLibrary.simpleMessage("低风险"),
    "ipRiskMedium": MessageLookupByLibrary.simpleMessage("中风险"),
    "ipRiskNoteAmount": MessageLookupByLibrary.simpleMessage("观测流量"),
    "ipRiskNoteAmountIsp": MessageLookupByLibrary.simpleMessage("运营商流量"),
    "ipRiskNoteConnection": MessageLookupByLibrary.simpleMessage("连接类型"),
    "ipRiskNoteDirect": m25,
    "ipRiskNoteFootnote": MessageLookupByLibrary.simpleMessage(
      "以上评估仅针对网页流量，其他类型流量的风险可能不同。",
    ),
    "ipRiskNoteGeneric": MessageLookupByLibrary.simpleMessage(
      "欺诈值代表 Scamalytics 认为来自该 IP 的网页流量中疑似欺诈流量所占的比例，范围为 0–100。",
    ),
    "ipRiskNoteIndirect": m26,
    "ipRiskNoteOwner": MessageLookupByLibrary.simpleMessage("所有者"),
    "ipRiskNoteProxying": MessageLookupByLibrary.simpleMessage(
      "可能在代理来自其他地区的流量，实际用户可能位于任何地方",
    ),
    "ipRiskNoteShare": MessageLookupByLibrary.simpleMessage("疑似欺诈"),
    "ipRiskNoteTitle": MessageLookupByLibrary.simpleMessage("欺诈值说明"),
    "ipRiskNoteWarningHigh": MessageLookupByLibrary.simpleMessage(
      "如果看到来自该 IP 的网页流量，很可能是欺诈分子在活动。",
    ),
    "ipRiskNoteWarningVeryHigh": MessageLookupByLibrary.simpleMessage(
      "如果看到来自该 IP 的网页流量，极有可能是欺诈分子在活动。",
    ),
    "ipRiskProxyType": MessageLookupByLibrary.simpleMessage("代理类型"),
    "ipRiskPublicProxy": MessageLookupByLibrary.simpleMessage("公共代理"),
    "ipRiskResidentialProxy": MessageLookupByLibrary.simpleMessage("住宅代理"),
    "ipRiskScore": MessageLookupByLibrary.simpleMessage("欺诈值"),
    "ipRiskSearchRobot": MessageLookupByLibrary.simpleMessage("搜索引擎爬虫"),
    "ipRiskServer": MessageLookupByLibrary.simpleMessage("服务器"),
    "ipRiskShareAlmostAll": MessageLookupByLibrary.simpleMessage("几乎全部"),
    "ipRiskShareLittle": MessageLookupByLibrary.simpleMessage("极少"),
    "ipRiskShareSome": MessageLookupByLibrary.simpleMessage("部分"),
    "ipRiskSource": MessageLookupByLibrary.simpleMessage("数据来源"),
    "ipRiskTorExit": MessageLookupByLibrary.simpleMessage("Tor 出口节点"),
    "ipRiskVeryHigh": MessageLookupByLibrary.simpleMessage("极高风险"),
    "ipRiskWebProxy": MessageLookupByLibrary.simpleMessage("Web 代理"),
    "ipcidr": MessageLookupByLibrary.simpleMessage("IP / 掩码"),
    "iperfAddressHint": MessageLookupByLibrary.simpleMessage(
      "服务器地址，例如 192.168.1.5",
    ),
    "iperfAddressRequired": MessageLookupByLibrary.simpleMessage("请输入服务器地址"),
    "iperfAddresses": MessageLookupByLibrary.simpleMessage("本机地址"),
    "iperfBandwidth": MessageLookupByLibrary.simpleMessage("发送速率"),
    "iperfBidir": MessageLookupByLibrary.simpleMessage("双向"),
    "iperfClient": MessageLookupByLibrary.simpleMessage("客户端"),
    "iperfCommands": MessageLookupByLibrary.simpleMessage("官方 iperf3 命令"),
    "iperfConnecting": MessageLookupByLibrary.simpleMessage("正在连接…"),
    "iperfDirection": MessageLookupByLibrary.simpleMessage("方向"),
    "iperfDone": MessageLookupByLibrary.simpleMessage("测试完成"),
    "iperfDuration": MessageLookupByLibrary.simpleMessage("时长"),
    "iperfErrorBusy": MessageLookupByLibrary.simpleMessage(
      "服务器正忙，正在进行其他测试，请稍后重试",
    ),
    "iperfErrorInterrupted": MessageLookupByLibrary.simpleMessage("测试被中断"),
    "iperfErrorListen": MessageLookupByLibrary.simpleMessage("无法启动服务端"),
    "iperfErrorPortInUse": m27,
    "iperfErrorProtocol": MessageLookupByLibrary.simpleMessage(
      "通信异常，对方可能不是 iPerf3 服务端",
    ),
    "iperfErrorRefused": MessageLookupByLibrary.simpleMessage(
      "连接被拒绝，请确认对方已启动 iPerf3 服务端",
    ),
    "iperfErrorServer": m28,
    "iperfErrorTimeout": MessageLookupByLibrary.simpleMessage("连接超时，请检查地址和网络"),
    "iperfErrorUdp": MessageLookupByLibrary.simpleMessage("UDP 握手失败，可能被防火墙拦截"),
    "iperfErrorUnreachable": MessageLookupByLibrary.simpleMessage("无法连接到服务器"),
    "iperfFirewallTip": MessageLookupByLibrary.simpleMessage(
      "如果其他设备连接不上，请在系统防火墙中允许 FastLin 内核的传入连接。",
    ),
    "iperfLostPackets": m29,
    "iperfNoAddress": MessageLookupByLibrary.simpleMessage(
      "未检测到局域网地址，请确认已连接 Wi-Fi 或有线网络",
    ),
    "iperfParallel": MessageLookupByLibrary.simpleMessage("并行"),
    "iperfPeer": MessageLookupByLibrary.simpleMessage("对端"),
    "iperfPort": MessageLookupByLibrary.simpleMessage("端口"),
    "iperfPortInvalid": MessageLookupByLibrary.simpleMessage(
      "请输入 1–65535 之间的端口",
    ),
    "iperfProtocol": MessageLookupByLibrary.simpleMessage("协议"),
    "iperfReady": MessageLookupByLibrary.simpleMessage("输入服务器地址或扫码后开始测试"),
    "iperfReceive": MessageLookupByLibrary.simpleMessage("接收"),
    "iperfResult": MessageLookupByLibrary.simpleMessage("测试结果"),
    "iperfRetest": MessageLookupByLibrary.simpleMessage("重新测试"),
    "iperfRetransmits": MessageLookupByLibrary.simpleMessage("重传"),
    "iperfRtt": MessageLookupByLibrary.simpleMessage("往返延迟"),
    "iperfRunning": MessageLookupByLibrary.simpleMessage("测试中"),
    "iperfScan": MessageLookupByLibrary.simpleMessage("扫码连接"),
    "iperfScanHint": MessageLookupByLibrary.simpleMessage(
      "在另一台设备的 FastLin 中扫码，即可一键连接",
    ),
    "iperfScanInvalid": MessageLookupByLibrary.simpleMessage(
      "这不是 iPerf3 连接二维码",
    ),
    "iperfScanned": m30,
    "iperfSeconds": m31,
    "iperfSend": MessageLookupByLibrary.simpleMessage("发送"),
    "iperfServer": MessageLookupByLibrary.simpleMessage("服务端"),
    "iperfServerListening": m32,
    "iperfServerOff": MessageLookupByLibrary.simpleMessage("服务端未启动"),
    "iperfServerOffHint": MessageLookupByLibrary.simpleMessage(
      "启动后，其他设备扫码或输入本机地址即可连接",
    ),
    "iperfServerStart": MessageLookupByLibrary.simpleMessage("启动服务端"),
    "iperfServerStop": MessageLookupByLibrary.simpleMessage("停止服务端"),
    "iperfServerTip": MessageLookupByLibrary.simpleMessage(
      "服务端只在本页面打开时运行，离开页面后会自动停止；运行期间屏幕保持常亮。",
    ),
    "iperfStart": MessageLookupByLibrary.simpleMessage("开始测试"),
    "iperfStreams": m33,
    "iperfTest": MessageLookupByLibrary.simpleMessage("iPerf3 工具"),
    "iperfTestDesc": MessageLookupByLibrary.simpleMessage(
      "测试局域网内设备之间的带宽，兼容官方 iperf3",
    ),
    "iperfThroughput": MessageLookupByLibrary.simpleMessage("吞吐"),
    "iperfTransferred": MessageLookupByLibrary.simpleMessage("传输量"),
    "iperfUdpUnavailable": MessageLookupByLibrary.simpleMessage(
      "UDP 端口被占用，只能进行 TCP 测试。",
    ),
    "iperfWaiting": MessageLookupByLibrary.simpleMessage("等待客户端连接"),
    "ipv6Desc": MessageLookupByLibrary.simpleMessage("开启后将可以接收 IPv6 流量"),
    "ipv6InboundDesc": MessageLookupByLibrary.simpleMessage("允许 IPv6 入站"),
    "isp": MessageLookupByLibrary.simpleMessage("运营商"),
    "itemsCount": m34,
    "joinGroups": MessageLookupByLibrary.simpleMessage("加入代理组"),
    "just": MessageLookupByLibrary.simpleMessage("刚刚"),
    "keepAliveIntervalDesc": MessageLookupByLibrary.simpleMessage("TCP 保持活动间隔"),
    "keepDockIcon": MessageLookupByLibrary.simpleMessage("常驻DOCK"),
    "keepDockIconDesc": MessageLookupByLibrary.simpleMessage("在 Dock 栏保留应用图标"),
    "key": MessageLookupByLibrary.simpleMessage("键"),
    "lanSharing": MessageLookupByLibrary.simpleMessage("局域网共享"),
    "landingNode": MessageLookupByLibrary.simpleMessage("落地节点"),
    "landingNodeDesc": MessageLookupByLibrary.simpleMessage(
      "经由所选前置代理连接，并加入所选代理组",
    ),
    "language": MessageLookupByLibrary.simpleMessage("语言"),
    "largeRuleSetTip": MessageLookupByLibrary.simpleMessage("规则集较大，会占用更多内存"),
    "lastEdit": MessageLookupByLibrary.simpleMessage("上次编辑"),
    "lastGenerated": MessageLookupByLibrary.simpleMessage("上次生成"),
    "layout": MessageLookupByLibrary.simpleMessage("布局"),
    "leftClickBehavior": MessageLookupByLibrary.simpleMessage("左键点击"),
    "light": MessageLookupByLibrary.simpleMessage("浅色"),
    "limitedUnlock": MessageLookupByLibrary.simpleMessage("仅自制"),
    "lineWrap": MessageLookupByLibrary.simpleMessage("自动换行"),
    "list": MessageLookupByLibrary.simpleMessage("列表"),
    "local": MessageLookupByLibrary.simpleMessage("本地"),
    "localBackupDesc": MessageLookupByLibrary.simpleMessage("备份数据到本地"),
    "localFile": MessageLookupByLibrary.simpleMessage("本地文件"),
    "localPing": MessageLookupByLibrary.simpleMessage("本地 Ping"),
    "localPingAverage": MessageLookupByLibrary.simpleMessage("平均延迟"),
    "localPingBytes": m35,
    "localPingClosed": MessageLookupByLibrary.simpleMessage("端口关闭"),
    "localPingCount": MessageLookupByLibrary.simpleMessage("次数"),
    "localPingDesc": MessageLookupByLibrary.simpleMessage(
      "直连测试 ICMP、TCP、UDP 延迟与丢包",
    ),
    "localPingDone": MessageLookupByLibrary.simpleMessage("Ping 完成"),
    "localPingErrorDenied": MessageLookupByLibrary.simpleMessage(
      "系统不允许发送 ICMP，请改用 TCP 或 UDP Ping",
    ),
    "localPingErrorNetwork": MessageLookupByLibrary.simpleMessage(
      "无法发送 Ping 数据包",
    ),
    "localPingErrorResolve": MessageLookupByLibrary.simpleMessage("无法解析该域名"),
    "localPingFailed": MessageLookupByLibrary.simpleMessage("发送失败"),
    "localPingFrom": m36,
    "localPingGateway": MessageLookupByLibrary.simpleMessage("网关"),
    "localPingListLimit": m37,
    "localPingMax": MessageLookupByLibrary.simpleMessage("最长"),
    "localPingMin": MessageLookupByLibrary.simpleMessage("最短"),
    "localPingReady": MessageLookupByLibrary.simpleMessage("选择目标后开始 Ping"),
    "localPingReceived": MessageLookupByLibrary.simpleMessage("已接收"),
    "localPingResolving": MessageLookupByLibrary.simpleMessage("正在解析"),
    "localPingResult": MessageLookupByLibrary.simpleMessage("Ping 结果"),
    "localPingRttSummary": m38,
    "localPingRunning": MessageLookupByLibrary.simpleMessage("正在 Ping"),
    "localPingSent": MessageLookupByLibrary.simpleMessage("已发送"),
    "localPingSize": MessageLookupByLibrary.simpleMessage("包大小"),
    "localPingStart": MessageLookupByLibrary.simpleMessage("开始 Ping"),
    "localPingStats": m39,
    "localPingSummary": m40,
    "localPingTargetHint": MessageLookupByLibrary.simpleMessage("域名或 IP 地址"),
    "localPingTcpTip": MessageLookupByLibrary.simpleMessage(
      "TCP Ping 测量建立连接的耗时；端口关闭时对方会立即拒绝，同样说明主机可达",
    ),
    "localPingTimeout": MessageLookupByLibrary.simpleMessage("请求超时"),
    "localPingUdpTip": MessageLookupByLibrary.simpleMessage(
      "端口 53 会发送 DNS 查询并等待应答；其他端口大多不会回应，超时不代表不通",
    ),
    "localPingUnreachable": MessageLookupByLibrary.simpleMessage("目标不可达"),
    "localRecoveryDesc": MessageLookupByLibrary.simpleMessage("通过文件恢复数据"),
    "locate": MessageLookupByLibrary.simpleMessage("定位"),
    "lockProxy": MessageLookupByLibrary.simpleMessage("锁定节点"),
    "log": MessageLookupByLibrary.simpleMessage("日志"),
    "logAiSearch": MessageLookupByLibrary.simpleMessage("AI 搜索"),
    "logLevel": MessageLookupByLibrary.simpleMessage("日志等级"),
    "logLevelDebugHint": m41,
    "logcat": MessageLookupByLibrary.simpleMessage("日志捕获"),
    "logcatDesc": MessageLookupByLibrary.simpleMessage("开启后将会显示日志入口"),
    "logs": MessageLookupByLibrary.simpleMessage("日志"),
    "logsDesc": MessageLookupByLibrary.simpleMessage("查看日志捕获记录"),
    "logsTest": MessageLookupByLibrary.simpleMessage("日志测试"),
    "loopback": MessageLookupByLibrary.simpleMessage("回环解锁工具"),
    "loopbackDesc": MessageLookupByLibrary.simpleMessage("用于 UWP 回环解锁"),
    "loopbackProtection": MessageLookupByLibrary.simpleMessage("回环保护"),
    "loopbackProtectionDesc": MessageLookupByLibrary.simpleMessage(
      "阻断网络错误引起的回环流量",
    ),
    "loose": MessageLookupByLibrary.simpleMessage("宽松"),
    "managedMode": MessageLookupByLibrary.simpleMessage("托管模式"),
    "managedModeDesc": MessageLookupByLibrary.simpleMessage("使用内置脚本生成代理组与规则"),
    "managedNodeTip": MessageLookupByLibrary.simpleMessage("地区组不存在时按普通节点使用"),
    "managedOptions": MessageLookupByLibrary.simpleMessage("默认选项"),
    "managedOptionsDesc": m42,
    "manualInput": MessageLookupByLibrary.simpleMessage("手动输入"),
    "manualRefreshIp": MessageLookupByLibrary.simpleMessage("重新获取 IP"),
    "maximize": MessageLookupByLibrary.simpleMessage("最大化"),
    "mediaBatchAll": MessageLookupByLibrary.simpleMessage("全部节点"),
    "mediaBatchAllDesc": MessageLookupByLibrary.simpleMessage(
      "检测所有节点，不含 DIRECT",
    ),
    "mediaBatchGroup": MessageLookupByLibrary.simpleMessage("检测"),
    "mediaBatchNoNodes": MessageLookupByLibrary.simpleMessage("没有可检测的节点"),
    "mediaBatchScope": MessageLookupByLibrary.simpleMessage("选择检测范围"),
    "mediaBatchSummary": m43,
    "mediaBatchTest": MessageLookupByLibrary.simpleMessage("节点批量检测"),
    "mediaUnlock": MessageLookupByLibrary.simpleMessage("连通性测试"),
    "mediaUnlockColorfulIcons": MessageLookupByLibrary.simpleMessage(
      "默认显示彩色 ICON 图标",
    ),
    "mediaUnlockDetails": MessageLookupByLibrary.simpleMessage("连通性测试详情"),
    "mediaUnlockDisplaySettings": MessageLookupByLibrary.simpleMessage("显示设置"),
    "mediaUnlockExtraDetails": MessageLookupByLibrary.simpleMessage(
      "返回更多 IP 详细信息",
    ),
    "mediaUnlockMiscSettings": MessageLookupByLibrary.simpleMessage("杂项设置"),
    "mediaUnlockMoreStreamingPlatforms": MessageLookupByLibrary.simpleMessage(
      "更多流媒体解锁项目",
    ),
    "mediaUnlockPinnedSettingsDesc": MessageLookupByLibrary.simpleMessage(
      "可选 3 个在小部件常驻展示的项目",
    ),
    "mediaUnlockRefreshByCategory": MessageLookupByLibrary.simpleMessage(
      "根据当前分组状态局部刷新",
    ),
    "mediaUnlockRefreshOnNodeChange": MessageLookupByLibrary.simpleMessage(
      "节点变化时自动刷新检测",
    ),
    "mediaUnlockSelectLimit": MessageLookupByLibrary.simpleMessage(
      "最多只能选择 3 个项目",
    ),
    "mediaUnlocked": MessageLookupByLibrary.simpleMessage("已解锁"),
    "memoryAlreadyOptimal": MessageLookupByLibrary.simpleMessage("内存已处于最佳状态"),
    "memoryAndRuntime": MessageLookupByLibrary.simpleMessage("内存与运行时"),
    "memoryFreed": m44,
    "memoryInfo": MessageLookupByLibrary.simpleMessage("内存信息"),
    "memoryInfoDesc": MessageLookupByLibrary.simpleMessage(
      "当前内存信息数值显示为内核运行时的动态堆栈内存占用，非完整 App 内存统计，仅供参考。",
    ),
    "mergeProfile": MessageLookupByLibrary.simpleMessage("订阅合并"),
    "mergeProfileDesc": MessageLookupByLibrary.simpleMessage(
      "将多个订阅合并，统一管理分流配置",
    ),
    "mergeProfileUnavailable": MessageLookupByLibrary.simpleMessage(
      "至少需要两个配置才能合并",
    ),
    "merged": MessageLookupByLibrary.simpleMessage("已合并"),
    "mergedSubscriptionName": m45,
    "messageTest": MessageLookupByLibrary.simpleMessage("消息测试"),
    "messageTestTip": MessageLookupByLibrary.simpleMessage("这是一条消息。"),
    "min": MessageLookupByLibrary.simpleMessage("最小"),
    "minimize": MessageLookupByLibrary.simpleMessage("最小化"),
    "minimizeOnExit": MessageLookupByLibrary.simpleMessage("退出最小化"),
    "minimizeOnExitDesc": MessageLookupByLibrary.simpleMessage("修改系统默认退出事件"),
    "minutes": m46,
    "mixedPort": MessageLookupByLibrary.simpleMessage("混合端口"),
    "mode": MessageLookupByLibrary.simpleMessage("模式"),
    "monochromeScheme": MessageLookupByLibrary.simpleMessage("单色"),
    "months": m47,
    "more": MessageLookupByLibrary.simpleMessage("查看"),
    "moreIpInfo": MessageLookupByLibrary.simpleMessage("更多 IP 信息"),
    "mrsCopyUrl": MessageLookupByLibrary.simpleMessage("复制链接 URL"),
    "mrsLookup": MessageLookupByLibrary.simpleMessage("MRS 速查"),
    "mrsLookupDesc": MessageLookupByLibrary.simpleMessage(
      "快速查询域名或 IP 所属的 GEO / RULE-SET 规则集",
    ),
    "mrsLookupHint": MessageLookupByLibrary.simpleMessage("输入域名或 IP"),
    "mrsMissing": MessageLookupByLibrary.simpleMessage("未找到内置的 BundleMRS"),
    "mrsNoMatch": MessageLookupByLibrary.simpleMessage("未匹配到任何规则集"),
    "mrsPrepareFailed": MessageLookupByLibrary.simpleMessage("规则集数据加载失败"),
    "mrsReferenced": MessageLookupByLibrary.simpleMessage("使用中"),
    "mrsResolveDns": MessageLookupByLibrary.simpleMessage("使用 DNS 规则解析域名"),
    "mrsResolveDnsDesc": MessageLookupByLibrary.simpleMessage(
      "开启后，针对域名按当前 DNS 配置解析出 IP 并进行匹配",
    ),
    "mrsRules": m48,
    "mrsTapAction": MessageLookupByLibrary.simpleMessage("自定义点击行为"),
    "mrsVia": m49,
    "mrsViewRules": MessageLookupByLibrary.simpleMessage("查看规则列表"),
    "name": MessageLookupByLibrary.simpleMessage("名称"),
    "nameSort": MessageLookupByLibrary.simpleMessage("按名称排序"),
    "natCopyResult": MessageLookupByLibrary.simpleMessage("复制结果"),
    "natDescBlocked": MessageLookupByLibrary.simpleMessage(
      "没有收到 STUN 响应：UDP 可能被防火墙、运营商或出站节点阻断。",
    ),
    "natDescCone": MessageLookupByLibrary.simpleMessage(
      "大部分 P2P 和联机都能正常使用。当前服务器无法细分是 NAT1–3 中的哪一种，换个服务器可以测得更准。",
    ),
    "natDescFullCone": MessageLookupByLibrary.simpleMessage(
      "NAT1：任何外部主机都可以连入，P2P、联机游戏与语音通话最友好。",
    ),
    "natDescOpen": MessageLookupByLibrary.simpleMessage(
      "没有 NAT，外部可直接访问本机，P2P 与联机体验最佳。",
    ),
    "natDescPortRestricted": MessageLookupByLibrary.simpleMessage(
      "NAT3：仅限你联系过的地址和端口回连，部分 P2P 与联机可能需要中继。",
    ),
    "natDescRestricted": MessageLookupByLibrary.simpleMessage(
      "NAT2：只有你主动联系过的地址才能回连，大多数 P2P 与游戏可正常使用。",
    ),
    "natDescSymmetric": MessageLookupByLibrary.simpleMessage(
      "NAT4：每个目标使用不同的映射端口，P2P 直连很难成功，通常需要中继。",
    ),
    "natDescUnknown": MessageLookupByLibrary.simpleMessage("无法判断 NAT 类型。"),
    "natErrorUnavailable": MessageLookupByLibrary.simpleMessage(
      "无法连接 STUN 服务器",
    ),
    "natErrorUnsupported": MessageLookupByLibrary.simpleMessage("当前出站不支持 UDP"),
    "natExternalIp": MessageLookupByLibrary.simpleMessage("外部 IP"),
    "natExternalPort": MessageLookupByLibrary.simpleMessage("外部端口"),
    "natFiltering": MessageLookupByLibrary.simpleMessage("过滤行为"),
    "natLocalIp": MessageLookupByLibrary.simpleMessage("本地 IP"),
    "natMapping": MessageLookupByLibrary.simpleMessage("映射行为"),
    "natMappingAddress": MessageLookupByLibrary.simpleMessage("地址相关"),
    "natMappingAddressPort": MessageLookupByLibrary.simpleMessage("地址和端口相关"),
    "natMappingDependent": MessageLookupByLibrary.simpleMessage("目标相关"),
    "natMappingIndependent": MessageLookupByLibrary.simpleMessage("端点无关"),
    "natPhaseBinding": MessageLookupByLibrary.simpleMessage("绑定"),
    "natPhaseFiltering": MessageLookupByLibrary.simpleMessage("过滤"),
    "natPhaseMapping": MessageLookupByLibrary.simpleMessage("映射"),
    "natPortPreserve": MessageLookupByLibrary.simpleMessage("端口保持"),
    "natPreserved": MessageLookupByLibrary.simpleMessage("保持"),
    "natProxyTip": MessageLookupByLibrary.simpleMessage(
      "经代理检测时，结果反映的是出站节点一侧的 NAT，而不是本机网络。",
    ),
    "natRandomized": MessageLookupByLibrary.simpleMessage("随机"),
    "natReady": MessageLookupByLibrary.simpleMessage("点击下方按钮开始检测"),
    "natResult": MessageLookupByLibrary.simpleMessage("检测结果"),
    "natRetest": MessageLookupByLibrary.simpleMessage("重新检测"),
    "natServer": MessageLookupByLibrary.simpleMessage("STUN 服务器"),
    "natServerCustom": MessageLookupByLibrary.simpleMessage("自定义服务器"),
    "natServerHint": MessageLookupByLibrary.simpleMessage(
      "主机:端口，例如 stun.example.com:3478",
    ),
    "natServerInvalid": MessageLookupByLibrary.simpleMessage("请输入有效的 主机:端口"),
    "natStart": MessageLookupByLibrary.simpleMessage("开始检测"),
    "natTest": MessageLookupByLibrary.simpleMessage("NAT 检测"),
    "natTestDesc": MessageLookupByLibrary.simpleMessage(
      "检测 NAT 类型、外部地址与 UDP 连通性",
    ),
    "natType": MessageLookupByLibrary.simpleMessage("NAT 类型"),
    "natTypeBlocked": MessageLookupByLibrary.simpleMessage("UDP 被阻断"),
    "natTypeCone": MessageLookupByLibrary.simpleMessage("圆锥型 NAT"),
    "natTypeFullCone": MessageLookupByLibrary.simpleMessage("完全圆锥型 NAT"),
    "natTypeOpen": MessageLookupByLibrary.simpleMessage("公网直连"),
    "natTypePortRestricted": MessageLookupByLibrary.simpleMessage(
      "端口受限圆锥型 NAT",
    ),
    "natTypeRestricted": MessageLookupByLibrary.simpleMessage("受限圆锥型 NAT"),
    "natTypeSymmetric": MessageLookupByLibrary.simpleMessage("对称型 NAT"),
    "natTypeUnknown": MessageLookupByLibrary.simpleMessage("未知"),
    "navBarHapticFeedback": MessageLookupByLibrary.simpleMessage("动效反馈"),
    "navBarHapticFeedbackDesc": MessageLookupByLibrary.simpleMessage(
      "开启更多的动画触感反馈",
    ),
    "navConnections": MessageLookupByLibrary.simpleMessage("连接"),
    "navTools": MessageLookupByLibrary.simpleMessage("更多"),
    "network": MessageLookupByLibrary.simpleMessage("网络"),
    "networkDesc": MessageLookupByLibrary.simpleMessage("修改网络相关设置"),
    "networkDetection": MessageLookupByLibrary.simpleMessage("网络检测"),
    "networkErrorRetryLater": MessageLookupByLibrary.simpleMessage(
      "网络异常，请稍后再试",
    ),
    "networkFix": MessageLookupByLibrary.simpleMessage("网络修复"),
    "networkFixDesc": MessageLookupByLibrary.simpleMessage("修复系统网络检测地球图标问题"),
    "networkInterface": MessageLookupByLibrary.simpleMessage("网卡选择"),
    "networkMatch": MessageLookupByLibrary.simpleMessage("网络匹配"),
    "networkMatchHint": MessageLookupByLibrary.simpleMessage(
      "输入 IP、CIDR 或 Gateway:IP/CIDR",
    ),
    "networkSpeed": MessageLookupByLibrary.simpleMessage("网络速度"),
    "networkSpeedNotification": MessageLookupByLibrary.simpleMessage("网速通知"),
    "networkSpeedNotificationDesc": MessageLookupByLibrary.simpleMessage(
      "在通知栏显示网速和订阅信息",
    ),
    "networkType": MessageLookupByLibrary.simpleMessage("网络类型"),
    "neutralScheme": MessageLookupByLibrary.simpleMessage("中性"),
    "newLogsCount": m50,
    "noAnimation": MessageLookupByLibrary.simpleMessage("默认"),
    "noBackupFileFound": MessageLookupByLibrary.simpleMessage("未找到备份文件"),
    "noData": MessageLookupByLibrary.simpleMessage("暂无数据"),
    "noHotKey": MessageLookupByLibrary.simpleMessage("暂无快捷键"),
    "noIcon": MessageLookupByLibrary.simpleMessage("无图标"),
    "noInfo": MessageLookupByLibrary.simpleMessage("暂无信息"),
    "noMatchedLogs": MessageLookupByLibrary.simpleMessage("没有符合条件的日志"),
    "noMoreInfoDesc": MessageLookupByLibrary.simpleMessage("暂无更多信息"),
    "noNetwork": MessageLookupByLibrary.simpleMessage("无网络"),
    "noNetworkApp": MessageLookupByLibrary.simpleMessage("无网络应用"),
    "noNodePrefix": MessageLookupByLibrary.simpleMessage("不加前缀"),
    "noProxy": MessageLookupByLibrary.simpleMessage("暂无代理"),
    "noProxyDesc": MessageLookupByLibrary.simpleMessage("请创建配置或者添加有效配置文件"),
    "noResolve": MessageLookupByLibrary.simpleMessage("不解析 IP"),
    "noStatusAvailable": MessageLookupByLibrary.simpleMessage("未获取到状态"),
    "noUsageData": MessageLookupByLibrary.simpleMessage("无用量统计"),
    "node": MessageLookupByLibrary.simpleMessage("节点"),
    "nodeClipboardDesc": MessageLookupByLibrary.simpleMessage(
      "支持分享链接、Base64 与 YAML 片段",
    ),
    "nodeExclusion": MessageLookupByLibrary.simpleMessage("节点排除"),
    "nodeExclusionDesc": MessageLookupByLibrary.simpleMessage("排除所有匹配到的节点"),
    "nodeExclusionPlaceholder": MessageLookupByLibrary.simpleMessage(
      "HK|香港|🇭🇰",
    ),
    "nodeFileDesc": MessageLookupByLibrary.simpleMessage("读取文件中的节点"),
    "nodeImportEmpty": MessageLookupByLibrary.simpleMessage("未找到有效节点"),
    "nodeImportSkipped": m51,
    "nodeManualDesc": MessageLookupByLibrary.simpleMessage(
      "支持分享链接、Base64 与 YAML",
    ),
    "nodePrefix": MessageLookupByLibrary.simpleMessage("节点前缀"),
    "nodePrefixValue": m52,
    "nodeQrcodeDesc": MessageLookupByLibrary.simpleMessage("扫描节点分享二维码"),
    "nodeRole": MessageLookupByLibrary.simpleMessage("节点用途"),
    "nodeShareUri": MessageLookupByLibrary.simpleMessage("节点分享(URI)"),
    "nodeTestFailed": MessageLookupByLibrary.simpleMessage("不可用"),
    "nodesSort": MessageLookupByLibrary.simpleMessage("节点排序"),
    "nonManagedRuleTip": MessageLookupByLibrary.simpleMessage(
      "非托管模式下，仅针对当前配置生效",
    ),
    "none": MessageLookupByLibrary.simpleMessage("无"),
    "notRecommended": MessageLookupByLibrary.simpleMessage("不推荐"),
    "notSelectedTip": MessageLookupByLibrary.simpleMessage("当前代理组无法选中"),
    "notUnlocked": MessageLookupByLibrary.simpleMessage("未解锁"),
    "notificationHighPriority": MessageLookupByLibrary.simpleMessage("高优先级"),
    "notificationHighPriorityDesc": MessageLookupByLibrary.simpleMessage(
      "调整当前通知栏为前台高优先级",
    ),
    "notificationHighPriorityTip": MessageLookupByLibrary.simpleMessage(
      "高优先级通知在有些定制系统上可以缓解后台核心保活的问题，如果你的 VPN 服务当前运行正常，这个选项建议继续保持关闭，确定要开启吗",
    ),
    "ntp": MessageLookupByLibrary.simpleMessage("NTP"),
    "ntpDesc": MessageLookupByLibrary.simpleMessage("使用 NTP 时间服务"),
    "ntpInterval": MessageLookupByLibrary.simpleMessage("更新时间"),
    "ntpPort": MessageLookupByLibrary.simpleMessage("端口"),
    "ntpServer": MessageLookupByLibrary.simpleMessage("服务器"),
    "ntpStatus": MessageLookupByLibrary.simpleMessage("状态"),
    "ntpStatusDesc": MessageLookupByLibrary.simpleMessage("开启 NTP 时间服务"),
    "nullNodeDesc": MessageLookupByLibrary.simpleMessage("没有节点，请先添加节点"),
    "nullProfileDesc": MessageLookupByLibrary.simpleMessage("没有配置文件,请先添加配置文件"),
    "nullTip": m53,
    "nullUdpConnections": MessageLookupByLibrary.simpleMessage("暂无 UDP 连接"),
    "numberRangeInvalid": m54,
    "numberTip": m55,
    "oneColumn": MessageLookupByLibrary.simpleMessage("一列"),
    "onlinePanel": MessageLookupByLibrary.simpleMessage("在线面板"),
    "onlyIcon": MessageLookupByLibrary.simpleMessage("仅图标"),
    "onlyOtherApps": MessageLookupByLibrary.simpleMessage("仅第三方应用"),
    "onlyShow": m56,
    "onlyStatisticsProxy": MessageLookupByLibrary.simpleMessage("代理流量统计"),
    "onlyStatisticsProxyDesc": MessageLookupByLibrary.simpleMessage(
      "开启后将只统计代理流量",
    ),
    "openDashboard": MessageLookupByLibrary.simpleMessage("打开 Zashboard"),
    "openRouterAdmin": MessageLookupByLibrary.simpleMessage("打开后台网关"),
    "openSettings": MessageLookupByLibrary.simpleMessage("打开设置"),
    "operatorOrAsn": MessageLookupByLibrary.simpleMessage("归属 / ASN"),
    "options": MessageLookupByLibrary.simpleMessage("选项"),
    "organizationDomain": MessageLookupByLibrary.simpleMessage("组织 / 域名"),
    "other": MessageLookupByLibrary.simpleMessage("其他"),
    "otherContributors": MessageLookupByLibrary.simpleMessage("其他贡献者(随机排序)"),
    "otherSettings": MessageLookupByLibrary.simpleMessage("增强工具"),
    "otherSettingsDesc": MessageLookupByLibrary.simpleMessage("修改增强工具设置"),
    "outboundMode": MessageLookupByLibrary.simpleMessage("出站模式"),
    "override": MessageLookupByLibrary.simpleMessage("覆写"),
    "overrideDesc": MessageLookupByLibrary.simpleMessage("覆写代理相关配置"),
    "overrideDestination": MessageLookupByLibrary.simpleMessage("覆盖目标地址"),
    "overrideDestinationDesc": MessageLookupByLibrary.simpleMessage(
      "使用嗅探结果覆盖连接目标地址",
    ),
    "overrideExperimental": MessageLookupByLibrary.simpleMessage(
      "覆写Experimental",
    ),
    "overrideExperimentalDesc": MessageLookupByLibrary.simpleMessage(
      "开启后将覆盖配置中的实验性配置",
    ),
    "overrideNtp": MessageLookupByLibrary.simpleMessage("覆写 NTP"),
    "overrideNtpDesc": MessageLookupByLibrary.simpleMessage(
      "开启后将覆盖配置中的 NTP 选项",
    ),
    "overrideSniffer": MessageLookupByLibrary.simpleMessage("覆写 Sniffer"),
    "overrideSnifferDesc": MessageLookupByLibrary.simpleMessage(
      "开启后将覆盖配置中的 Sniffer 选项",
    ),
    "overrideTunnel": MessageLookupByLibrary.simpleMessage("覆写 Tunnel"),
    "overrideTunnelDesc": MessageLookupByLibrary.simpleMessage(
      "开启后将覆盖配置中的 Tunnel 选项",
    ),
    "packageListPermissionDenied": MessageLookupByLibrary.simpleMessage(
      "权限被拒绝。没有权限无法访问应用列表。",
    ),
    "packageListPermissionRequired": MessageLookupByLibrary.simpleMessage(
      "此功能需要访问已安装应用列表的权限。是否授予此权限？",
    ),
    "palette": MessageLookupByLibrary.simpleMessage("调色板"),
    "parsePureIp": MessageLookupByLibrary.simpleMessage("解析纯 IP 连接"),
    "parsePureIpDesc": MessageLookupByLibrary.simpleMessage("解析纯 IP 连接"),
    "password": MessageLookupByLibrary.simpleMessage("密码"),
    "paste": MessageLookupByLibrary.simpleMessage("粘贴"),
    "phosphorIcons": MessageLookupByLibrary.simpleMessage("Phosphor 图标"),
    "phosphorIconsDesc": MessageLookupByLibrary.simpleMessage(
      "使用现代简约的 Phosphor 图标",
    ),
    "pianoWave": MessageLookupByLibrary.simpleMessage("琴键律动"),
    "pick": MessageLookupByLibrary.simpleMessage("选择"),
    "pin": MessageLookupByLibrary.simpleMessage("置顶"),
    "pleaseBindWebDAV": MessageLookupByLibrary.simpleMessage("请绑定 WebDAV"),
    "pleaseCloseSystemProxyFirst": MessageLookupByLibrary.simpleMessage(
      "请先关闭系统代理",
    ),
    "pleaseCloseTunFirst": MessageLookupByLibrary.simpleMessage("请先关闭虚拟网卡"),
    "pleaseEnterScriptName": MessageLookupByLibrary.simpleMessage("请输入脚本名称"),
    "pleaseInputAdminPassword": MessageLookupByLibrary.simpleMessage(
      "请输入管理员密码",
    ),
    "pleaseUploadFile": MessageLookupByLibrary.simpleMessage("请上传文件"),
    "pleaseUploadValidQrcode": MessageLookupByLibrary.simpleMessage(
      "请上传有效的二维码",
    ),
    "port": MessageLookupByLibrary.simpleMessage("端口"),
    "portConflictTip": MessageLookupByLibrary.simpleMessage("请输入不同的端口"),
    "portTip": m57,
    "pouringHourGlass": MessageLookupByLibrary.simpleMessage("流沙倾注"),
    "pouringHourGlassRefined": MessageLookupByLibrary.simpleMessage("玉漏凝光"),
    "powerSwitch": MessageLookupByLibrary.simpleMessage("启动开关"),
    "pressKeyboard": MessageLookupByLibrary.simpleMessage("请按下按键"),
    "preview": MessageLookupByLibrary.simpleMessage("预览"),
    "privateIp": MessageLookupByLibrary.simpleMessage("私有 / 局域网 IP 地址"),
    "process": MessageLookupByLibrary.simpleMessage("进程"),
    "processPath": MessageLookupByLibrary.simpleMessage("进程路径"),
    "profile": MessageLookupByLibrary.simpleMessage("配置"),
    "profileAndRules": MessageLookupByLibrary.simpleMessage("配置文件规则"),
    "profileAutoUpdateIntervalInvalidValidationDesc":
        MessageLookupByLibrary.simpleMessage("请输入有效间隔时间格式"),
    "profileAutoUpdateIntervalNullValidationDesc":
        MessageLookupByLibrary.simpleMessage("请输入自动更新间隔时间"),
    "profileHasUpdate": MessageLookupByLibrary.simpleMessage(
      "配置文件已经修改，是否关闭自动更新？",
    ),
    "profileImportFailed": m58,
    "profileNameNullValidationDesc": MessageLookupByLibrary.simpleMessage(
      "请输入配置名称",
    ),
    "profileParseErrorDesc": MessageLookupByLibrary.simpleMessage("配置文件解析错误"),
    "profileSwitchMode": MessageLookupByLibrary.simpleMessage("网络配置切换"),
    "profileUrlInvalidValidationDesc": MessageLookupByLibrary.simpleMessage(
      "请输入有效配置 URL",
    ),
    "profileUrlNullValidationDesc": MessageLookupByLibrary.simpleMessage(
      "请输入配置 URL",
    ),
    "profiles": MessageLookupByLibrary.simpleMessage("配置"),
    "profilesSort": MessageLookupByLibrary.simpleMessage("配置排序"),
    "progress": MessageLookupByLibrary.simpleMessage("进程"),
    "project": MessageLookupByLibrary.simpleMessage("项目"),
    "providers": MessageLookupByLibrary.simpleMessage("提供者"),
    "providersCount": m59,
    "provinceAndCity": MessageLookupByLibrary.simpleMessage("省份 / 城市"),
    "proxies": MessageLookupByLibrary.simpleMessage("代理"),
    "proxiesCount": MessageLookupByLibrary.simpleMessage("代理节点"),
    "proxiesSetting": MessageLookupByLibrary.simpleMessage("代理设置"),
    "proxyChains": MessageLookupByLibrary.simpleMessage("代理链"),
    "proxyGroup": MessageLookupByLibrary.simpleMessage("代理组"),
    "proxyGroupsCount": MessageLookupByLibrary.simpleMessage("代理组"),
    "proxyPort": MessageLookupByLibrary.simpleMessage("代理端口"),
    "proxyPortDesc": MessageLookupByLibrary.simpleMessage("设置 Clash 监听端口"),
    "proxyProviders": MessageLookupByLibrary.simpleMessage("代理提供者"),
    "proxyProvidersCount": MessageLookupByLibrary.simpleMessage("代理集"),
    "pulse": MessageLookupByLibrary.simpleMessage("脉冲律动"),
    "pulsingGrid": MessageLookupByLibrary.simpleMessage("矩阵脉动"),
    "pumpingHeart": MessageLookupByLibrary.simpleMessage("怦然心动"),
    "qrcode": MessageLookupByLibrary.simpleMessage("二维码"),
    "qrcodeDesc": MessageLookupByLibrary.simpleMessage("扫描二维码导入配置文件"),
    "quicGoDisableEcn": MessageLookupByLibrary.simpleMessage("禁用 QUIC 显式拥塞通知"),
    "quicGoDisableEcnDesc": MessageLookupByLibrary.simpleMessage(
      "禁用 QUIC 的显式拥塞通知功能",
    ),
    "quicGoDisableGso": MessageLookupByLibrary.simpleMessage("禁用 QUIC 通用分段卸载"),
    "quicGoDisableGsoDesc": MessageLookupByLibrary.simpleMessage(
      "禁用 QUIC 的通用分段卸载功能",
    ),
    "quicPortSniffer": MessageLookupByLibrary.simpleMessage("QUIC 端口嗅探"),
    "quickResponse": MessageLookupByLibrary.simpleMessage("快速响应"),
    "quickResponseDesc": MessageLookupByLibrary.simpleMessage(
      "网络变化或切换节点时主动断开连接",
    ),
    "rainbowScheme": MessageLookupByLibrary.simpleMessage("彩虹"),
    "realTimeSpeed": MessageLookupByLibrary.simpleMessage("实时速度"),
    "reclaimableMemory": MessageLookupByLibrary.simpleMessage("可回收"),
    "recovery": MessageLookupByLibrary.simpleMessage("恢复"),
    "recoveryAll": MessageLookupByLibrary.simpleMessage("恢复所有数据"),
    "recoveryDecryptedTip": MessageLookupByLibrary.simpleMessage("已使用当前密码解密恢复"),
    "recoveryProfiles": MessageLookupByLibrary.simpleMessage("仅恢复配置文件"),
    "recoveryStrategy": MessageLookupByLibrary.simpleMessage("恢复策略"),
    "recoveryStrategyDesc_compatible": MessageLookupByLibrary.simpleMessage(
      "保留本机已有的配置和脚本，按 ID 合并备份中的内容",
    ),
    "recoveryStrategyDesc_override": MessageLookupByLibrary.simpleMessage(
      "清空本机的配置和脚本，完全替换为备份中的内容",
    ),
    "recoveryStrategy_compatible": MessageLookupByLibrary.simpleMessage("兼容"),
    "recoveryStrategy_override": MessageLookupByLibrary.simpleMessage("覆盖"),
    "recoverySuccess": MessageLookupByLibrary.simpleMessage("恢复成功"),
    "redirPort": MessageLookupByLibrary.simpleMessage("Redir端口"),
    "redo": MessageLookupByLibrary.simpleMessage("重做"),
    "refreshAppList": MessageLookupByLibrary.simpleMessage("刷新应用列表"),
    "refreshAppListConfirm": MessageLookupByLibrary.simpleMessage("是否刷新应用列表？"),
    "regExp": MessageLookupByLibrary.simpleMessage("正则"),
    "regenerate": MessageLookupByLibrary.simpleMessage("重新生成"),
    "regexInvalid": MessageLookupByLibrary.simpleMessage("正则表达式格式错误"),
    "regionGroups": MessageLookupByLibrary.simpleMessage("地区分组"),
    "regionGroupsTip": MessageLookupByLibrary.simpleMessage(
      "没有匹配节点的地区不会生成策略组，未匹配任何地区的节点归入「其他节点」",
    ),
    "regionName": MessageLookupByLibrary.simpleMessage("国家名称"),
    "regionRegex": MessageLookupByLibrary.simpleMessage("匹配正则"),
    "registerWarp": MessageLookupByLibrary.simpleMessage("注册 Cloudflare WARP"),
    "registerWarpDesc": MessageLookupByLibrary.simpleMessage(
      "生成 WireGuard 落地节点",
    ),
    "registerWarpFailed": MessageLookupByLibrary.simpleMessage("WARP 注册失败"),
    "registerWarpTip": m60,
    "regularNode": MessageLookupByLibrary.simpleMessage("常规节点"),
    "regularNodeDesc": MessageLookupByLibrary.simpleMessage("直接连接，加入所选代理组即可"),
    "reject": MessageLookupByLibrary.simpleMessage("拦截"),
    "remainingTraffic": MessageLookupByLibrary.simpleMessage("剩余流量"),
    "remote": MessageLookupByLibrary.simpleMessage("远程"),
    "remoteBackupDesc": MessageLookupByLibrary.simpleMessage("备份数据到 WebDAV"),
    "remoteDestination": MessageLookupByLibrary.simpleMessage("远程目标"),
    "remoteRecoveryDesc": MessageLookupByLibrary.simpleMessage(
      "通过 WebDAV 恢复数据",
    ),
    "remove": MessageLookupByLibrary.simpleMessage("移除"),
    "rename": MessageLookupByLibrary.simpleMessage("重命名"),
    "replace": MessageLookupByLibrary.simpleMessage("替换"),
    "replaceAll": MessageLookupByLibrary.simpleMessage("全部替换"),
    "request": MessageLookupByLibrary.simpleMessage("请求"),
    "reset": MessageLookupByLibrary.simpleMessage("重置"),
    "resetIconCache": MessageLookupByLibrary.simpleMessage("重置图标缓存"),
    "resetIconCacheDesc": MessageLookupByLibrary.simpleMessage(
      "是否重置本地图标缓存？这个操作是安全的，因为应用会再次从远程链接自动获取。",
    ),
    "resetTip": MessageLookupByLibrary.simpleMessage("确定要重置吗?"),
    "resources": MessageLookupByLibrary.simpleMessage("外部资源"),
    "resourcesDesc": MessageLookupByLibrary.simpleMessage("查看外部资源或规则集合"),
    "restart": MessageLookupByLibrary.simpleMessage("重启"),
    "restartApp": MessageLookupByLibrary.simpleMessage("重启软件"),
    "restartCoreDesc": MessageLookupByLibrary.simpleMessage("是否手动重启内核？"),
    "restartCoreTitle": MessageLookupByLibrary.simpleMessage("重启内核"),
    "restartTip": MessageLookupByLibrary.simpleMessage("重启 TUN 后生效"),
    "restore": MessageLookupByLibrary.simpleMessage("还原"),
    "restoreBundled": MessageLookupByLibrary.simpleMessage("恢复内置版本"),
    "retry": MessageLookupByLibrary.simpleMessage("重试"),
    "rightClickBehavior": MessageLookupByLibrary.simpleMessage("右键点击"),
    "ring": MessageLookupByLibrary.simpleMessage("光环流转"),
    "ripple": MessageLookupByLibrary.simpleMessage("水波荡漾"),
    "rotatingCircle": MessageLookupByLibrary.simpleMessage("单圆自转"),
    "rotatingPlain": MessageLookupByLibrary.simpleMessage("灵板翻转"),
    "routeAddCount": m61,
    "routeCategoryAi": MessageLookupByLibrary.simpleMessage("AI"),
    "routeCategoryDeveloper": MessageLookupByLibrary.simpleMessage("开发工具"),
    "routeCategoryFinance": MessageLookupByLibrary.simpleMessage("金融支付"),
    "routeCategoryGaming": MessageLookupByLibrary.simpleMessage("游戏"),
    "routeCategorySocial": MessageLookupByLibrary.simpleMessage("社交通讯"),
    "routeCategoryStreaming": MessageLookupByLibrary.simpleMessage("流媒体"),
    "routeCategoryTech": MessageLookupByLibrary.simpleMessage("科技平台"),
    "routeNameInvalid": MessageLookupByLibrary.simpleMessage("名称不能包含逗号或换行"),
    "routeRemoveCount": m62,
    "routeTarget": MessageLookupByLibrary.simpleMessage("默认出口"),
    "routeTrace": MessageLookupByLibrary.simpleMessage("路由追踪"),
    "routeTraceChain": MessageLookupByLibrary.simpleMessage("代理链"),
    "routeTraceCheckedRules": MessageLookupByLibrary.simpleMessage("已检查的规则"),
    "routeTraceDesc": MessageLookupByLibrary.simpleMessage(
      "查看域名或 IP 在内核中的 DNS 与规则匹配过程",
    ),
    "routeTraceDns": MessageLookupByLibrary.simpleMessage("DNS 解析"),
    "routeTraceDnsBy": m63,
    "routeTraceDnsIp": MessageLookupByLibrary.simpleMessage("目标本身是 IP，无需解析"),
    "routeTraceDnsSkipped": MessageLookupByLibrary.simpleMessage(
      "匹配过程中无需解析 IP",
    ),
    "routeTraceFinal": MessageLookupByLibrary.simpleMessage("最终出站"),
    "routeTraceHint": MessageLookupByLibrary.simpleMessage("输入域名、IP 或网址"),
    "routeTraceHostsHit": m64,
    "routeTraceInput": MessageLookupByLibrary.simpleMessage("目标"),
    "routeTraceModeDirect": MessageLookupByLibrary.simpleMessage("直连模式：所有流量直连"),
    "routeTraceModeGlobal": MessageLookupByLibrary.simpleMessage(
      "全局模式：所有流量走 GLOBAL",
    ),
    "routeTraceNoMatch": MessageLookupByLibrary.simpleMessage("没有规则命中，按直连处理"),
    "routeTraceRules": MessageLookupByLibrary.simpleMessage("规则匹配"),
    "routeTraceRulesSummary": m65,
    "routeTraceRulesTotal": m66,
    "routeTraceSkipMissing": MessageLookupByLibrary.simpleMessage("目标不存在，跳过"),
    "routeTraceSkipPass": MessageLookupByLibrary.simpleMessage("PASS 跳过"),
    "routeTraceSkipUdp": MessageLookupByLibrary.simpleMessage("不支持 UDP，跳过"),
    "routeTraceStopped": MessageLookupByLibrary.simpleMessage("代理未启动，无法模拟内核路由"),
    "routeTraceTrigger": MessageLookupByLibrary.simpleMessage("触发解析"),
    "routeTraceTruncated": MessageLookupByLibrary.simpleMessage("仅显示前 3000 条"),
    "routeTraceUdpUnsupported": MessageLookupByLibrary.simpleMessage(
      "该出站不支持 UDP",
    ),
    "routeTraceViewRules": MessageLookupByLibrary.simpleMessage("查看已检查的规则"),
    "rule": MessageLookupByLibrary.simpleMessage("规则"),
    "ruleAdded": MessageLookupByLibrary.simpleMessage("规则已添加"),
    "ruleCount": m67,
    "ruleCountIncluded": m68,
    "ruleHits": MessageLookupByLibrary.simpleMessage("规则命中"),
    "ruleProviders": MessageLookupByLibrary.simpleMessage("规则提供者"),
    "ruleProvidersCount": MessageLookupByLibrary.simpleMessage("规则集"),
    "ruleSets": MessageLookupByLibrary.simpleMessage("规则集"),
    "ruleSort": MessageLookupByLibrary.simpleMessage("规则排序"),
    "ruleTarget": MessageLookupByLibrary.simpleMessage("规则目标"),
    "ruleTypeDesc": m69,
    "ruleTypeName": m70,
    "rulesCount": MessageLookupByLibrary.simpleMessage("路由规则"),
    "runTime": MessageLookupByLibrary.simpleMessage("启动时间"),
    "runningMode": MessageLookupByLibrary.simpleMessage("运行模式"),
    "runtimeConfig": MessageLookupByLibrary.simpleMessage("运行时配置"),
    "save": MessageLookupByLibrary.simpleMessage("保存"),
    "saveChanges": MessageLookupByLibrary.simpleMessage("是否保存更改？"),
    "saveTip": MessageLookupByLibrary.simpleMessage("确定要保存吗？"),
    "script": MessageLookupByLibrary.simpleMessage("覆写脚本"),
    "scriptDesc": MessageLookupByLibrary.simpleMessage("配置 JavaScript 覆写脚本"),
    "scriptOtherOptions": MessageLookupByLibrary.simpleMessage("其他设置"),
    "search": MessageLookupByLibrary.simpleMessage("搜索"),
    "searchIcons": MessageLookupByLibrary.simpleMessage("搜索图标"),
    "searchRuleSets": MessageLookupByLibrary.simpleMessage("搜索规则集"),
    "searchServices": MessageLookupByLibrary.simpleMessage("搜索服务名称"),
    "seconds": MessageLookupByLibrary.simpleMessage("秒"),
    "secretCopied": MessageLookupByLibrary.simpleMessage("密码已复制到剪贴板"),
    "selectAll": MessageLookupByLibrary.simpleMessage("全选"),
    "selectBackupVersion": MessageLookupByLibrary.simpleMessage("选择备份版本"),
    "selectIcon": MessageLookupByLibrary.simpleMessage("选择图标"),
    "selected": MessageLookupByLibrary.simpleMessage("已选择"),
    "selectedCountTitle": m71,
    "serviceReady": MessageLookupByLibrary.simpleMessage("服务已就绪"),
    "serviceRunning": MessageLookupByLibrary.simpleMessage("服务正在运行中"),
    "setcapFailedFallback": MessageLookupByLibrary.simpleMessage(
      "无法授予文件能力，已回退到 setuid",
    ),
    "setcapNotInstalledFallback": MessageLookupByLibrary.simpleMessage(
      "未安装 setcap，已回退到 setuid",
    ),
    "settings": MessageLookupByLibrary.simpleMessage("设置"),
    "sharedAddress": MessageLookupByLibrary.simpleMessage("共享地址"),
    "show": MessageLookupByLibrary.simpleMessage("显示"),
    "showHiddenItems": MessageLookupByLibrary.simpleMessage("显示隐藏策略"),
    "showMenu": MessageLookupByLibrary.simpleMessage("打开菜单"),
    "showPanel": MessageLookupByLibrary.simpleMessage("显示窗口"),
    "showStartSwitch": MessageLookupByLibrary.simpleMessage("联动开关"),
    "showStartSwitchDesc": MessageLookupByLibrary.simpleMessage("首页显示独立的开关按钮"),
    "shrink": MessageLookupByLibrary.simpleMessage("紧凑"),
    "sidebarFlyout": MessageLookupByLibrary.simpleMessage("悬浮面板"),
    "sidebarFlyoutDelay": MessageLookupByLibrary.simpleMessage("触发延迟"),
    "sidebarFlyoutDesc": MessageLookupByLibrary.simpleMessage("显示侧边栏悬浮卡片设置"),
    "sidebarFlyoutEntries": MessageLookupByLibrary.simpleMessage("显示入口"),
    "sidebarFlyoutOutsideTools": MessageLookupByLibrary.simpleMessage(
      "仅在非「更多」页面展示",
    ),
    "silentLaunch": MessageLookupByLibrary.simpleMessage("静默启动"),
    "silentLaunchDesc": MessageLookupByLibrary.simpleMessage("不打开软件直接在后台启动"),
    "size": MessageLookupByLibrary.simpleMessage("尺寸"),
    "skipCertVerify": MessageLookupByLibrary.simpleMessage("跳过证书验证"),
    "skipDomain": MessageLookupByLibrary.simpleMessage("跳过域名"),
    "skipDstAddress": MessageLookupByLibrary.simpleMessage("跳过目标 IP"),
    "skipLocalAuth": MessageLookupByLibrary.simpleMessage("跳过本机验证"),
    "skipLocalAuthDesc": MessageLookupByLibrary.simpleMessage("允许本机免密访问代理"),
    "skipSrcAddress": MessageLookupByLibrary.simpleMessage("跳过来源 IP"),
    "slow": MessageLookupByLibrary.simpleMessage("慢"),
    "smartAutoStop": MessageLookupByLibrary.simpleMessage("智能启停"),
    "smartAutoStopDesc": MessageLookupByLibrary.simpleMessage("连接指定网络后停止代理服务"),
    "smartAutoStopServiceRunning": MessageLookupByLibrary.simpleMessage(
      "智能启停服务运行中",
    ),
    "smartDelayLaunch": MessageLookupByLibrary.simpleMessage("智能延迟"),
    "smartDelayLaunchDesc": MessageLookupByLibrary.simpleMessage(
      "仅在网络成功连接以后启动",
    ),
    "sniffHost": MessageLookupByLibrary.simpleMessage("嗅探域名"),
    "sniffer": MessageLookupByLibrary.simpleMessage("Sniffer"),
    "snifferAddressHint": MessageLookupByLibrary.simpleMessage("每行一个地址"),
    "snifferDesc": MessageLookupByLibrary.simpleMessage("修改域名嗅探配置"),
    "snifferDomainHint": MessageLookupByLibrary.simpleMessage("每行一个域名"),
    "snifferPorts": MessageLookupByLibrary.simpleMessage("端口"),
    "snifferPortsHint": MessageLookupByLibrary.simpleMessage(
      "例如: 80, 8080-8880",
    ),
    "snifferStatus": MessageLookupByLibrary.simpleMessage("状态"),
    "snifferStatusDesc": MessageLookupByLibrary.simpleMessage("开启嗅探服务设置"),
    "socksPort": MessageLookupByLibrary.simpleMessage("Socks端口"),
    "sort": MessageLookupByLibrary.simpleMessage("排序"),
    "source": MessageLookupByLibrary.simpleMessage("来源"),
    "sourceIp": MessageLookupByLibrary.simpleMessage("源 IP"),
    "specialProxy": MessageLookupByLibrary.simpleMessage("特殊代理"),
    "specialRules": MessageLookupByLibrary.simpleMessage("特殊规则"),
    "speedTest": MessageLookupByLibrary.simpleMessage("网速测试"),
    "speedTestAgain": MessageLookupByLibrary.simpleMessage("重新测速"),
    "speedTestChangeOutbound": MessageLookupByLibrary.simpleMessage("更换出站"),
    "speedTestClearHistoryTip": MessageLookupByLibrary.simpleMessage(
      "确定清空全部测速记录？",
    ),
    "speedTestConnecting": MessageLookupByLibrary.simpleMessage("连接中"),
    "speedTestConnections": MessageLookupByLibrary.simpleMessage("连接方式"),
    "speedTestConnectionsDesc": m72,
    "speedTestCoreStopped": MessageLookupByLibrary.simpleMessage("未启动 · 直连测速"),
    "speedTestCredit": MessageLookupByLibrary.simpleMessage(
      "测速服务器由网络上公开的第三方提供，特别感谢 Apple、Cloudflare 以及 Speedtest by Ookla。",
    ),
    "speedTestDataUsed": MessageLookupByLibrary.simpleMessage("已用流量"),
    "speedTestDuration": MessageLookupByLibrary.simpleMessage("测试时长"),
    "speedTestErrorBlocked": MessageLookupByLibrary.simpleMessage("测速服务不可用"),
    "speedTestErrorBlockedDesc": m73,
    "speedTestErrorNetworkDesc": MessageLookupByLibrary.simpleMessage(
      "请检查出站是否可用后重试",
    ),
    "speedTestErrorRejected": MessageLookupByLibrary.simpleMessage("测速请求被规则拦截"),
    "speedTestErrorRejectedDesc": MessageLookupByLibrary.simpleMessage(
      "当前规则将测速域名指向了 REJECT，可更换出站后重试",
    ),
    "speedTestErrorTimeout": MessageLookupByLibrary.simpleMessage("连接测速服务超时"),
    "speedTestErrorUnavailable": MessageLookupByLibrary.simpleMessage(
      "无法连接测速服务",
    ),
    "speedTestExitNode": MessageLookupByLibrary.simpleMessage("出站节点"),
    "speedTestFollowRules": MessageLookupByLibrary.simpleMessage("跟随规则"),
    "speedTestHistory": MessageLookupByLibrary.simpleMessage("测速记录"),
    "speedTestHistoryEmpty": MessageLookupByLibrary.simpleMessage("暂无测速记录"),
    "speedTestHistoryRetention": MessageLookupByLibrary.simpleMessage(
      "保留 14 天",
    ),
    "speedTestJitter": MessageLookupByLibrary.simpleMessage("抖动"),
    "speedTestLoadedLatency": MessageLookupByLibrary.simpleMessage("负载延迟"),
    "speedTestManual": MessageLookupByLibrary.simpleMessage("手动指定"),
    "speedTestMobileDataTip": MessageLookupByLibrary.simpleMessage(
      "当前正在使用移动数据，一次测速可能消耗数百 MB 流量，是否继续？",
    ),
    "speedTestMultiThread": MessageLookupByLibrary.simpleMessage("多线程"),
    "speedTestOutbound": MessageLookupByLibrary.simpleMessage("出站"),
    "speedTestPacketLoss": MessageLookupByLibrary.simpleMessage("丢包"),
    "speedTestProbing": MessageLookupByLibrary.simpleMessage("正在探测出站…"),
    "speedTestProtocol": MessageLookupByLibrary.simpleMessage("协议"),
    "speedTestProtocolDesc": MessageLookupByLibrary.simpleMessage(
      "HTTP/3 基于 QUIC (UDP)，不可用时依次回退到 HTTP/2、（HTTP/2 不可用时）HTTP/1.1",
    ),
    "speedTestProtocolFallback": m74,
    "speedTestQuality": MessageLookupByLibrary.simpleMessage("网络质量"),
    "speedTestReady": MessageLookupByLibrary.simpleMessage("准备就绪"),
    "speedTestRealtime": MessageLookupByLibrary.simpleMessage("实时速率"),
    "speedTestResponsiveness": MessageLookupByLibrary.simpleMessage("响应性"),
    "speedTestRoute": MessageLookupByLibrary.simpleMessage("路由规则"),
    "speedTestServer": MessageLookupByLibrary.simpleMessage("测速服务器"),
    "speedTestServerAutoDesc": MessageLookupByLibrary.simpleMessage(
      "自动选择 Speedtest 服务器",
    ),
    "speedTestSettings": MessageLookupByLibrary.simpleMessage("测速设置"),
    "speedTestSingleThread": MessageLookupByLibrary.simpleMessage("单线程"),
    "speedTestStart": MessageLookupByLibrary.simpleMessage("开始测速"),
    "speedTestStreams": m75,
    "speedTestSwitchProvider": m76,
    "speedTestUseSystemDns": MessageLookupByLibrary.simpleMessage(
      "使用系统 DNS 解析",
    ),
    "speedTestUseSystemDnsDesc": MessageLookupByLibrary.simpleMessage(
      "开启后，强制使用系统 DNS 来解析选中的测速服务器，这在某些情况下会很有用",
    ),
    "spinningCircle": MessageLookupByLibrary.simpleMessage("圆盘翻转"),
    "spinningLines": MessageLookupByLibrary.simpleMessage("流光旋绕"),
    "squareCircle": MessageLookupByLibrary.simpleMessage("方圆化境"),
    "stackMode": MessageLookupByLibrary.simpleMessage("栈模式"),
    "standard": MessageLookupByLibrary.simpleMessage("标准"),
    "start": MessageLookupByLibrary.simpleMessage("启动"),
    "startSwitchOffLabel": MessageLookupByLibrary.simpleMessage("关闭时文字"),
    "startSwitchOnLabel": MessageLookupByLibrary.simpleMessage("开启时文字"),
    "startSwitchOutlined": MessageLookupByLibrary.simpleMessage("描边"),
    "startSwitchPersonalized": MessageLookupByLibrary.simpleMessage("个性化显示"),
    "startSwitchStyle": MessageLookupByLibrary.simpleMessage("样式"),
    "startSwitchTonal": MessageLookupByLibrary.simpleMessage("淡色"),
    "startTest": MessageLookupByLibrary.simpleMessage("延迟测试"),
    "startVpn": MessageLookupByLibrary.simpleMessage("正在启动"),
    "stop": MessageLookupByLibrary.simpleMessage("停止"),
    "stopVpn": MessageLookupByLibrary.simpleMessage("正在停止"),
    "storeFix": MessageLookupByLibrary.simpleMessage("商店修复"),
    "storeFixDesc": MessageLookupByLibrary.simpleMessage(
      "修复 Google Play 商店下载异常",
    ),
    "strictRoute": MessageLookupByLibrary.simpleMessage("严格路由"),
    "strictRouteDesc": MessageLookupByLibrary.simpleMessage("使用 TUN 严格路由模式"),
    "style": MessageLookupByLibrary.simpleMessage("风格"),
    "subRule": MessageLookupByLibrary.simpleMessage("子规则"),
    "subdomains": MessageLookupByLibrary.simpleMessage("子域名"),
    "submit": MessageLookupByLibrary.simpleMessage("提交"),
    "success": MessageLookupByLibrary.simpleMessage("Success"),
    "switchLabel": MessageLookupByLibrary.simpleMessage("开关"),
    "sync": MessageLookupByLibrary.simpleMessage("同步"),
    "syncAll": MessageLookupByLibrary.simpleMessage("全部同步"),
    "syncDelayAnimation": MessageLookupByLibrary.simpleMessage("同步动画到其他页面"),
    "syncFailed": MessageLookupByLibrary.simpleMessage("同步失败"),
    "system": MessageLookupByLibrary.simpleMessage("系统"),
    "systemApp": MessageLookupByLibrary.simpleMessage("系统应用"),
    "systemDns": MessageLookupByLibrary.simpleMessage("DNS"),
    "systemFont": MessageLookupByLibrary.simpleMessage("系统字体"),
    "systemProxy": MessageLookupByLibrary.simpleMessage("系统代理"),
    "systemProxyDesc": MessageLookupByLibrary.simpleMessage("设置系统代理"),
    "tab": MessageLookupByLibrary.simpleMessage("标签页"),
    "tcpConcurrent": MessageLookupByLibrary.simpleMessage("TCP并发"),
    "tcpConcurrentDesc": MessageLookupByLibrary.simpleMessage("开启后允许 TCP 并发连接"),
    "testUrl": MessageLookupByLibrary.simpleMessage("测试链接"),
    "testing": MessageLookupByLibrary.simpleMessage("检测中"),
    "textScale": MessageLookupByLibrary.simpleMessage("文本缩放"),
    "theme": MessageLookupByLibrary.simpleMessage("主题"),
    "themeColor": MessageLookupByLibrary.simpleMessage("主题色彩"),
    "themeDesc": MessageLookupByLibrary.simpleMessage("设置主题色彩相关"),
    "themeMode": MessageLookupByLibrary.simpleMessage("主题模式"),
    "thisMonth": MessageLookupByLibrary.simpleMessage("本月"),
    "thisWeek": MessageLookupByLibrary.simpleMessage("本周"),
    "threeBounce": MessageLookupByLibrary.simpleMessage("灵珠跃动"),
    "threeColumns": MessageLookupByLibrary.simpleMessage("三列"),
    "threeInOut": MessageLookupByLibrary.simpleMessage("三星舒合"),
    "tight": MessageLookupByLibrary.simpleMessage("紧凑"),
    "time": MessageLookupByLibrary.simpleMessage("时间"),
    "tip": MessageLookupByLibrary.simpleMessage("提示"),
    "titleTooLong": MessageLookupByLibrary.simpleMessage("太长了，最多支持 20 个字符"),
    "tlsPortSniffer": MessageLookupByLibrary.simpleMessage("TLS 端口嗅探"),
    "today": MessageLookupByLibrary.simpleMessage("今日"),
    "toggle": MessageLookupByLibrary.simpleMessage("切换"),
    "tonalSpotScheme": MessageLookupByLibrary.simpleMessage("调性点缀"),
    "tooManyRules": MessageLookupByLibrary.simpleMessage("最多允许 5 个规则"),
    "toolConnectivityDesc": MessageLookupByLibrary.simpleMessage(
      "检测常用服务可用性，支持按节点批量检测",
    ),
    "toolHistoryClear": MessageLookupByLibrary.simpleMessage("清空历史"),
    "toolSpeedTestDesc": MessageLookupByLibrary.simpleMessage("测量下载、上传速度与网络延迟"),
    "toolbox": MessageLookupByLibrary.simpleMessage("工具箱"),
    "toolboxDesc": MessageLookupByLibrary.simpleMessage("网络诊断调试与实用工具"),
    "toolboxEditTip": MessageLookupByLibrary.simpleMessage("点按卡片切换大小，长按拖动调整位置"),
    "toolboxEditTipDesktop": MessageLookupByLibrary.simpleMessage(
      "点击卡片切换大小，拖动调整位置",
    ),
    "toolboxEditTipTv": MessageLookupByLibrary.simpleMessage("选中卡片后按确认键切换大小"),
    "tools": MessageLookupByLibrary.simpleMessage("更多"),
    "totalTraffic": MessageLookupByLibrary.simpleMessage("传输总量"),
    "tproxyPort": MessageLookupByLibrary.simpleMessage("Tproxy端口"),
    "trafficRanking": MessageLookupByLibrary.simpleMessage("排行"),
    "trafficStatsClearTip": MessageLookupByLibrary.simpleMessage(
      "确定清除全部流量统计数据吗？",
    ),
    "trafficStatsDesc": MessageLookupByLibrary.simpleMessage("按日、周、月查看流量具体去向"),
    "trafficStatsDetail": MessageLookupByLibrary.simpleMessage("记录明细"),
    "trafficStatsDetailDesc": MessageLookupByLibrary.simpleMessage(
      "记录域名、进程、节点和规则的去向，关闭后只记录总量",
    ),
    "trafficStatsDisabledTip": MessageLookupByLibrary.simpleMessage(
      "默认关闭，开启后开始记录，数据只保存在本机",
    ),
    "trafficStatsEnable": MessageLookupByLibrary.simpleMessage("启用流量统计"),
    "trafficStatsRetention": MessageLookupByLibrary.simpleMessage("数据保留"),
    "trafficStatsSiteIcon": MessageLookupByLibrary.simpleMessage("显示网站图标"),
    "trafficStatsSiteIconDesc": MessageLookupByLibrary.simpleMessage(
      "优先从对应网站获取图标，网站没有清晰图标时改用 Google 图标服务，并缓存到本地",
    ),
    "trafficTrend": MessageLookupByLibrary.simpleMessage("趋势"),
    "trafficUsage": MessageLookupByLibrary.simpleMessage("流量统计"),
    "trayClickBehavior": MessageLookupByLibrary.simpleMessage("托盘点击行为"),
    "trayEnhancement": MessageLookupByLibrary.simpleMessage("托盘增强"),
    "trayEnhancementDesc": MessageLookupByLibrary.simpleMessage(
      "在系统托盘区菜单中控制代理组",
    ),
    "trayIconInvert": MessageLookupByLibrary.simpleMessage("托盘反转"),
    "trayIconInvertDesc": MessageLookupByLibrary.simpleMessage(
      "针对当前托盘图标颜色取反设置",
    ),
    "tryManualRefresh": MessageLookupByLibrary.simpleMessage("请尝试手动刷新"),
    "tun": MessageLookupByLibrary.simpleMessage("虚拟网卡"),
    "tunDesc": MessageLookupByLibrary.simpleMessage("使用 TUN 接管设备流量"),
    "tunEnableRequireAdmin": MessageLookupByLibrary.simpleMessage(
      "启用 TUN 虚拟网卡功能需要管理员或 Root 权限",
    ),
    "tunVirtualAddress": MessageLookupByLibrary.simpleMessage("TUN 虚拟网卡地址"),
    "tunnel": MessageLookupByLibrary.simpleMessage("Tunnel"),
    "tunnelAddress": MessageLookupByLibrary.simpleMessage("监听地址"),
    "tunnelAddressHint": MessageLookupByLibrary.simpleMessage(
      "例如: 127.0.0.1:6553",
    ),
    "tunnelDesc": MessageLookupByLibrary.simpleMessage("使用流量转发隧道"),
    "tunnelList": MessageLookupByLibrary.simpleMessage("转发列表"),
    "tunnelNetwork": MessageLookupByLibrary.simpleMessage("网络协议"),
    "tunnelNetworkHint": MessageLookupByLibrary.simpleMessage("例如: tcp, udp"),
    "tunnelProxy": MessageLookupByLibrary.simpleMessage("代理名称"),
    "tunnelProxyHint": MessageLookupByLibrary.simpleMessage("例如: proxy (可选)"),
    "tunnelTarget": MessageLookupByLibrary.simpleMessage("目标地址"),
    "tunnelTargetHint": MessageLookupByLibrary.simpleMessage(
      "例如: 114.114.114.114:53",
    ),
    "tvScanImport": MessageLookupByLibrary.simpleMessage("扫码 / 局域网导入"),
    "tvScanImportDesc": MessageLookupByLibrary.simpleMessage("手机扫码或局域网推送配置至电视"),
    "tvScanManualUrl": MessageLookupByLibrary.simpleMessage("手机浏览器也可直接访问："),
    "tvScanNoNetwork": MessageLookupByLibrary.simpleMessage(
      "未检测到可用的局域网，请检查 Wi-Fi",
    ),
    "tvScanStep1": MessageLookupByLibrary.simpleMessage(
      "确保手机与 TV 连接在同一 Wi-Fi 局域网",
    ),
    "tvScanStep2": MessageLookupByLibrary.simpleMessage("使用支持的相机或浏览器以扫描二维码"),
    "tvScanStep3": MessageLookupByLibrary.simpleMessage("在网页中粘贴订阅链接或上传配置并推送"),
    "tvScanSuccess": MessageLookupByLibrary.simpleMessage("配置推送成功，正在导入..."),
    "tvScanWaiting": MessageLookupByLibrary.simpleMessage("等待手机推送配置中..."),
    "twoColumns": MessageLookupByLibrary.simpleMessage("两列"),
    "unableToUpdateCurrentProfileDesc": MessageLookupByLibrary.simpleMessage(
      "无法更新当前配置文件",
    ),
    "unauthorized": MessageLookupByLibrary.simpleMessage("未授权"),
    "undo": MessageLookupByLibrary.simpleMessage("撤销"),
    "unifiedDelay": MessageLookupByLibrary.simpleMessage("统一延迟"),
    "unifiedDelayDesc": MessageLookupByLibrary.simpleMessage("去除握手解析等额外延迟"),
    "unknown": MessageLookupByLibrary.simpleMessage("未知"),
    "unlockProxy": MessageLookupByLibrary.simpleMessage("解除锁定"),
    "unlocked": MessageLookupByLibrary.simpleMessage("已完成"),
    "unnamed": MessageLookupByLibrary.simpleMessage("未命名"),
    "unpin": MessageLookupByLibrary.simpleMessage("取消置顶"),
    "update": MessageLookupByLibrary.simpleMessage("更新"),
    "updateDownloadFailed": MessageLookupByLibrary.simpleMessage("更新下载失败"),
    "updateDownloadStarted": MessageLookupByLibrary.simpleMessage("开始下载新版本"),
    "updateDownloaded": MessageLookupByLibrary.simpleMessage("新版本已下载完成"),
    "updateDownloading": MessageLookupByLibrary.simpleMessage("新版本正在下载中"),
    "updateInstallFailed": MessageLookupByLibrary.simpleMessage("更新安装失败"),
    "updateReadyAppTip": m77,
    "updateTime": MessageLookupByLibrary.simpleMessage("更新时间"),
    "updateTip": MessageLookupByLibrary.simpleMessage("升级提示"),
    "upload": MessageLookupByLibrary.simpleMessage("上传"),
    "uriShareUnsupported": MessageLookupByLibrary.simpleMessage(
      "该节点暂不支持 URI 分享",
    ),
    "url": MessageLookupByLibrary.simpleMessage("URL"),
    "urlDesc": MessageLookupByLibrary.simpleMessage("通过 URL 获取配置文件"),
    "urlTip": m78,
    "usageStyle": MessageLookupByLibrary.simpleMessage("用量样式"),
    "usageStyleBar": MessageLookupByLibrary.simpleMessage("条形"),
    "usageStyleConcentric": MessageLookupByLibrary.simpleMessage("同心环"),
    "usageStyleRing": MessageLookupByLibrary.simpleMessage("圆环"),
    "useCustomUa": MessageLookupByLibrary.simpleMessage("使用指定 UA"),
    "useGlobalScriptOverride": MessageLookupByLibrary.simpleMessage("按配置指定脚本"),
    "userAuth": MessageLookupByLibrary.simpleMessage("用户验证"),
    "userAuthEmpty": MessageLookupByLibrary.simpleMessage("未配置验证用户，局域网连接无需凭据"),
    "username": MessageLookupByLibrary.simpleMessage("用户名"),
    "usernameCannotContainColon": MessageLookupByLibrary.simpleMessage(
      "用户名不能包含冒号",
    ),
    "value": MessageLookupByLibrary.simpleMessage("值"),
    "vibrantScheme": MessageLookupByLibrary.simpleMessage("活力"),
    "view": MessageLookupByLibrary.simpleMessage("查看"),
    "viewChangelog": MessageLookupByLibrary.simpleMessage("查看更新日志"),
    "viewDetailedIpData": MessageLookupByLibrary.simpleMessage("查看详细 IP 数据"),
    "vpnDesc": MessageLookupByLibrary.simpleMessage("修改VPN相关设置"),
    "vpnEnableDesc": MessageLookupByLibrary.simpleMessage(
      "通过 VpnService 自动路由系统流量",
    ),
    "vpnSystemProxyDesc": MessageLookupByLibrary.simpleMessage(
      "为 VpnService 附加 HTTP 代理",
    ),
    "vpnTip": MessageLookupByLibrary.simpleMessage("重启 VPN 后生效"),
    "wakelock": MessageLookupByLibrary.simpleMessage("亮屏锁"),
    "wakelockDescription": MessageLookupByLibrary.simpleMessage(
      "本功能不需要任何特殊权限，因为它仅启用屏幕唤醒锁，而不是任何 CPU 唤醒锁，应用会在后台保持必要的活跃，且屏幕不会自动熄灭，这在一些场景下会很有用",
    ),
    "wanderingCubes": MessageLookupByLibrary.simpleMessage("双角巡游"),
    "wave": MessageLookupByLibrary.simpleMessage("波浪起伏"),
    "waveSpinner": MessageLookupByLibrary.simpleMessage("波澜叠转"),
    "webDAVConfiguration": MessageLookupByLibrary.simpleMessage("WebDAV 配置"),
    "whitelistMode": MessageLookupByLibrary.simpleMessage("白名单模式"),
    "writeToSystem": MessageLookupByLibrary.simpleMessage("写入系统"),
    "writeToSystemDesc": MessageLookupByLibrary.simpleMessage("需要管理员权限"),
    "xattrUnsupportedFallback": MessageLookupByLibrary.simpleMessage(
      "文件系统不支持文件能力（xattr），已回退到 setuid",
    ),
    "years": m79,
  };
}

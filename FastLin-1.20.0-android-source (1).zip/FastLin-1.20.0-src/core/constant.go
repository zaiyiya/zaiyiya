package main

import (
	"encoding/json"
	"net/netip"
	"time"

	"github.com/metacubex/mihomo/adapter/provider"
	P "github.com/metacubex/mihomo/component/process"
	"github.com/metacubex/mihomo/constant"
	"github.com/metacubex/mihomo/log"
	"github.com/metacubex/mihomo/tunnel"
)

type ValidateConfigParams struct {
	Data         string       `json:"data"`
	AgeSecretKey string       `json:"age-secret-key"`
	Setup        *SetupParams `json:"setup"`
}

type DecryptAgeConfigParams struct {
	Data         string `json:"data"`
	AgeSecretKey string `json:"age-secret-key"`
}

type GetConfigParams struct {
	Path           string   `json:"path"`
	AgeSecretKey   string   `json:"age-secret-key"`
	DisabledGroups []string `json:"disabled-groups"`
	Snippet        bool     `json:"snippet"`
}

type ExportConfigParams struct {
	Path            string `json:"path"`
	AgeSecretKey    string `json:"age-secret-key"`
	Output          string `json:"output"`
	ExpandProviders bool   `json:"expand-providers"`
	ProvidersPath   string `json:"providers-path"`
	Refresh         bool   `json:"refresh"`
}

type InitParams struct {
	HomeDir string `json:"home-dir"`
	Version int    `json:"version"`
}

type SetupParams struct {
	SelectedMap    map[string]string `json:"selected-map"`
	TestURL        string            `json:"test-url"`
	ProfilePath    string            `json:"profile-path"`
	AgeSecretKey   string            `json:"age-secret-key"`
	ScriptedConfig string            `json:"scripted-config"`
	Patch          *PatchParams      `json:"patch"`
}

type SetupResult struct {
	Message string `json:"message"`
	Global  string `json:"global"`
}

type UpdateParams struct {
	Tun                *tunSchema         `json:"tun"`
	AllowLan           *bool              `json:"allow-lan"`
	MixedPort          *int               `json:"mixed-port"`
	FindProcessMode    *P.FindProcessMode `json:"find-process-mode"`
	Mode               *tunnel.TunnelMode `json:"mode"`
	LogLevel           *log.LogLevel      `json:"log-level"`
	IPv6               *bool              `json:"ipv6"`
	Sniffing           *bool              `json:"sniffing"`
	TCPConcurrent      *bool              `json:"tcp-concurrent"`
	ExternalController *string            `json:"external-controller"`
	Interface          *string            `json:"interface-name"`
	UnifiedDelay       *bool              `json:"unified-delay"`
}

type tunSchema struct {
	Enable                bool               `yaml:"enable" json:"enable"`
	Device                *string            `yaml:"device" json:"device"`
	Stack                 *constant.TUNStack `yaml:"stack" json:"stack"`
	DNSMode               *string            `yaml:"dns-mode" json:"dns-mode,omitempty"`
	DNSHijack             *[]string          `yaml:"dns-hijack" json:"dns-hijack"`
	AutoRoute             *bool              `yaml:"auto-route" json:"auto-route"`
	AutoRedirect          *bool              `yaml:"auto-redirect" json:"auto-redirect,omitempty"`
	RouteAddress          *[]netip.Prefix    `yaml:"route-address" json:"route-address,omitempty"`
	RouteExcludeAddress   *[]netip.Prefix    `yaml:"route-exclude-address" json:"route-exclude-address,omitempty"`
	StrictRoute           *bool              `yaml:"strict-route" json:"strict-route,omitempty"`
	DisableICMPForwarding *bool              `yaml:"disable-icmp-forwarding" json:"disable-icmp-forwarding,omitempty"`
}

type ChangeProxyParams struct {
	GroupName *string `json:"group-name"`
	ProxyName *string `json:"proxy-name"`
}

type TestDelayParams struct {
	ProxyName string `json:"proxy-name"`
	TestUrl   string `json:"test-url"`
	Timeout   int64  `json:"timeout"`
}

type ExternalProvider struct {
	Name             string                     `json:"name"`
	Type             string                     `json:"type"`
	VehicleType      string                     `json:"vehicle-type"`
	Count            int                        `json:"count"`
	Path             string                     `json:"path"`
	UpdateAt         time.Time                  `json:"update-at"`
	SubscriptionInfo *provider.SubscriptionInfo `json:"subscription-info"`
}

const (
	messageMethod                        Method = "message"
	initClashMethod                      Method = "initClash"
	getIsInitMethod                      Method = "getIsInit"
	forceGcMethod                        Method = "forceGc"
	shutdownMethod                       Method = "shutdown"
	validateConfigMethod                 Method = "validateConfig"
	importProfileMethod                  Method = "importProfile"
	downloadProfileMethod                Method = "downloadProfile"
	decryptAgeConfigMethod               Method = "decryptAgeConfig"
	updateConfigMethod                   Method = "updateConfig"
	getProxiesMethod                     Method = "getProxies"
	changeProxyMethod                    Method = "changeProxy"
	getTrafficMethod                     Method = "getTraffic"
	getTrafficSnapshotMethod             Method = "getTrafficSnapshot"
	resetTrafficMethod                   Method = "resetTraffic"
	asyncTestDelayMethod                 Method = "asyncTestDelay"
	asyncTestDelaysMethod                Method = "asyncTestDelays"
	setForegroundMethod                  Method = "setForeground"
	getConnectionsMethod                 Method = "getConnections"
	getConnectionsSummaryMethod          Method = "getConnectionsSummary"
	closeConnectionsMethod               Method = "closeConnections"
	resetConnectionsMethod               Method = "resetConnectionsMethod"
	closeConnectionMethod                Method = "closeConnection"
	closeGroupConnectionsMethod          Method = "closeGroupConnections"
	getDialerDependentsMethod            Method = "getDialerDependents"
	checkDialerUDPMethod                 Method = "checkDialerUdp"
	getExternalProvidersMethod           Method = "getExternalProviders"
	getExternalProviderMethod            Method = "getExternalProvider"
	getCountryCodeMethod                 Method = "getCountryCode"
	getMemoryMethod                      Method = "getMemory"
	updateGeoDataMethod                  Method = "updateGeoData"
	updateExternalProviderMethod         Method = "updateExternalProvider"
	sideLoadExternalProviderMethod       Method = "sideLoadExternalProvider"
	startLogMethod                       Method = "startLog"
	stopLogMethod                        Method = "stopLog"
	startListenerMethod                  Method = "startListener"
	stopListenerMethod                   Method = "stopListener"
	updateDnsMethod                      Method = "updateDns"
	setStateMethod                       Method = "setState"
	getAndroidVpnOptionsMethod           Method = "getAndroidVpnOptions"
	getRunTimeMethod                     Method = "getRunTime"
	getCurrentProfileNameMethod          Method = "getCurrentProfileName"
	crashMethod                          Method = "crash"
	setupConfigMethod                    Method = "setupConfig"
	getConfigMethod                      Method = "getConfig"
	getRuntimeConfigMethod               Method = "getRuntimeConfig"
	getProxyConfigMethod                 Method = "getProxyConfig"
	updateExpandedProviderMethod         Method = "updateExpandedProvider"
	exportConfigMethod                   Method = "exportConfig"
	mergeProfilesMethod                  Method = "mergeProfiles"
	flushFakeIPMethod                    Method = "flushFakeIP"
	flushDnsCacheMethod                  Method = "flushDnsCache"
	generateAgeKeyPairMethod             Method = "generateAgeKeyPair"
	convertAgeSecretKeyToPublicKeyMethod Method = "convertAgeSecretKeyToPublicKey"
	getModeMethod                        Method = "getMode"
	parseExternalProviderContentMethod   Method = "parseExternalProviderContent"
	getCoreStatusMethod                  Method = "getCoreStatus"
	getRequestsMethod                    Method = "getRequests"
	startTrackRequestsMethod             Method = "startTrackRequests"
	stopTrackRequestsMethod              Method = "stopTrackRequests"
	clearRequestsMethod                  Method = "clearRequests"
	getLogsMethod                        Method = "getLogs"
	clearLogsMethod                      Method = "clearLogs"
	startSpeedTestMethod                 Method = "startSpeedTest"
	cancelSpeedTestMethod                Method = "cancelSpeedTest"
	probeSpeedTestMethod                 Method = "probeSpeedTest"
	getSpeedTestServersMethod            Method = "getSpeedTestServers"
	startStunTestMethod                  Method = "startStunTest"
	cancelStunTestMethod                 Method = "cancelStunTest"
	startIperfServerMethod               Method = "startIperfServer"
	stopIperfServerMethod                Method = "stopIperfServer"
	startIperfClientMethod               Method = "startIperfClient"
	cancelIperfClientMethod              Method = "cancelIperfClient"
	startLocalPingMethod                 Method = "startLocalPing"
	cancelLocalPingMethod                Method = "cancelLocalPing"
	routeTraceMethod                     Method = "routeTrace"
	dnsQueryMethod                       Method = "dnsQuery"
	mrsPrepareMethod                     Method = "mrsPrepare"
	mrsLookupMethod                      Method = "mrsLookup"
	mrsDumpMethod                        Method = "mrsDump"
	getTrafficStatsMethod                Method = "getTrafficStats"
	clearTrafficStatsMethod              Method = "clearTrafficStats"
	storeGetMethod                       Method = "storeGet"
	storeSetMethod                       Method = "storeSet"
	storeListMethod                      Method = "storeList"
	parseNodesMethod                     Method = "parseNodes"
	registerWarpMethod                   Method = "registerWarp"
	testNodeMethod                       Method = "testNode"
	storeClearMethod                     Method = "storeClear"
	cancelMrsLookupMethod                Method = "cancelMrsLookup"
	startToolProxyMethod                 Method = "startToolProxy"
	stopToolProxyMethod                  Method = "stopToolProxy"
	ageCryptMethod                       Method = "ageCrypt"
)

type Method string

type MessageType string

type Delay struct {
	Url   string `json:"url"`
	Name  string `json:"name"`
	Value int32  `json:"value"`
}

type Message struct {
	Type MessageType `json:"type"`
	Data interface{} `json:"data"`
}

const (
	LogMessage           MessageType = "log"
	DelaysMessage        MessageType = "delays"
	GroupsChangedMessage MessageType = "groupsChanged"
	RequestMessage       MessageType = "request"
)

func (message *Message) Json() (string, error) {
	data, err := json.Marshal(message)
	return string(data), err
}
